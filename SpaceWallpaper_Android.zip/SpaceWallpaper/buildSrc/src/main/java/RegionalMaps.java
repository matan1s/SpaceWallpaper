import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Iterator;
import java.util.List;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageInputStream;
import javax.imageio.stream.ImageOutputStream;

/**
 * Build-time helper (runs on the GitHub Actions machine, never on the phone).
 *
 * Downloads NASA's full-resolution Blue Marble (day) and Black Marble (night lights) maps, crops
 * the Europe / North Africa region (20W-50E, 10N-70N) using a region read (the whole 21600 px image
 * is never decoded into memory), resizes to 2560x2048, colour-matches it to the bundled global maps
 * and writes region_day.jpg / region_aux.jpg into the app assets.
 *
 * If anything fails (no network, URL moved, unexpected image) the bundled fallback maps are kept
 * and the build continues. region_source.txt records which source was used; the app shows it.
 */
public final class RegionalMaps {
    static final double LON0 = -20, LON1 = 50, LAT0 = 10, LAT1 = 70;
    static final int OUT_W = 2560, OUT_H = 2048;

    static final List<String> DAY_URLS = List.of(
            "https://eoimages.gsfc.nasa.gov/images/imagerecords/74000/74042/world.200408.3x21600x10800.jpg",
            "https://eoimages.gsfc.nasa.gov/images/imagerecords/73000/73909/world.topo.bathy.200412.3x21600x10800.jpg",
            "https://eoimages.gsfc.nasa.gov/images/imagerecords/74000/74092/world.200407.3x21600x10800.jpg");
    static final List<String> NIGHT_URLS = List.of(
            "https://eoimages.gsfc.nasa.gov/images/imagerecords/144000/144898/BlackMarble_2016_3km.jpg",
            "https://eoimages.gsfc.nasa.gov/images/imagerecords/79000/79765/dnb_land_ocean_ice.2012.13500x6750.jpg");

    private RegionalMaps() {}

    /** Entry point used by app/build.gradle. Never throws: on failure the fallback stays. */
    public static void run(File texturesDir, File workDir, List<String> dayUrls, List<String> nightUrls) {
        System.setProperty("java.awt.headless", "true");          // CI machine has no display
        File marker = new File(texturesDir, "region_source.txt");
        try {
            if (marker.exists() && readText(marker).startsWith("NASA")) {
                log("regional maps already generated from NASA sources - skipping");
                return;
            }
            workDir.mkdirs();
            BufferedImage fbDay = ImageIO.read(new File(texturesDir, "region_day.jpg"));
            BufferedImage fbAux = ImageIO.read(new File(texturesDir, "region_aux.jpg"));
            if (fbDay == null || fbAux == null) throw new IOException("fallback maps missing");

            String dayUrl = null, nightUrl = null;
            BufferedImage day = null, night = null;
            for (String u : dayUrls) {
                try {
                    File f = download(u, new File(workDir, "day.jpg"));
                    day = cropRegion(f, 10000);
                    dayUrl = u;
                    break;
                } catch (Exception e) {
                    log("day source failed: " + u + " (" + e.getMessage() + ")");
                }
            }
            for (String u : nightUrls) {
                try {
                    File f = download(u, new File(workDir, "night.jpg"));
                    night = cropRegion(f, 8000);
                    nightUrl = u;
                    break;
                } catch (Exception e) {
                    log("night source failed: " + u + " (" + e.getMessage() + ")");
                }
            }
            if (day == null && night == null) {
                log("no NASA source reachable - keeping the bundled fallback maps");
                return;
            }

            BufferedImage outDay = fbDay;
            if (day != null) {
                outDay = matchColours(resize(day, OUT_W, OUT_H), fbDay);
            }
            BufferedImage outAux = new BufferedImage(OUT_W, OUT_H, BufferedImage.TYPE_INT_RGB);
            BufferedImage nightR = night != null ? resize(night, OUT_W, OUT_H) : null;
            for (int y = 0; y < OUT_H; y++) {
                for (int x = 0; x < OUT_W; x++) {
                    int a = fbAux.getRGB(x, y);
                    int lights = (a >> 16) & 0xFF;
                    int land = (a >> 8) & 0xFF;
                    if (nightR != null) {
                        int n = nightR.getRGB(x, y);
                        lights = (int) Math.round(0.299 * ((n >> 16) & 0xFF) + 0.587 * ((n >> 8) & 0xFF) + 0.114 * (n & 0xFF));
                    }
                    outAux.setRGB(x, y, (lights << 16) | (land << 8));
                }
            }
            writeJpeg(outDay, new File(texturesDir, "region_day.jpg"), 0.90f);
            writeJpeg(outAux, new File(texturesDir, "region_aux.jpg"), 0.90f);
            String src = "NASA hi-res: day=" + (dayUrl != null ? name(dayUrl) : "fallback")
                    + ", night=" + (nightUrl != null ? name(nightUrl) : "fallback") + "\n";
            Files.write(marker.toPath(), src.getBytes(StandardCharsets.UTF_8));
            log("regional maps written - " + src.trim());
        } catch (Throwable t) {
            log("regional map step skipped: " + t);
        }
    }

    public static void run(File texturesDir, File workDir) {
        run(texturesDir, workDir, DAY_URLS, NIGHT_URLS);
    }

    // ------------------------------------------------------------------------------------------
    static File download(String url, File out) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(120000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "DeepSpaceWallpaper-build");
        int code = c.getResponseCode();
        if (code != 200) throw new IOException("HTTP " + code);
        try (InputStream in = c.getInputStream(); OutputStream os = new FileOutputStream(out)) {
            byte[] buf = new byte[1 << 16];
            int r;
            long total = 0;
            while ((r = in.read(buf)) > 0) {
                os.write(buf, 0, r);
                total += r;
            }
            log("downloaded " + (total / 1024 / 1024) + " MB from " + url);
        }
        return out;
    }

    /** Reads only the region rectangle of a (huge) equirectangular JPEG. */
    static BufferedImage cropRegion(File f, int minWidth) throws IOException {
        try (ImageInputStream iis = ImageIO.createImageInputStream(f)) {
            Iterator<ImageReader> it = ImageIO.getImageReaders(iis);
            if (!it.hasNext()) throw new IOException("not an image");
            ImageReader r = it.next();
            r.setInput(iis, true, true);
            int w = r.getWidth(0), h = r.getHeight(0);
            if (w < minWidth || Math.abs(w - 2 * h) > 4) throw new IOException("unexpected size " + w + "x" + h);
            int x0 = (int) Math.floor((LON0 + 180) / 360.0 * w);
            int x1 = (int) Math.ceil((LON1 + 180) / 360.0 * w);
            int y0 = (int) Math.floor((90 - LAT1) / 180.0 * h);
            int y1 = (int) Math.ceil((90 - LAT0) / 180.0 * h);
            ImageReadParam p = r.getDefaultReadParam();
            p.setSourceRegion(new Rectangle(x0, y0, x1 - x0, y1 - y0));
            BufferedImage img = r.read(0, p);
            r.dispose();
            log("cropped " + img.getWidth() + "x" + img.getHeight() + " from " + w + "x" + h);
            return img;
        }
    }

    /** High-quality resize (progressive halving + bicubic). */
    static BufferedImage resize(BufferedImage src, int w, int h) {
        BufferedImage cur = toRgb(src);
        while (cur.getWidth() / 2 >= w && cur.getHeight() / 2 >= h) {
            cur = scale(cur, cur.getWidth() / 2, cur.getHeight() / 2);
        }
        return scale(cur, w, h);
    }

    static BufferedImage scale(BufferedImage src, int w, int h) {
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.drawImage(src, 0, 0, w, h, null);
        g.dispose();
        return out;
    }

    static BufferedImage toRgb(BufferedImage src) {
        if (src.getType() == BufferedImage.TYPE_INT_RGB) return src;
        BufferedImage out = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = out.createGraphics();
        g.drawImage(src, 0, 0, null);
        g.dispose();
        return out;
    }

    /** Per-channel mean/std transfer so the hi-res crop blends invisibly into the global map. */
    static BufferedImage matchColours(BufferedImage img, BufferedImage ref) {
        double[] mi = new double[3], si = new double[3], mr = new double[3], sr = new double[3];
        stats(img, mi, si);
        stats(ref, mr, sr);
        BufferedImage out = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < img.getHeight(); y++) {
            for (int x = 0; x < img.getWidth(); x++) {
                int p = img.getRGB(x, y);
                int[] c = {(p >> 16) & 0xFF, (p >> 8) & 0xFF, p & 0xFF};
                int rgb = 0;
                for (int k = 0; k < 3; k++) {
                    double v = (c[k] - mi[k]) * (sr[k] / Math.max(si[k], 1e-3)) + mr[k];
                    int iv = (int) Math.max(0, Math.min(255, Math.round(v)));
                    rgb = (rgb << 8) | iv;
                }
                out.setRGB(x, y, rgb);
            }
        }
        return out;
    }

    static void stats(BufferedImage img, double[] mean, double[] sd) {
        long n = 0;
        double[] s = new double[3], s2 = new double[3];
        for (int y = 0; y < img.getHeight(); y += 2) {
            for (int x = 0; x < img.getWidth(); x += 2) {
                int p = img.getRGB(x, y);
                int[] c = {(p >> 16) & 0xFF, (p >> 8) & 0xFF, p & 0xFF};
                for (int k = 0; k < 3; k++) {
                    s[k] += c[k];
                    s2[k] += c[k] * (double) c[k];
                }
                n++;
            }
        }
        for (int k = 0; k < 3; k++) {
            mean[k] = s[k] / n;
            sd[k] = Math.sqrt(Math.max(s2[k] / n - mean[k] * mean[k], 0));
        }
    }

    static void writeJpeg(BufferedImage img, File out, float quality) throws IOException {
        ImageWriter w = ImageIO.getImageWritersByFormatName("jpg").next();
        ImageWriteParam p = w.getDefaultWriteParam();
        p.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        p.setCompressionQuality(quality);
        try (ImageOutputStream os = ImageIO.createImageOutputStream(out)) {
            w.setOutput(os);
            w.write(null, new IIOImage(img, null, null), p);
        }
        w.dispose();
    }

    static String readText(File f) throws IOException {
        return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
    }

    static String name(String url) { return url.substring(url.lastIndexOf('/') + 1); }

    static void log(String s) { System.out.println("[RegionalMaps] " + s); }
}
