#version 300 es
// Bloom pass 1: bright-pass + 4x downsample (16 source pixels via 4 bilinear taps)
precision mediump float;
uniform sampler2D uTex;
uniform vec2 uSrcTexel;      // 1 / source size
uniform float uThreshold;    // ~0.62 on the tone-mapped image
out vec4 fragColor;
void main() {
    vec2 uv = gl_FragCoord.xy * 4.0 * uSrcTexel;   // centre of the 4x4 source block
    vec3 c = texture(uTex, uv + vec2(-1.0, -1.0) * uSrcTexel).rgb
           + texture(uTex, uv + vec2( 1.0, -1.0) * uSrcTexel).rgb
           + texture(uTex, uv + vec2(-1.0,  1.0) * uSrcTexel).rgb
           + texture(uTex, uv + vec2( 1.0,  1.0) * uSrcTexel).rgb;
    c *= 0.25;
    float l = max(max(c.r, c.g), c.b);
    float k = smoothstep(uThreshold, uThreshold + 0.25, l);        // soft knee
    fragColor = vec4(c * k, 1.0);
}
