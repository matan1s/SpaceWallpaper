#version 300 es
// Bloom pass 1: bright-pass + 4x downsample (16 source pixels via 4 bilinear taps).
// The scene alpha is a bloom mask: 1 in space / flare, 0.3 on the Earth disc, so city lights
// only get a faint halo and stay crisp.
precision mediump float;
uniform sampler2D uTex;
uniform vec2 uSrcTexel;      // 1 / source size
uniform float uThreshold;    // on the tone-mapped image
out vec4 fragColor;
void main() {
    vec2 uv = gl_FragCoord.xy * 4.0 * uSrcTexel;   // centre of the 4x4 source block
    vec4 a = texture(uTex, uv + vec2(-1.0, -1.0) * uSrcTexel);
    vec4 b = texture(uTex, uv + vec2( 1.0, -1.0) * uSrcTexel);
    vec4 c = texture(uTex, uv + vec2(-1.0,  1.0) * uSrcTexel);
    vec4 d = texture(uTex, uv + vec2( 1.0,  1.0) * uSrcTexel);
    vec3 col = (a.rgb * a.a + b.rgb * b.a + c.rgb * c.a + d.rgb * d.a) * 0.25;
    float mask = (a.a + b.a + c.a + d.a) * 0.25;
    float l = max(max(col.r, col.g), col.b) / max(mask, 0.05);
    float k = smoothstep(uThreshold, uThreshold + 0.20, l);         // soft knee
    fragColor = vec4(col * k, 1.0);
}
