#version 300 es
// Final pass: upscale scene to the screen, add bloom, film grain and dithering
precision highp float;
uniform sampler2D uScene;
uniform sampler2D uBloom;
uniform vec2  uScreen;       // screen size in pixels
uniform float uBloomAmt;     // 0 disables bloom
uniform float uSeed;         // changes every frame (grain animation)
out vec4 fragColor;

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

void main() {
    vec2 uv = gl_FragCoord.xy / uScreen;
    vec3 c = texture(uScene, uv).rgb;
    if (uBloomAmt > 0.0) {
        vec3 b = texture(uBloom, uv).rgb;
        c = 1.0 - (1.0 - c) * (1.0 - b * uBloomAmt);                // screen blend: no clipping
    }
    // film grain: strongest in the shadows, invisible in highlights
    float g = hash12(gl_FragCoord.xy + uSeed * 37.13) - 0.5;
    float lum = dot(c, vec3(0.299, 0.587, 0.114));
    c += g * 0.018 * (1.0 - smoothstep(0.05, 0.6, lum));
    // triangular dither against banding in the deep-space gradients
    float d = hash12(gl_FragCoord.xy * 1.37 + 11.0) + hash12(gl_FragCoord.xy * 0.71 + 3.0) - 1.0;
    c += d / 255.0;
    fragColor = vec4(c, 1.0);
}
