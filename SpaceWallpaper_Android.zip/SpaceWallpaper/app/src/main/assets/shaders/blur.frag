#version 300 es
// Bloom pass 2/3: separable Gaussian (9 taps folded into 5 bilinear fetches)
precision mediump float;
uniform sampler2D uTex;
uniform vec2 uDir;           // (1/w, 0) or (0, 1/h), scaled by the blur radius
out vec4 fragColor;
void main() {
    vec2 uv = gl_FragCoord.xy / vec2(textureSize(uTex, 0));
    vec3 c = texture(uTex, uv).rgb * 0.2270270;
    c += texture(uTex, uv + uDir * 1.3846154).rgb * 0.3162162;
    c += texture(uTex, uv - uDir * 1.3846154).rgb * 0.3162162;
    c += texture(uTex, uv + uDir * 3.2307692).rgb * 0.0702703;
    c += texture(uTex, uv - uDir * 3.2307692).rgb * 0.0702703;
    fragColor = vec4(c, 1.0);
}
