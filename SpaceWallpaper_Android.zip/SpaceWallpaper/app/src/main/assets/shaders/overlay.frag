#version 300 es
// Debug overlay: draws the stats bitmap into the viewport rectangle (premultiplied alpha).
precision mediump float;
uniform sampler2D uTex;
uniform vec4 uRect;          // x, y, w, h in window pixels (GL origin bottom-left)
out vec4 fragColor;
void main() {
    vec2 uv = (gl_FragCoord.xy - uRect.xy) / uRect.zw;
    fragColor = texture(uTex, vec2(uv.x, 1.0 - uv.y));       // bitmap rows are top-down
}
