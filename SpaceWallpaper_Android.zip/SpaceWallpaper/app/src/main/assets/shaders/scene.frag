#version 300 es
// ---------------------------------------------------------------------------
//  Deep Space live wallpaper - per-frame scene shader (v3.4)
//  Composition fitted to the reference (S25 Ultra portrait 1440x3120):
//    Earth limb: (100%,10%) -> (47%,62%) -> (100%,98%), Sun behind the limb at ~(48%,64%),
//    Moon at (26%,26%), Milky Way from (45%,0%) to (0%,75%), core near (15%,50%).
//  v3.4: the static sky (Milky Way, nebulae, stars) is pre-rendered by sky.frag into uSkyA/uSkyB;
//  only animated parts run here: star twinkle, Earth + clouds, Moon, meteors, flare.
//  Output: tone-mapped colour; bloom + grain are added by composite.frag.
//  SEAMLESS LOOP: every animated term is periodic in uPhase (0..2PI).
// ---------------------------------------------------------------------------
precision highp float;
precision highp int;

uniform mediump sampler3D uNoise;
uniform mediump sampler2D uEarthDay;   // NASA Blue Marble (equirectangular)
uniform mediump sampler2D uEarthAux;   // R clouds, G night lights (Black Marble), B land mask
uniform mediump sampler2D uMoonTex;    // lunar map
uniform mediump sampler2D uCloudTex;   // sharpened 4K cloud map (single channel)
uniform mediump sampler2D uRegionDay;  // hi-res Europe / North Africa day map (20W-50E, 10N-70N)
uniform mediump sampler2D uRegionAux;  // R night lights, G land mask (same region)
uniform mediump sampler2D uSkyA;       // baked Milky Way (sky.frag)
uniform mediump sampler2D uSkyB;       // baked stars + twinkle code (sky.frag)
uniform vec2  uTanExt;    // tangent half-extent covered by the baked sky
uniform vec2  uRes;
uniform float uPhase;
uniform vec4  uCam;       // x yaw, y pitch (radians), z/w parallax shift (-1..1)
uniform int   uOct;
uniform vec4  uToggles;   // x stars, z camera drift amount, w flare on/off (settings switch ONLY)
uniform vec3  uSun;       // direction towards the Sun (camera space)
uniform float uRealtime;  // 1 = real-time sun (uSun is the real Sun, Earth does not spin)
uniform mat3  uEarthM;    // camera space -> Earth texture space (base orientation)
uniform float uEarthSpin; // Earth spin angle (radians) applied about the polar axis
uniform vec4  uMoon;      // xy screen position (fraction, origin top-left), z size scale, w visible
uniform float uMoonBright; // moon brightness multiplier (settings slider, 1 = default)
uniform vec4  uClouds;    // x clouds on/off, y opacity 0..1
uniform vec4  uLight;     // x flare intensity (0..1, 1 = v3.1 strength), y Earth sunlight, z city lights
uniform vec4  uPlanets;   // x drifting planets on/off, y depth-of-field strength
uniform vec4  uMeteorA;   // active meteor 1 (CPU-scheduled): head.xy (tangent), heading (rad), life
uniform vec4  uMeteorB;   // active meteor 2
uniform vec2  uMeteorLen; // tail lengths of meteor 1 / 2

out vec4 fragColor;

#define SUN uSun

// ---- scene layout (camera space, camera looks down -Z) ----
const vec3  PB_C  = vec3(35.98335, -2.73510, -65.74738);   // Earth centre (off-screen right)
const float PB_R  = 37.7387;
const float SUN_ANG = 0.0047;
// regional hi-res maps: longitude / latitude bounds (degrees) and edge feather (fraction)
const float REG_LON0 = -20.0, REG_LON1 = 50.0, REG_LAT0 = 10.0, REG_LAT1 = 70.0;
const float REG_FEATHER = 0.08;
const float MOON_DIST = 45.0;
const float MOON_R0   = 1.93;                               // 15% of screen width at default size
const float PL_PARALLAX_EARTH = 1.2;                         // per-layer parallax (scene units)
const float PL_PARALLAX_MOON  = 0.45;


#include "common.glsl"

// Sphere test with analytic anti-aliased coverage of the limb.
// returns (tEntry, coverage); tca = distance to closest approach, dmin = closest distance to centre
vec2 sphere(vec3 ro, vec3 rd, vec3 c, float r, float pix, out float tca, out float dmin) {
    vec3 oc = c - ro;
    tca = dot(oc, rd);
    dmin = length(oc - rd * tca);
    if (tca <= 0.0) return vec2(-1.0, 0.0);
    float cov = clamp((r - dmin) / (tca * pix) + 0.5, 0.0, 1.0);
    float h = r * r - dmin * dmin;
    return vec2(tca - sqrt(max(h, 0.0)), cov);
}

// Single-scattering style atmosphere approximation (additive light along the ray)
vec3 atmosphere(vec3 ro, vec3 rd, vec3 c, float r, float tca, float dmin,
                float scaleH, vec3 tint, float strength, vec3 L) {
    if (tca <= 0.0) return vec3(0.0);
    float x = (dmin - r) / (scaleH * r);
    float dens;
    if (x > 0.0) {
        dens = exp(-x);
    } else {
        float mu = sqrt(max(1.0 - (dmin / r) * (dmin / r), 0.0)); // 0 at limb .. 1 at disc centre
        dens = exp(-mu * 9.0);
    }
    vec3 limbN = normalize(ro + rd * tca - c);
    float lit = smoothstep(-0.35, 0.55, dot(limbN, L));
    float fwd = pow(max(dot(rd, L), 0.0), 400.0);
    return tint * dens * strength * lit * (0.30 + 6.0 * fwd);
}

// ---------------------------------------------------------------------------

// Equirectangular lookup with explicit LOD (no derivatives => no seam line, safe in branches)
vec4 equirect(sampler2D tex, vec3 d, float footprint, float mu, float texW) {
    float u = atan(d.x, d.z) * 0.15915494 + 0.5;
    float v = acos(clamp(d.y, -1.0, 1.0)) * 0.31830989;
    texW = float(textureSize(tex, 0).x);                    // actual size (tier-dependent)
    float lod = log2(max(footprint * texW * 0.15915494, 1e-4)) + 0.5 * log2(1.0 / max(mu, 0.06));
    return textureLod(tex, vec2(u, v), max(lod, 0.0));
}




// Light used for the Earth surface: the real Sun in real-time mode; otherwise the Sun swung
// towards the camera so a wide day crescent runs along the limb (as in the reference photo).
vec3 earthLight() {
    return uRealtime > 0.5 ? uSun : normalize(uSun + 0.60 * vec3(-0.55, 0.10, 0.62));
}
// Artistic key light for the optional drifting planets
vec3 planetLight() {
    return uRealtime > 0.5 ? uSun : normalize(uSun + vec3(0.9, 0.35, 1.15));
}

// screen fraction (origin top-left) -> camera-space direction at rest
vec3 screenDir(vec2 f) {
    float aspect = uRes.x / uRes.y;
    return normalize(vec3((f.x - 0.5) * 2.0 * TAN_V * aspect, (0.5 - f.y) * 2.0 * TAN_V, -1.0));
}

// ===========================================================================
//  BAKED STATIC SKY (sky.frag): Milky Way + stars; only the twinkle is animated here
// ===========================================================================
// 5-tap Catmull-Rom (bilinear-tap optimised). Keeps 1-pixel stars sharp at any sub-pixel camera
// offset (plain bilinear would halve their peak while the camera drifts).
vec3 sampleCatmullRom(sampler2D tex, vec2 uv) {
    vec2 size = vec2(textureSize(tex, 0));
    vec2 sp = uv * size;
    vec2 t1 = floor(sp - 0.5) + 0.5;
    vec2 f = sp - t1;
    vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    vec2 w3 = f * f * (-0.5 + 0.5 * f);
    vec2 w12 = w1 + w2;
    vec2 t12 = (t1 + w2 / w12) / size;
    vec2 t0 = (t1 - 1.0) / size;
    vec2 t3 = (t1 + 2.0) / size;
    vec3 r = texture(tex, vec2(t12.x, t0.y)).rgb * (w12.x * w0.y)
           + texture(tex, vec2(t0.x, t12.y)).rgb * (w0.x * w12.y)
           + texture(tex, t12).rgb * (w12.x * w12.y)
           + texture(tex, vec2(t3.x, t12.y)).rgb * (w3.x * w12.y)
           + texture(tex, vec2(t12.x, t3.y)).rgb * (w12.x * w3.y);
    float wsum = w12.x * w0.y + w0.x * w12.y + w12.x * w12.y + w3.x * w12.y + w12.x * w3.y;
    return max(r / wsum, vec3(0.0));
}

vec3 bakedSky(vec3 rd, float ph) {
    vec2 st = (rd.xy / -rd.z) / uTanExt * 0.5 + 0.5;
    vec3 mw = texture(uSkyA, st).rgb;
    vec3 sb = uToggles.x > 0.5 ? sampleCatmullRom(uSkyB, st) : vec3(0.0);
    vec3 col = mw * mw * mw * MW_SCALE;
    if (uToggles.x > 0.5 && dot(sb, vec3(1.0)) > 0.004) {
        ivec2 sz = textureSize(uSkyB, 0);
        ivec2 tc = clamp(ivec2(st * vec2(sz)), ivec2(0), sz - 1);
        float code = floor(texelFetch(uSkyB, tc, 0).a * 255.0 + 0.5);   // exact twinkle code
        float tw;
        if (code >= 240.0) {
            tw = 0.85 + 0.15 * sin(ph * (code - 236.0));                 // bright stars
        } else {
            float ki = floor(code / 16.0);
            tw = 0.75 + 0.25 * sin(ph * (10.0 + 2.0 * ki) + (code - ki * 16.0) * 0.39269908);
        }
        col += sb * sb * sb * ST_SCALE * tw;
    }
    return col;
}

// ===========================================================================
//  EARTH
// flare strength actually applied: switch AND intensity slider (0% looks exactly like OFF)
float flareAmount() { return uToggles.w > 0.5 ? uLight.x : 0.0; }

vec2 eqUV(vec3 d) {
    return vec2(atan(d.x, d.z) * 0.15915494 + 0.5, acos(clamp(d.y, -1.0, 1.0)) * 0.31830989);
}

// Earth-texture-space normals under the neighbouring pixels (+x, +y). Re-intersecting the sphere
// gives exact screen-space derivatives without dFdx (safe inside branches, no seam artefacts).
void earthNeighbours(vec3 rd, vec3 ec, float pix, vec3 N, out vec3 bx, out vec3 by) {
    for (int k = 0; k < 2; k++) {
        vec3 off = k == 0 ? vec3(pix, 0.0, 0.0) : vec3(0.0, pix, 0.0);
        float sgn = 1.0;
        vec3 r2 = normalize(rd + off);
        float b = dot(ec, r2);
        float h = b * b - dot(ec, ec) + PB_R * PB_R;
        if (h < 0.0) {                                       // at the limb: use the other side
            sgn = -1.0;
            r2 = normalize(rd - off);
            b = dot(ec, r2);
            h = b * b - dot(ec, ec) + PB_R * PB_R;
        }
        vec3 n2 = h >= 0.0 ? normalize(r2 * (b - sqrt(h)) - ec) : N;
        vec3 v = uEarthM * (N + (n2 - N) * sgn);
        if (k == 0) bx = v; else by = v;
    }
}

float cloudSample(mat3 R, vec3 b0, vec3 bx, vec3 by) {
    vec2 uv = eqUV(R * b0);
    vec2 dx = eqUV(R * bx) - uv;
    vec2 dy = eqUV(R * by) - uv;
    dx.x -= floor(dx.x + 0.5);                               // longitude wrap
    dy.x -= floor(dy.x + 0.5);
    return textureGrad(uCloudTex, uv, dx, dy).r;
}

// ===========================================================================
// sample an equirectangular map with exact screen-space gradients (correct mip + anisotropy)
vec4 sampleEq(sampler2D tex, vec2 uv, vec2 dx, vec2 dy) { return textureGrad(tex, uv, dx, dy); }

vec3 shadeEarth(vec3 rd, vec3 P, vec3 ec, float t, float pix, float ph) {
    vec3 N = normalize(P - ec);
    float fp = t * pix / PB_R;
    float mu = max(dot(N, -rd), 0.0);
    vec3 base = uEarthM * N;
    mat3 spin = rotY(-uEarthSpin);
    vec3 q = spin * base;

    // neighbouring-pixel normals -> exact texture gradients for every Earth map
    vec3 bx, by;
    earthNeighbours(rd, ec, pix, N, bx, by);
    vec2 uv = eqUV(q);
    vec2 dx = eqUV(spin * bx) - uv;
    vec2 dy = eqUV(spin * by) - uv;
    dx.x -= floor(dx.x + 0.5);                                // longitude wrap
    dy.x -= floor(dy.x + 0.5);

    // ---- global 4K maps ----
    vec3 dayS = sampleEq(uEarthDay, uv, dx, dy).rgb;
    vec3 aux = sampleEq(uEarthAux, uv, dx, dy).rgb;
    float landS = aux.b;
    float lightS = aux.g;
    // blurred lights (2 mips up) for the unsharp mask that keeps cities as crisp points
    float lightB = sampleEq(uEarthAux, uv, dx * 4.0, dy * 4.0).g;

    // ---- high-resolution regional maps (Europe / North Africa), feathered blend ----
    float lon = (uv.x - 0.5) * 360.0;
    float lat = 90.0 - uv.y * 180.0;
    vec2 ruv = vec2((lon - REG_LON0) / (REG_LON1 - REG_LON0), (REG_LAT1 - lat) / (REG_LAT1 - REG_LAT0));
    float rw = smoothstep(0.0, REG_FEATHER, min(min(ruv.x, 1.0 - ruv.x), min(ruv.y, 1.0 - ruv.y)));
    if (rw > 0.0) {
        vec2 sc = vec2(360.0 / (REG_LON1 - REG_LON0), 180.0 / (REG_LAT1 - REG_LAT0));
        vec2 rdx = dx * sc, rdy = dy * sc;
        vec3 rday = sampleEq(uRegionDay, ruv, rdx, rdy).rgb;
        vec3 raux = sampleEq(uRegionAux, ruv, rdx, rdy).rgb;
        float rlB = sampleEq(uRegionAux, ruv, rdx * 4.0, rdy * 4.0).r;
        dayS = mix(dayS, rday, rw);
        lightS = mix(lightS, raux.r, rw);
        lightB = mix(lightB, rlB, rw);
        landS = mix(landS, raux.g, rw);
    }

    // clouds drift faster than the ground: two flow phases cross-faded (seamless)
    float cloud = 0.0;
    if (uClouds.x > 0.5 && uClouds.y > 0.0) {
        float ft = ph * 0.15915494 * 6.0;                      // 6 flow cycles per loop
        float f1 = fract(ft), f2 = fract(ft + 0.5);
        float wgt = abs(f1 - 0.5) * 2.0;                       // weight of layer 2
        float cl1 = cloudSample(rotY(-uEarthSpin - 0.05 * f1), base, bx, by);
        float cl2 = cloudSample(rotY(-uEarthSpin - 0.05 * f2), base, bx, by);
        float c0 = smoothstep(0.10, 0.85, mix(cl1, cl2, wgt));
        float edge = 4.0 * c0 * (1.0 - c0);
        cloud = c0;
        // procedural micro-detail only on cloud EDGES (skipped on clear sky / solid cloud),
        // max 3 octaves (finer ones are sub-pixel anyway); rides on both flow phases -> never pops
        if (edge > 0.03) {
            int dOct = min(uOct, 3);
            vec3 cq1 = rotY(-uEarthSpin - 0.05 * f1) * base;
            vec3 cq2 = rotY(-uEarthSpin - 0.05 * f2) * base;
            float det = mix(fbm(cq1 * 190.0 + 3.7, dOct, fp * 190.0), fbm(cq2 * 190.0 + 3.7, dOct, fp * 190.0), wgt);
            cloud = clamp(c0 + (det - 0.5) * 0.65 * edge, 0.0, 1.0);
        }
        cloud *= uClouds.y;
    }

    vec3 day = toLinear(dayS);
    float land = smoothstep(0.3, 0.7, landS);
    vec3 alb = mix(day * vec3(0.30, 0.42, 0.62), day, land);

    vec3 L = earthLight();
    float ndl = dot(N, L);
    float lamb = max(ndl, 0.0);
    float dayF = smoothstep(-0.10, 0.15, ndl);
    vec3 sunCol = vec3(1.0, 0.97, 0.92) * 3.2 * uLight.y;      // Earth-light slider
    vec3 night = vec3(0.10, 0.16, 0.30) * 0.06;                // moon/sky light on the night side

    // (v3.3: no specular ocean glint - it produced the soft blob near the limb at ~(50%,59%))
    vec3 surf = alb * (sunCol * lamb + night * (0.6 + 0.8 * land));
    surf *= 1.0 - 0.45 * cloud * dayF;

    // city lights: unsharp-masked so cities stay crisp points, gentle periodic shimmer
    float nightF = 1.0 - smoothstep(-0.18, 0.06, ndl);
    float sharp = lightS + 0.55 * max(lightS - lightB, 0.0);     // boost peaks only, never dark rings
    float lights = pow(sharp, 1.6);
    vec3 orbit = vec3(cos(ph * 9.0), sin(ph * 9.0), 0.0) * 0.6;
    float shimmer = 0.88 + 0.24 * vnoise(q * 260.0 + orbit);
    surf += vec3(1.0, 0.66, 0.28) * lights * 1.05 * uLight.z * shimmer * nightF * (1.0 - 0.8 * cloud);

    vec3 clc = vec3(0.95, 0.96, 0.99) * (sunCol * (0.04 + 0.96 * lamb) * dayF)
             + vec3(0.45, 0.55, 0.80) * night * 2.5;
    vec3 col = mix(surf, clc, cloud);

    // blue haze towards the limb; brighter on the day side and towards the Sun
    float haze = pow(1.0 - mu, 3.0);
    float toSun = pow(max(dot(rd, SUN), 0.0), 500.0) * flareAmount();
    col += mix(vec3(0.04, 0.12, 0.35), vec3(0.30, 0.78, 1.0), toSun) * haze
         * (0.03 + 1.4 * toSun + 0.35 * smoothstep(-0.05, 0.4, ndl) * uLight.y);
    return col;
}

// thin bright rim along the whole limb + soft outer glow
vec3 earthRim(vec3 rd, vec3 ec, float tca, float dmin) {
    if (tca <= 0.0) return vec3(0.0);
    float h = (dmin - PB_R) / PB_R;                            // >0 outside, <0 inside the disc
    float rimIn = h < 0.0 ? exp(h * 260.0) : 0.0;              // just inside the limb
    float rimOut = h >= 0.0 ? exp(-h * 220.0) : 0.0;           // thin bright line just outside
    float glow = h >= 0.0 ? exp(-h * 28.0) : exp(h * 25.0) * 0.4;
    vec3 limbN = normalize(rd * tca - ec);
    float lit = 0.45 + 0.55 * smoothstep(-0.5, 0.6, dot(limbN, earthLight()));
    float fwd = pow(max(dot(rd, SUN), 0.0), 300.0) * flareAmount();            // flare OFF / 0% -> even rim
    vec3 c = vec3(0.35, 0.72, 1.0) * (rimOut * 0.9 + rimIn * 0.5) + vec3(0.18, 0.45, 1.0) * glow * 0.30;
    return c * lit * (1.0 + 5.0 * fwd) * (0.25 + 0.75 * uLight.y);         // rim follows Earth light
}

// ===========================================================================
//  MOON (lit by the true Sun -> thin crescent on the lower-right)
// ===========================================================================
vec3 shadeMoon(vec3 rd, vec3 P, vec3 mc, float mr, float t, float pix) {
    vec3 N = normalize(P - mc);
    float fp = t * pix / mr;
    float mu = max(dot(N, -rd), 0.0);
    vec3 q = rotY(2.2) * rotX(0.15) * N;
    vec3 tex = toLinear(equirect(uMoonTex, q, fp, mu, 1024.0).rgb);
    // stronger crater contrast so the surface reads clearly even on the dark side
    float l = dot(tex, vec3(0.333));
    vec3 alb = mix(vec3(l), tex, 0.6) * (0.55 + 0.9 * smoothstep(0.05, 0.6, l));

    // crescent light: the real Sun, swung slightly towards the camera -> wider lower-right crescent
    vec3 L = uRealtime > 0.5 ? SUN : normalize(SUN + vec3(0.30, -0.05, 0.42));
    float ndl = dot(N, L);
    float ls = max(ndl, 0.0) / (max(ndl, 0.0) + mu + 1e-3) * 2.0;     // Lommel-Seeliger
    float crescent = ls * smoothstep(-0.02, 0.10, ndl);

    // earthshine: lights the whole disc (~25-35% brightness) so craters are visible everywhere
    vec3 toE = normalize(PB_C - mc);
    float es = 0.55 + 0.25 * max(dot(N, toE), 0.0);
    vec3 col = alb * (vec3(1.0, 0.97, 0.93) * 4.2 * crescent + vec3(0.62, 0.70, 0.86) * es * 0.55);

    // very subtle soft rim so the disc separates from the Milky Way
    col += vec3(0.55, 0.65, 0.85) * pow(1.0 - mu, 3.0) * 0.045;
    return col * uMoonBright;
}


// ===========================================================================
//  DRIFTING PLANETS  (enter -> cross very slowly -> exit, periodic in uPhase)
// ===========================================================================
// Each planet travels between two off-screen points A -> B (tangent-space screen coords,
// depth z) exactly f times per loop, so the wrap-around always happens off-screen.
// Depth also changes along the path, which changes size and depth-of-field blur.
struct Planet { vec2 a; vec2 b; vec2 z; float r; float f; float off; float kind; float spin; };

Planet planetDef(int i) {
    if (i == 0) return Planet(vec2(-0.42, 0.44), vec2(0.36, 0.20), vec2(300.0, 250.0), 7.0, 1.0, 0.08, 0.0, 3.0); // gas giant
    if (i == 1) return Planet(vec2(0.05, -0.80), vec2(-0.46, -0.30), vec2(430.0, 380.0), 8.0, 1.0, 0.52, 1.0, 4.0); // ringed
    if (i == 2) return Planet(vec2(-0.40, -0.10), vec2(0.10, 0.72), vec2(760.0, 700.0), 8.0, 1.0, 0.80, 2.0, 5.0); // ice giant
    return Planet(vec2(0.34, -0.58), vec2(-0.38, 0.10), vec2(160.0, 130.0), 1.3, 2.0, 0.30, 3.0, 2.0);             // red rocky
}

vec3 planetCentre(Planet p, float ph) {
    float u = fract(ph * 0.15915494 * p.f + p.off);
    vec2 s = mix(p.a, p.b, u);
    float z = mix(p.z.x, p.z.y, u);
    return vec3(s * z, -z);
}

vec3 shadePlanetSurface(float kind, vec3 N, vec3 q, float fp) {
    vec3 L = planetLight();
    float lat = q.y;
    vec3 alb;
    if (kind < 0.5) {            // Jupiter-like: warm bands, turbulence, a storm
        float w = fbm(q * 3.0 + 4.0, 5, fp * 3.0);
        float band = sin(lat * 12.0 + (w - 0.5) * 3.0);
        alb = mix(vec3(0.66, 0.52, 0.38), vec3(0.90, 0.84, 0.72), 0.5 + 0.35 * band);
        alb = mix(alb, vec3(0.55, 0.30, 0.20), smoothstep(0.6, 0.9, fbm(q * 9.0, 4, fp * 9.0)) * 0.35);
        float spot = exp(-dot(q - normalize(vec3(0.6, -0.35, 0.7)), q - normalize(vec3(0.6, -0.35, 0.7))) * 40.0);
        alb = mix(alb, vec3(0.75, 0.38, 0.25), spot * 0.8);
    } else if (kind < 1.5) {     // Saturn-like: pale gold, soft bands
        float w = fbm(q * 2.5 + 9.0, 4, fp * 2.5);
        float band = sin(lat * 14.0 + (w - 0.5) * 1.5);
        alb = mix(vec3(0.78, 0.68, 0.48), vec3(0.93, 0.86, 0.68), 0.5 + 0.5 * band);
    } else if (kind < 2.5) {     // Neptune-like: deep blue, faint streaks
        float w = fbm(q * 4.0 + 2.0, 4, fp * 4.0);
        alb = mix(vec3(0.16, 0.32, 0.72), vec3(0.32, 0.52, 0.90), 0.5 + 0.5 * sin(lat * 10.0 + w * 2.0));
        alb += vec3(0.5) * smoothstep(0.66, 0.8, fbm(q * vec3(6.0, 20.0, 6.0), 4, fp * 20.0)) * 0.4;
    } else {                     // Mars-like: rust, dark regions, polar cap
        float h = fbm(q * 3.5 + 1.0, 6, fp * 3.5);
        alb = mix(vec3(0.42, 0.18, 0.08), vec3(0.72, 0.36, 0.18), smoothstep(0.35, 0.65, h));
        alb = mix(alb, vec3(0.85, 0.85, 0.88), smoothstep(0.86, 0.92, abs(lat)));
    }
    float ndl = dot(N, L);
    float diff = max(ndl, 0.0);
    float limb = smoothstep(-0.05, 0.25, ndl);
    return toLinear(alb) * (vec3(1.0, 0.97, 0.93) * 1.7 * diff + vec3(0.25, 0.32, 0.45) * 0.012) * (0.4 + 0.6 * limb);
}

// Returns premultiplied colour + coverage of all drifting planets along this ray.
vec4 driftingPlanets(vec3 ro, vec3 rd, float pix, float ph) {
    vec3 col = vec3(0.0);
    float cover = 0.0;
    float focus = 60.0;                                         // camera focused on the Earth
    for (int i = 0; i < 4; i++) {
        Planet p = planetDef(i);
        vec3 c = planetCentre(p, ph);
        // depth-of-field: angular blur grows with distance behind the focal plane
        float blur = uPlanets.y * 0.30 * max(1.0 / focus - 1.0 / (-c.z), 0.0);
        float soft = pix + blur;
        // cheap reject (including a ring if present)
        vec3 oc = c - ro;
        float tc = dot(oc, rd);
        if (tc <= 0.0) continue;
        float reach = p.r * (p.kind > 0.5 && p.kind < 1.5 ? 2.4 : 1.0) + soft * tc * 2.0;
        if (length(oc - rd * tc) > reach) continue;

        float tca, dmin;
        vec2 hit = sphere(ro, rd, c, p.r, soft, tca, dmin);
        mat3 tilt = rotZ(0.3 + float(i) * 0.7) * rotX(0.35);
        vec4 layer = vec4(0.0);
        if (hit.y > 0.0) {
            vec3 N = normalize(ro + rd * hit.x - c);
            vec3 q = rotY(ph * p.spin) * (tilt * N);          // integer spins per loop -> seamless
            float fp = hit.x * soft / p.r;
            layer = vec4(shadePlanetSurface(p.kind, N, q, fp) * hit.y, hit.y);
        }
        if (p.kind > 0.5 && p.kind < 1.5) {                   // Saturn rings
            vec3 rn = normalize(transpose(tilt) * vec3(0.0, 1.0, 0.0));
            float dn = dot(rd, rn);
            if (abs(dn) > 1e-4) {
                float tr = dot(c - ro, rn) / dn;
                vec3 rp = ro + rd * tr - c;
                float rr = length(rp) / p.r;
                if (tr > 0.0 && rr > 1.25 && rr < 2.35) {
                    float bands = 0.55 + 0.45 * sin(rr * 55.0) * sin(rr * 13.0 + 1.0);
                    float gap = smoothstep(0.0, 0.03, abs(rr - 1.95) - 0.035);       // Cassini division
                    float edge = smoothstep(1.25, 1.32, rr) * smoothstep(2.35, 2.25, rr);
                    float a = clamp(bands * gap * edge * 0.85, 0.0, 1.0);
                    vec3 L = planetLight();
                    // planet shadow on the rings
                    vec3 toL = L;
                    float b2 = dot(-rp, toL);
                    float shadow = (b2 > 0.0 && length(-rp - toL * b2) < p.r) ? 0.15 : 1.0;
                    vec3 rc = toLinear(vec3(0.86, 0.78, 0.60)) * (0.25 + 1.4 * abs(dot(L, rn))) * shadow;
                    bool inFront = hit.y <= 0.0 || tr < hit.x;
                    if (inFront) layer = vec4(rc * a, a) + layer * (1.0 - a);
                    else layer += vec4(rc * a, a) * (1.0 - layer.a);
                }
            }
        }
        col = col * (1.0 - layer.a) + layer.rgb;            // later (closer) planets over earlier
        cover = cover + layer.a * (1.0 - cover);
    }
    return vec4(col, cover);
}


// ===========================================================================
//  METEORS (scheduled on the CPU by Meteors.java: random times/directions, periodic loop)
//  Each pixel only tests the (max 2) meteors that are actually flying right now.
// ===========================================================================
vec3 meteor(vec2 sp, vec4 m, float len, float pix) {
    if (m.w <= 0.0) return vec3(0.0);
    vec2 dir = vec2(cos(m.z), sin(m.z));
    vec2 dp = sp - m.xy;
    float along = dot(dp, -dir);                              // distance behind the head
    if (along < -pix * 3.0 || along > len) return vec3(0.0);
    float across = abs(dot(dp, vec2(-dir.y, dir.x)));
    if (across > pix * 6.0) return vec3(0.0);
    float w = pix * 0.9;
    float tail = clamp(1.0 - along / len, 0.0, 1.0);
    float core = exp(-across * across / (w * w)) * tail * tail;
    float headGlow = exp(-dot(dp, dp) / (w * w * 4.0));
    return vec3(0.85, 0.92, 1.0) * (core * 0.9 + headGlow * 1.2) * m.w;
}

vec3 meteors(vec3 rd, float pix) {
    if (uMeteorA.w <= 0.0 && uMeteorB.w <= 0.0) return vec3(0.0);
    vec2 sp = rd.xy / max(-rd.z, 0.05);                      // sky position in tangent units
    return meteor(sp, uMeteorA, uMeteorLen.x, pix) + meteor(sp, uMeteorB, uMeteorLen.y, pix);
}

void main() {
    vec2 uv = gl_FragCoord.xy / uRes * 2.0 - 1.0;
    float aspect = uRes.x / uRes.y;
    float ph = uPhase;
    float pix = 2.0 * TAN_V / uRes.y;

    // slow cinematic camera rotation + gyroscope rotation (affects every layer equally)
    float drift = uToggles.z;
    float yaw   = drift * (0.008 * sin(ph * 2.0) + 0.004 * sin(ph * 5.0 + 1.0)) + uCam.x;
    float pitch = drift * (0.006 * sin(ph * 3.0 + 0.5)) + uCam.y;
    float roll  = drift * 0.005 * sin(ph * 2.0 + 2.0);
    vec3 ro = vec3(0.0);
    vec3 rd = normalize(vec3(uv.x * TAN_V * aspect, uv.y * TAN_V, -1.0));
    rd = rotY(yaw) * rotX(pitch) * rotZ(roll) * rd;

    // per-layer parallax: stars / Milky Way move least, Moon more, Earth most
    vec2 sh = uCam.zw;
    vec3 ec = PB_C + vec3(sh * PL_PARALLAX_EARTH, 0.0)
            + drift * vec3(0.35 * sin(ph * 2.0 + 0.3), 0.25 * sin(ph * 3.0), 0.0);

    float bTca, bD;
    vec2 pb = sphere(ro, rd, ec, PB_R, pix, bTca, bD);

    // ---- sky ----
    vec3 col = vec3(0.0006, 0.0010, 0.0032);
    if (pb.y < 1.0) {
        col += bakedSky(rd, ph);
        col += meteors(rd, pix);
        if (uPlanets.x > 0.5) {
            vec4 pl = driftingPlanets(ro, rd, pix, ph);
            col = col * (1.0 - pl.a) + pl.rgb;
        }
    }

    // ---- Moon (in front of the Milky Way) ----
    float moonCover = 0.0;
    if (uMoon.w > 0.5) {
        vec3 md = screenDir(uMoon.xy);
        vec3 mc = md * MOON_DIST + vec3(sh * PL_PARALLAX_MOON, 0.0)
                + vec3(0.30 * sin(ph), 0.15 * sin(ph * 2.0 + 1.0), 0.0);
        float mr = MOON_R0 * uMoon.z;
        float mTca, mD;
        vec2 mo = sphere(ro, rd, mc, mr, pix * 1.8, mTca, mD);         // slightly soft edge
        if (mo.y > 0.0) {
            col = mix(col, shadeMoon(rd, rd * mo.x, mc, mr, mo.x, pix), mo.y);
            moonCover = mo.y;
        }
    }

    // ---- Earth ----
    if (pb.y > 0.0) {
        vec3 P = rd * pb.x;
        col = mix(col, shadeEarth(rd, P, ec, pb.x, pix, ph), pb.y);
    }
    col += earthRim(rd, ec, bTca, bD) * (1.0 - moonCover);

    // ---- sunrise flare: starburst on the limb + full-width anamorphic streak ----
    vec3 flareCol = vec3(0.0);
    if (flareAmount() > 0.0) {
        float breathe = 0.80 + 0.20 * sin(ph * 16.0) + 0.06 * sin(ph * 37.0);
        vec3 sc = ec;
        float limbAng = asin(clamp(PB_R / length(sc), 0.0, 1.0));
        float sunOff = acos(clamp(dot(normalize(sc), SUN), -1.0, 1.0));
        float vis = clamp((sunOff - limbAng + SUN_ANG) / (2.0 * SUN_ANG), 0.0, 1.0);
        float leak = exp(-max(limbAng - sunOff, 0.0) / 0.02);
        float glow = (0.40 * leak + 0.60 * vis) * breathe * step(0.0, dot(rd, SUN));
        vec3 dv = rd - SUN;
        float x = dv.x, y = dv.y;
        float a = length(cross(rd, SUN));
        vec3 flare = vec3(0.30, 0.70, 1.0) * glow * (0.30 * exp(-a / 0.08) + 0.04 * exp(-a / 0.3));
        if (a < 0.25) {                                          // starburst: only near the Sun (terms < 1e-4 beyond)
            float th = atan(y, x);
            float rays = pow(abs(cos(th * 4.0)), 40.0) * exp(-a / 0.025) * 0.6
                       + pow(abs(cos(th * 4.0 + 0.39)), 60.0) * exp(-a / 0.015) * 0.35;
            flare += vec3(1.0, 0.98, 0.95) * vis * 6.0 * smoothstep(SUN_ANG * 1.3, SUN_ANG * 0.6, a) * (1.0 - pb.y)
                   + vec3(0.95, 0.98, 1.0) * glow * (2.6 * exp(-a / 0.008) + 0.9 * exp(-a / 0.03) + rays);
        }
        if (abs(y) < 0.06) {                                     // anamorphic streak: one thin line
            float streak = exp(-abs(y) / 0.0022) * (0.75 * exp(-abs(x) / 0.30) + 0.35 * exp(-abs(x) / 0.06));
            streak += exp(-abs(y) / 0.008) * exp(-abs(x) / 0.12) * 0.15;
            flare += vec3(0.45, 0.75, 1.0) * streak * glow * 1.3;
        }
        flareCol = flare * flareAmount();                 // intensity slider (also scales its bloom)
        col += flareCol;
    }

    // filmic tone-map + gamma (bloom, grain and dithering are applied in composite.frag)
    col = 1.0 - exp(-col * 1.15);
    col = pow(col, vec3(1.0 / 2.2));
    // alpha = post-processing mask: 1 in space, 0.3 on the Earth disc (and Moon).
    // composite.frag uses it to keep grain off the globe; bright.frag uses it so city lights only
    // get a faint halo. Flare pixels keep full bloom.
    float body = max(pb.y, moonCover);
    float flareLum = clamp(dot(flareCol, vec3(0.3333)) * 2.0, 0.0, 1.0);
    fragColor = vec4(col, 1.0 - 0.7 * body * (1.0 - flareLum));
}
