#version 300 es
// ---------------------------------------------------------------------------
//  Deep Space live wallpaper - scene shader
//  Hybrid approach: analytic ray/sphere geometry (real 3D parallax) +
//  a small pre-generated 3D noise texture for all surface / cloud detail.
//
//  SEAMLESS LOOP: every animated quantity is a periodic function of uPhase
//  (0..2PI) with integer frequencies, so phase 2PI == phase 0 exactly.
//  The CPU advances the phase continuously and wraps it, so there is never
//  a jump, fade, or restart.
// ---------------------------------------------------------------------------
precision highp float;
precision highp int;

uniform mediump sampler3D uNoise;
uniform mediump sampler2D uEarthDay;   // NASA Blue Marble colour map (equirectangular)
uniform mediump sampler2D uEarthAux;   // R clouds, G night lights, B land mask
uniform mediump sampler2D uMoonTex;    // lunar colour map
uniform vec2  uRes;       // render-target size in pixels
uniform float uPhase;     // 0..2PI
uniform vec4  uCam;       // x: yaw  y: pitch  (radians)  z,w: lateral shift (scene units)
uniform int   uOct;       // max fbm octaves (quality level)
uniform vec4  uToggles;   // x: stars on/off  y: spacecraft on/off  z: auto camera drift amount

out vec4 fragColor;

const float TAN_V = 0.62;                       // tan(half vertical FOV)

// ---- scene layout (camera space, camera looks down -Z) ----
const vec3  SUN    = vec3(0.5257, -0.0678, -0.8480); // normalized; sun is off-screen right, just above the near horizon
const vec3  SUN_PB = vec3(0.7806, -0.2927, 0.5529); // key light on the hero planet: from lower-right / in front
const vec3  SUN_FG = vec3(0.6247, 0.4165, -0.6609); // key light used for the near planet surface (artistic)
const vec3  PB_C   = vec3(10.5, 12.8, -60.0);   // hero planet
const float PB_R   = 23.0;
const vec3  FG_C   = vec3(26.43, -35.26, -13.22); // huge planet we are orbiting (horizon at bottom)
const float FG_R   = 40.0;
const vec3  MOON_C = vec3(-4.9, -1.0, -40.0);
const float MOON_R = 1.45;
const vec3  SAT_P  = vec3(4.9, 2.6, -21.0);

// ---------------------------------------------------------------------------
float vnoise(vec3 p) { return texture(uNoise, p * (1.0 / 24.0)).r; }

const mat3 OCT = mat3( 0.00,  0.80,  0.60,
                      -0.80,  0.36, -0.48,
                      -0.60, -0.48,  0.64);

// fbm with footprint-based LOD (avoids shimmering of sub-pixel detail)
float fbm(vec3 p, int oct, float footprint) {
    float s = 0.0, a = 0.5, n = 0.0, f = footprint;
    for (int i = 0; i < 8; i++) {
        if (i >= oct) break;
        float fade = clamp(2.0 - f * 3.0, 0.0, 1.0);  // fade out octaves near pixel size
        if (fade <= 0.0) break;
        s += a * fade * vnoise(p);
        n += a * fade;
        p = OCT * p * 2.03;
        f *= 2.03;
        a *= 0.5;
    }
    return n > 0.0 ? s / n : 0.5;
}

float ridged(vec3 p, int oct, float footprint) {
    float s = 0.0, a = 0.5, n = 0.0, f = footprint;
    for (int i = 0; i < 6; i++) {
        if (i >= oct) break;
        float fade = clamp(2.0 - f * 3.0, 0.0, 1.0);
        if (fade <= 0.0) break;
        float v = 1.0 - abs(vnoise(p) * 2.0 - 1.0);
        s += a * fade * v * v;
        n += a * fade;
        p = OCT * p * 2.07;
        f *= 2.07;
        a *= 0.5;
    }
    return n > 0.0 ? s / n : 0.0;
}

mat3 rotY(float a) { float c = cos(a), s = sin(a); return mat3(c, 0.0, -s, 0.0, 1.0, 0.0, s, 0.0, c); }
mat3 rotX(float a) { float c = cos(a), s = sin(a); return mat3(1.0, 0.0, 0.0, 0.0, c, s, 0.0, -s, c); }
mat3 rotZ(float a) { float c = cos(a), s = sin(a); return mat3(c, s, 0.0, -s, c, 0.0, 0.0, 0.0, 1.0); }

uvec3 pcg3(uvec3 v) {
    v = v * 1664525u + 1013904223u;
    v.x += v.y * v.z; v.y += v.z * v.x; v.z += v.x * v.y;
    v ^= v >> 16u;
    v.x += v.y * v.z; v.y += v.z * v.x; v.z += v.x * v.y;
    return v;
}
vec3 hash33(vec3 p) { return vec3(pcg3(uvec3(ivec3(floor(p)) + 65536))) * (1.0 / 4294967295.0); }

// Sphere test with analytic anti-aliased coverage of the limb.
// returns (tEntry, coverage); tca = distance to closest approach, dmin = closest distance to centre
vec2 sphere(vec3 ro, vec3 rd, vec3 c, float r, float pix, out float tca, out float dmin) {
    vec3 oc = c - ro;
    tca = dot(oc, rd);
    dmin = length(oc - rd * tca);
    if (tca <= 0.0) return vec2(-1.0, 0.0);
    float cov = clamp((r - dmin) / (tca * pix) + 0.5, 0.0, 1.0);
    float h = r * r - dmin * dmin;
    return vec2(tca - sqrt(max(h, 0.0)), cov);
}

// Single-scattering style atmosphere approximation (additive light along the ray)
vec3 atmosphere(vec3 ro, vec3 rd, vec3 c, float r, float tca, float dmin,
                float scaleH, vec3 tint, float strength, vec3 L) {
    if (tca <= 0.0) return vec3(0.0);
    float x = (dmin - r) / (scaleH * r);
    float dens;
    if (x > 0.0) {
        dens = exp(-x);
    } else {
        float mu = sqrt(max(1.0 - (dmin / r) * (dmin / r), 0.0)); // 0 at limb .. 1 at disc centre
        dens = exp(-mu * 9.0);
    }
    vec3 limbN = normalize(ro + rd * tca - c);
    float lit = smoothstep(-0.35, 0.55, dot(limbN, L));
    float fwd = pow(max(dot(rd, L), 0.0), 5.0);
    return tint * dens * strength * lit * (0.35 + 3.0 * fwd);
}

// ---------------------------------------------------------------------------
// Equirectangular lookup with explicit LOD (no derivatives => no seam line, safe in branches)
vec4 equirect(sampler2D tex, vec3 d, float footprint, float mu, float texW) {
    float u = atan(d.x, d.z) * 0.15915494 + 0.5;
    float v = acos(clamp(d.y, -1.0, 1.0)) * 0.31830989;
    float lod = log2(max(footprint * texW * 0.15915494, 1e-4)) + 0.5 * log2(1.0 / max(mu, 0.06));
    return textureLod(tex, vec2(u, v), max(lod, 0.0));
}

vec3 toLinear(vec3 c) { return c * c * (c * 0.3 + 0.7); }    // cheap sRGB -> linear

vec3 shadeHeroPlanet(vec3 ro, vec3 rd, vec3 P, float t, float pix, float ph) {
    // Real Earth: NASA day map + clouds + night lights, physically-motivated lighting.
    vec3 N = normalize(P - PB_C);
    float fp = t * pix / PB_R;                          // pixel footprint on the unit sphere
    float mu = max(dot(N, -rd), 0.0);
    mat3 tilt = rotZ(0.41) * rotX(0.30);                // axial tilt towards the camera
    vec3 n0 = tilt * N;
    vec3 q = rotY(-ph) * n0;                            // 1 full rotation per loop (west -> east)
    float ca = -ph - 0.08 * sin(ph);                    // clouds drift relative to the ground
    vec3 cq = rotY(ca) * n0;

    vec3 day = toLinear(equirect(uEarthDay, q, fp, mu, 4096.0).rgb);
    vec3 aux = equirect(uEarthAux, q, fp, mu, 2048.0).rgb;
    float cloud = equirect(uEarthAux, cq, fp, mu, 2048.0).r;
    float land = smoothstep(0.3, 0.7, aux.b);
    float lights = aux.g;

    // Blue Marble oceans are flat and bright: deepen them, keep coastal shallows
    vec3 alb = mix(day * vec3(0.35, 0.45, 0.62), day, land);
    cloud = smoothstep(0.08, 0.85, cloud);

    float ndl = dot(N, SUN_PB);
    float lamb = max(ndl, 0.0);
    float day01 = smoothstep(-0.08, 0.18, ndl);
    vec3 sunCol = vec3(1.0, 0.97, 0.92) * 3.2;
    vec3 amb = vec3(0.20, 0.30, 0.45) * 0.010;

    vec3 surf = alb * (sunCol * lamb + amb);
    // ocean specular: broad sheen + sharp sun glint
    vec3 hv = normalize(SUN_PB - rd);
    float nh = max(dot(N, hv), 0.0);
    float fres = 0.02 + 0.98 * pow(1.0 - mu, 5.0);
    float spec = (pow(nh, 400.0) * 3.0 + pow(nh, 40.0) * 0.25) * fres * 4.0;
    surf += vec3(1.0, 0.95, 0.88) * spec * (1.0 - land) * lamb * (1.0 - cloud);
    surf *= 1.0 - 0.45 * cloud;                                       // cloud shadows

    // city lights on the night side (under the clouds)
    float night = 1.0 - smoothstep(-0.20, 0.05, ndl);
    surf += vec3(1.0, 0.70, 0.38) * pow(lights, 1.8) * 0.20 * night * (1.0 - 0.8 * cloud);

    // clouds: bright on the day side, soft forward-lit edge near the terminator
    vec3 cl = vec3(0.95, 0.96, 0.98) * (sunCol * (0.04 + 0.96 * lamb) * day01 + amb * 2.0);
    vec3 col = mix(surf, cl, cloud);

    // Rayleigh-like blue haze towards the limb on the day side
    float haze = pow(1.0 - mu, 3.0);
    col = mix(col, vec3(0.28, 0.52, 1.0) * sunCol * 0.20 * smoothstep(-0.15, 0.5, ndl), haze * 0.55);
    col += vec3(0.10, 0.20, 0.42) * 0.08 * day01 * (1.0 - mu);
    return col;
}

vec3 shadeFgPlanet(vec3 ro, vec3 rd, vec3 P, float t, float pix, float ph) {
    vec3 N = normalize(P - FG_C);
    float fp = t * pix / FG_R;
    mat3 tilt = rotX(0.9) * rotZ(-0.4);
    vec3 q = rotY(ph) * (tilt * N);                     // surface rotation (1 turn / loop)

    int o = uOct + 1;
    float h = fbm(q * 9.0 + 3.0, o, fp * 9.0);
    float land = smoothstep(0.47, 0.53, h);
    float det = fbm(q * 40.0, max(o - 2, 1), fp * 40.0);
    vec3 alb = mix(vec3(0.010, 0.050, 0.130),
                   mix(vec3(0.08, 0.13, 0.05), vec3(0.36, 0.30, 0.20), smoothstep(0.35, 0.65, det)), land);

    float ca = ph + 0.07 * sin(ph);                    // clouds drift relative to ground
    vec3 cq = rotY(ca) * (tilt * N);
    vec3 evo = 0.5 * vec3(cos(ph * 3.0), 0.0, sin(ph * 3.0));
    float c = fbm(cq * 30.0 + evo, o + 1, fp * 30.0);
    float cloud = smoothstep(0.47, 0.60, c);
    float thick = smoothstep(0.56, 0.70, c);

    float ndl = dot(N, SUN_FG);
    float day = smoothstep(-0.25, 0.30, ndl);
    vec3 sunCol = vec3(1.0, 0.96, 0.90) * 2.2;
    vec3 amb = vec3(0.25, 0.40, 0.65) * 0.01;
    vec3 ground = alb * (sunCol * max(ndl + 0.15, 0.0) * day + amb) * (1.0 - 0.6 * cloud);
    vec3 cl = mix(vec3(0.75, 0.80, 0.88), vec3(0.95, 0.96, 1.0), thick)
              * (sunCol * (0.30 + 0.7 * max(ndl + 0.2, 0.0)) * day + amb * 3.0);
    vec3 col = mix(ground, cl, cloud);

    float mu = max(dot(N, -rd), 0.0);
    float haze = pow(1.0 - mu, 8.0);
    col = mix(col, vec3(0.55, 0.75, 1.0) * (0.05 + 1.8 * day), clamp(haze * 0.9, 0.0, 1.0));
    return col;
}

vec3 shadeMoon(vec3 rd, vec3 P, vec3 mc, float t, float pix) {
    vec3 N = normalize(P - mc);
    float fp = t * pix / MOON_R;
    float mu = max(dot(N, -rd), 0.0);
    vec3 q = rotY(2.2) * rotX(0.15) * N;
    vec3 alb = toLinear(equirect(uMoonTex, q, fp, mu, 1024.0).rgb) * 0.42;
    float ndl = dot(N, SUN_PB);
    float bounce = max(dot(N, normalize(FG_C - mc)), 0.0);
    // Lommel-Seeliger-ish lunar reflectance: flatter than Lambert, looks like the real Moon
    float ls = max(ndl, 0.0) / (max(ndl, 0.0) + mu + 1e-3) * 2.0;
    vec3 light = vec3(1.0, 0.97, 0.93) * 2.6 * ls + vec3(0.3, 0.42, 0.6) * (0.02 + 0.12 * bounce);
    return alb * light;
}

// tiny, distant satellite - signed-distance silhouette oriented to the view
vec4 spacecraft(vec3 ro, vec3 rd, vec3 sp, float pix, float ph) {
    vec3 v = sp - ro;
    float t = dot(v, rd);
    if (t <= 0.0) return vec4(0.0);
    vec3 fwd = normalize(v);
    if (dot(rd, fwd) < 0.9995) return vec4(0.0);       // cheap early out
    vec3 e1 = normalize(cross(fwd, vec3(0.0, 1.0, 0.0)));
    vec3 e2 = cross(e1, fwd);
    vec3 off = ro + rd * t - sp;
    vec2 p = vec2(dot(off, e1), dot(off, e2));
    float roll = -0.45 + 0.12 * sin(ph);
    float cs = cos(roll), sn = sin(roll);
    p = mat2(cs, sn, -sn, cs) * p;
    float pw = t * pix;

    vec2 dBody = abs(p) - vec2(0.055, 0.045);
    float body = length(max(dBody, 0.0)) + min(max(dBody.x, dBody.y), 0.0);
    vec2 pp = vec2(abs(p.x) - 0.25, p.y);
    vec2 dPan = abs(pp) - vec2(0.15, 0.042);
    float panel = length(max(dPan, 0.0)) + min(max(dPan.x, dPan.y), 0.0);
    vec2 dStr = abs(p) - vec2(0.12, 0.006);
    float strut = length(max(dStr, 0.0)) + min(max(dStr.x, dStr.y), 0.0);

    float aBody = clamp(0.5 - body / pw, 0.0, 1.0);
    float aPan = clamp(0.5 - panel / pw, 0.0, 1.0);
    float aStr = clamp(0.5 - strut / pw, 0.0, 1.0) * 0.8;
    float a = max(max(aBody, aPan), aStr);
    if (a <= 0.0) return vec4(0.0);

    float glint = pow(max(sin(ph * 5.0 + 1.3), 0.0), 24.0);  // occasional soft solar-panel glint
    vec3 cPan = vec3(0.10, 0.13, 0.18) + vec3(0.9, 0.95, 1.0) * glint * 0.9;
    vec3 cBody = vec3(0.55, 0.55, 0.53);
    vec3 col = aBody > 0.0 ? mix(cPan, cBody, aBody / max(a, 1e-4)) : cPan;
    col = mix(col, vec3(0.35), aStr * (1.0 - aPan) * (1.0 - aBody));
    return vec4(col * 1.4, a);
}

vec3 starfield(vec3 d, float pix, float ph) {
    vec3 col = vec3(0.0);
    for (int l = 0; l < 3; l++) {
        float S = l == 0 ? 60.0 : (l == 1 ? 150.0 : 340.0);
        float dens = l == 0 ? 0.10 : (l == 1 ? 0.10 : 0.12);
        vec3 q = d * S;
        vec3 h = hash33(q + float(l) * 71.0);
        if (h.x > dens) continue;
        vec3 sp = floor(q) + 0.2 + 0.6 * hash33(q + 13.0 + float(l) * 29.0);
        vec3 sdir = normalize(sp);
        float ang = length(cross(d, sdir));
        float size = pix * (l == 0 ? 1.1 : 0.8);
        float b = exp(-ang * ang / (size * size));
        float mag = l == 0 ? 0.55 : (l == 1 ? 0.22 : 0.10);
        mag *= pow(h.y, 2.0) + 0.15;
        float k = floor(10.0 + h.z * 30.0);           // integer -> periodic twinkle
        mag *= 0.8 + 0.2 * sin(ph * k + h.y * 6.2831);
        vec3 tint = mix(vec3(0.75, 0.85, 1.0), vec3(1.0, 0.92, 0.80), fract(h.y * 7.0));
        col += tint * b * mag;
    }
    return col;
}

void main() {
    vec2 uv = gl_FragCoord.xy / uRes * 2.0 - 1.0;
    float aspect = uRes.x / uRes.y;
    float ph = uPhase;
    float pix = 2.0 * TAN_V / uRes.y;                   // angular size of one pixel

    // ---- slow cinematic camera: small periodic orbit + sensor/home-screen parallax ----
    float drift = uToggles.z;
    float yaw   = drift * (0.018 * sin(ph * 2.0) + 0.008 * sin(ph * 5.0 + 1.0)) + uCam.x;
    float pitch = drift * (0.012 * sin(ph * 3.0 + 0.5)) + uCam.y;
    float roll  = drift * 0.010 * sin(ph * 2.0 + 2.0);
    vec3 ro = vec3(uCam.z, uCam.w, 0.0)
            + drift * vec3(0.55 * sin(ph * 2.0 + 0.3), 0.30 * sin(ph * 3.0), 0.8 * sin(ph + 1.0));
    vec3 rd = normalize(vec3(uv.x * TAN_V * aspect, uv.y * TAN_V, -1.0));
    rd = rotY(yaw) * rotX(pitch) * rotZ(roll) * rd;

    // ---- moving bodies (periodic) ----
    vec3 moonC = MOON_C + vec3(1.6 * sin(ph), 0.5 * sin(ph) - 0.25 * cos(ph * 2.0), 2.0 * cos(ph));
    vec3 satP = SAT_P + vec3(0.9 * sin(ph * 2.0), 0.45 * sin(ph * 3.0 + 1.0), 0.0);

    // ---- visibility (front-most first, to skip hidden work) ----
    float fTca, fD, bTca, bD, mTca, mD;
    vec2 fg = sphere(ro, rd, FG_C, FG_R, pix, fTca, fD);
    vec2 pb = sphere(ro, rd, PB_C, PB_R, pix, bTca, bD);
    vec2 mo = sphere(ro, rd, moonC, MOON_R, pix, mTca, mD);

    vec3 col = vec3(0.0);
    float cover = fg.y;                                  // how much of the pixel the near planet hides

    if (cover < 1.0) {
        // background: deep space, faint blue haze near the lit horizon, stars
        vec3 bg = vec3(0.0015, 0.0025, 0.006);
        bg += vec3(0.02, 0.06, 0.12) * pow(max(dot(rd, SUN), 0.0), 12.0) * 0.5;
        if (uToggles.x > 0.5) bg += starfield(rd, pix, ph) * (1.0 - pb.y);
        col = bg;

        if (pb.y > 0.0) {
            vec3 P = ro + rd * pb.x;
            col = mix(col, shadeHeroPlanet(ro, rd, P, pb.x, pix, ph), pb.y);
        }
        col += atmosphere(ro, rd, PB_C, PB_R, bTca, bD, 0.016, vec3(0.35, 0.62, 1.0), 1.4, SUN_PB);

        if (mo.y > 0.0) {
            vec3 P = ro + rd * mo.x;
            col = mix(col, shadeMoon(rd, P, moonC, mo.x, pix), mo.y);
        }
        if (uToggles.y > 0.5) {
            vec4 s = spacecraft(ro, rd, satP, pix, ph);
            col = mix(col, s.rgb, s.a);
        }
    }

    if (cover > 0.0) {
        vec3 P = ro + rd * fg.x;
        col = mix(col, shadeFgPlanet(ro, rd, P, fg.x, pix, ph), cover);
    }
    // near-planet atmosphere: the bright glowing horizon line
    col += atmosphere(ro, rd, FG_C, FG_R, fTca, fD, 0.010, vec3(0.55, 0.78, 1.0), 2.4, SUN);
    col += atmosphere(ro, rd, FG_C, FG_R, fTca, fD, 0.0025, vec3(0.85, 0.93, 1.0), 6.0, SUN);
    col += atmosphere(ro, rd, FG_C, FG_R, fTca, fD, 0.035, vec3(0.20, 0.45, 0.85), 0.8, SUN);

    // very subtle lens glow from the (off-screen) sun - breathes with the camera
    float sd = max(dot(rd, SUN), 0.0);
    col += vec3(0.85, 0.92, 1.0) * (0.12 * pow(sd, 90.0) + 0.02 * pow(sd, 22.0));

    // filmic tonemap + gamma + dither (prevents banding in dark gradients)
    col = 1.0 - exp(-col * 1.1);
    col = pow(col, vec3(1.0 / 2.2));
    float dn = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    col += (dn - 0.5) / 255.0;
    fragColor = vec4(col, 1.0);
}
