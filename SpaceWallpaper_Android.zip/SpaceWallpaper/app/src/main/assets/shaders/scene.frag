#version 300 es
// ---------------------------------------------------------------------------
//  Deep Space live wallpaper - "Earth sunrise" scene
//  Earth (NASA maps) seen from its night side, the Sun rising behind the limb,
//  and the Milky Way across the sky.
//
//  SEAMLESS LOOP: every animated quantity is a periodic function of uPhase
//  (0..2PI) with integer frequencies; the CPU advances and wraps the phase,
//  so there is never a jump, fade or restart.
// ---------------------------------------------------------------------------
precision highp float;
precision highp int;

uniform mediump sampler3D uNoise;
uniform mediump sampler2D uEarthDay;   // NASA Blue Marble colour map (equirectangular)
uniform mediump sampler2D uEarthAux;   // R clouds, G night lights, B land mask
uniform vec2  uRes;
uniform float uPhase;
uniform vec4  uCam;       // x yaw, y pitch, z/w lateral shift
uniform int   uOct;
uniform vec4  uToggles;   // x stars, z camera drift amount

out vec4 fragColor;

const float TAN_V = 0.62;

// ---- scene layout (camera space, camera looks down -Z) ----
const vec3  PB_C  = vec3(39.65511, -1.20167, -60.08351);  // Earth centre (fills the right side)
const float PB_R  = 40.654;
const vec3  SUN   = vec3(0.00030, -0.16330, -0.98658);    // just behind Earth's left limb
const float SUN_ANG = 0.0047;                             // real angular radius of the Sun
const vec3  MW_N  = vec3(-0.95240, 0.23444, 0.19488);     // Milky Way plane normal
const vec3  MW_A  = vec3(-0.01600, 0.59992, -0.79990);    // towards the bright galactic core
const vec3  MW_B  = vec3(-0.30444, -0.76494, -0.56762);
// Moon: far behind Earth in the upper-left sky, lit by the same Sun -> thin crescent
const vec3  MOON_DIR  = vec3(-0.166, 0.318, -0.934);   // base direction (camera space)
const float MOON_DIST = 300.0;
const float MOON_R    = 9.0;                            // ~1.7 deg on screen (stylised)

float vnoise(vec3 p) { return texture(uNoise, p * (1.0 / 24.0)).r; }

const mat3 OCT = mat3( 0.00,  0.80,  0.60,
                      -0.80,  0.36, -0.48,
                      -0.60, -0.48,  0.64);

// fbm with footprint-based LOD (avoids shimmering of sub-pixel detail)
float fbm(vec3 p, int oct, float footprint) {
    float s = 0.0, a = 0.5, n = 0.0, f = footprint;
    for (int i = 0; i < 8; i++) {
        if (i >= oct) break;
        float fade = clamp(2.0 - f * 3.0, 0.0, 1.0);  // fade out octaves near pixel size
        if (fade <= 0.0) break;
        s += a * fade * vnoise(p);
        n += a * fade;
        p = OCT * p * 2.03;
        f *= 2.03;
        a *= 0.5;
    }
    return n > 0.0 ? s / n : 0.5;
}

float ridged(vec3 p, int oct, float footprint) {
    float s = 0.0, a = 0.5, n = 0.0, f = footprint;
    for (int i = 0; i < 6; i++) {
        if (i >= oct) break;
        float fade = clamp(2.0 - f * 3.0, 0.0, 1.0);
        if (fade <= 0.0) break;
        float v = 1.0 - abs(vnoise(p) * 2.0 - 1.0);
        s += a * fade * v * v;
        n += a * fade;
        p = OCT * p * 2.07;
        f *= 2.07;
        a *= 0.5;
    }
    return n > 0.0 ? s / n : 0.0;
}

mat3 rotY(float a) { float c = cos(a), s = sin(a); return mat3(c, 0.0, -s, 0.0, 1.0, 0.0, s, 0.0, c); }
mat3 rotX(float a) { float c = cos(a), s = sin(a); return mat3(1.0, 0.0, 0.0, 0.0, c, s, 0.0, -s, c); }
mat3 rotZ(float a) { float c = cos(a), s = sin(a); return mat3(c, s, 0.0, -s, c, 0.0, 0.0, 0.0, 1.0); }

uvec3 pcg3(uvec3 v) {
    v = v * 1664525u + 1013904223u;
    v.x += v.y * v.z; v.y += v.z * v.x; v.z += v.x * v.y;
    v ^= v >> 16u;
    v.x += v.y * v.z; v.y += v.z * v.x; v.z += v.x * v.y;
    return v;
}
vec3 hash33(vec3 p) { return vec3(pcg3(uvec3(ivec3(floor(p)) + 65536))) * (1.0 / 4294967295.0); }

// Sphere test with analytic anti-aliased coverage of the limb.
// returns (tEntry, coverage); tca = distance to closest approach, dmin = closest distance to centre
vec2 sphere(vec3 ro, vec3 rd, vec3 c, float r, float pix, out float tca, out float dmin) {
    vec3 oc = c - ro;
    tca = dot(oc, rd);
    dmin = length(oc - rd * tca);
    if (tca <= 0.0) return vec2(-1.0, 0.0);
    float cov = clamp((r - dmin) / (tca * pix) + 0.5, 0.0, 1.0);
    float h = r * r - dmin * dmin;
    return vec2(tca - sqrt(max(h, 0.0)), cov);
}

// Single-scattering style atmosphere approximation (additive light along the ray)
vec3 atmosphere(vec3 ro, vec3 rd, vec3 c, float r, float tca, float dmin,
                float scaleH, vec3 tint, float strength, vec3 L) {
    if (tca <= 0.0) return vec3(0.0);
    float x = (dmin - r) / (scaleH * r);
    float dens;
    if (x > 0.0) {
        dens = exp(-x);
    } else {
        float mu = sqrt(max(1.0 - (dmin / r) * (dmin / r), 0.0)); // 0 at limb .. 1 at disc centre
        dens = exp(-mu * 9.0);
    }
    vec3 limbN = normalize(ro + rd * tca - c);
    float lit = smoothstep(-0.35, 0.55, dot(limbN, L));
    float fwd = pow(max(dot(rd, L), 0.0), 400.0);
    return tint * dens * strength * lit * (0.30 + 6.0 * fwd);
}

// ---------------------------------------------------------------------------
// Equirectangular lookup with explicit LOD (no derivatives => no seam line, safe in branches)
vec4 equirect(sampler2D tex, vec3 d, float footprint, float mu, float texW) {
    float u = atan(d.x, d.z) * 0.15915494 + 0.5;
    float v = acos(clamp(d.y, -1.0, 1.0)) * 0.31830989;
    float lod = log2(max(footprint * texW * 0.15915494, 1e-4)) + 0.5 * log2(1.0 / max(mu, 0.06));
    return textureLod(tex, vec2(u, v), max(lod, 0.0));
}

vec3 toLinear(vec3 c) { return c * c * (c * 0.3 + 0.7); }    // cheap sRGB -> linear

vec3 starfield(vec3 d, float pix, float ph, float band) {
    vec3 col = vec3(0.0);
    for (int l = 0; l < 3; l++) {
        float S = l == 0 ? 60.0 : (l == 1 ? 150.0 : 340.0);
        float dens = (l == 0 ? 0.10 : (l == 1 ? 0.10 : 0.12)) + band * (l == 0 ? 0.06 : 0.28);
        vec3 q = d * S;
        vec3 h = hash33(q + float(l) * 71.0);
        if (h.x > dens) continue;
        vec3 sp = floor(q) + 0.2 + 0.6 * hash33(q + 13.0 + float(l) * 29.0);
        vec3 sdir = normalize(sp);
        float ang = length(cross(d, sdir));
        float size = pix * (l == 0 ? 1.1 : 0.8);
        float b = exp(-ang * ang / (size * size));
        float mag = l == 0 ? 0.55 : (l == 1 ? 0.22 : 0.10);
        mag *= pow(h.y, 2.0) + 0.15;
        float k = floor(10.0 + h.z * 30.0);           // integer -> periodic twinkle
        mag *= 0.8 + 0.2 * sin(ph * k + h.y * 6.2831);
        vec3 tint = mix(vec3(0.75, 0.85, 1.0), vec3(1.0, 0.92, 0.80), fract(h.y * 7.0));
        col += tint * b * mag;
    }
    return col;
}


float milkyWayBand(vec3 rd) {
    float b = dot(rd, MW_N);
    return exp(-pow(b / 0.08, 2.0));
}

// Moon centre drifts on a tiny closed path (integer frequency -> seamless loop)
vec3 moonCentre(float ph) {
    vec3 d = MOON_DIR + vec3(0.010 * sin(ph), 0.006 * sin(ph * 2.0 + 0.7), 0.0);
    return normalize(d) * MOON_DIST;
}

vec3 shadeMoon(vec3 rd, vec3 P, vec3 C, float t, float pix, float ph) {
    vec3 N = normalize(P - C);
    float fp = t * pix / MOON_R;
    vec3 q = rotY(0.35 * sin(ph)) * rotX(0.4) * N;               // slow libration wobble
    int o = max(uOct - 1, 3);
    // maria (dark basalt plains) + highland crater texture
    float maria = smoothstep(0.46, 0.62, fbm(q * 2.2 + 11.0, 4, fp * 2.2));
    float crater = ridged(q * 7.0 + 3.0, o, fp * 7.0);
    float fine = fbm(q * 22.0 + 5.0, o, fp * 22.0);
    float alb = mix(0.62, 0.30, maria) * (0.80 + 0.35 * crater) * (0.85 + 0.30 * fine);
    vec3 albC = alb * mix(vec3(1.0, 0.97, 0.92), vec3(0.90, 0.92, 0.98), maria);

    float mu0 = max(dot(N, SUN), 0.0);
    float mu  = max(dot(N, -rd), 0.0);
    float lommel = 2.0 * mu0 / (mu0 + mu + 1e-3);                // flat, dusty lunar look
    float term = smoothstep(-0.02, 0.10, dot(N, SUN));           // soft terminator
    vec3 col = albC * vec3(1.0, 0.96, 0.90) * 2.2 * lommel * term;
    // earthshine: faint blue-grey on the night side of the disc
    col += albC * vec3(0.35, 0.45, 0.70) * 0.028 * (0.4 + 0.6 * mu);
    return col;
}

vec3 shadeEarth(vec3 ro, vec3 rd, vec3 P, float t, float pix, float ph) {
    vec3 N = normalize(P - PB_C);
    float fp = t * pix / PB_R;
    float mu = max(dot(N, -rd), 0.0);
    mat3 tilt = rotZ(-0.35) * rotX(-0.25) * rotY(0.8);  // frames Europe / Africa at the start
    vec3 n0 = tilt * N;
    vec3 q = rotY(-ph) * n0;                             // one rotation per loop, west -> east
    vec3 cq = rotY(-ph - 0.06 * sin(ph)) * n0;           // clouds drift relative to the ground

    vec3 day = toLinear(equirect(uEarthDay, q, fp, mu, 4096.0).rgb);
    vec3 aux = equirect(uEarthAux, q, fp, mu, 2048.0).rgb;
    float cloud = smoothstep(0.08, 0.85, equirect(uEarthAux, cq, fp, mu, 2048.0).r);
    float land = smoothstep(0.3, 0.7, aux.b);
    vec3 alb = mix(day * vec3(0.35, 0.45, 0.62), day, land);

    float ndl = dot(N, SUN);
    float lamb = max(ndl, 0.0);
    float dayF = smoothstep(-0.06, 0.12, ndl);
    vec3 sunCol = vec3(1.0, 0.96, 0.90) * 4.0;
    // night side: faint blue skylight so clouds and oceans are just readable
    vec3 night = vec3(0.10, 0.16, 0.30) * 0.035;

    vec3 surf = alb * (sunCol * lamb + night);
    vec3 hv = normalize(SUN - rd);
    float spec = pow(max(dot(N, hv), 0.0), 300.0) * 6.0 * (0.02 + 0.98 * pow(1.0 - mu, 5.0));
    surf += vec3(1.0, 0.92, 0.80) * spec * (1.0 - land) * lamb;
    surf *= 1.0 - 0.45 * cloud * dayF;

    // golden city lights
    float nightF = 1.0 - smoothstep(-0.12, 0.04, ndl);
    float lights = pow(aux.g, 1.6);
    surf += vec3(1.0, 0.68, 0.30) * lights * 0.55 * nightF * (1.0 - 0.75 * cloud);

    vec3 cl = vec3(0.95, 0.96, 0.98) * (sunCol * (0.03 + 0.97 * lamb) * dayF) + vec3(0.55, 0.65, 0.85) * night * 3.0;
    vec3 col = mix(surf, cl, cloud);

    // atmosphere seen through the limb: turquoise near the sun, deep blue elsewhere
    float haze = pow(1.0 - mu, 4.0);
    float toSun = pow(max(dot(rd, SUN), 0.0), 600.0);
    vec3 skyCol = mix(vec3(0.05, 0.14, 0.40), vec3(0.25, 0.80, 1.0), toSun);
    col += skyCol * haze * (0.015 + 1.5 * toSun + 0.5 * smoothstep(-0.05, 0.4, ndl));
    return col;
}

vec3 milkyWay(vec3 rd, float pix) {
    float b = dot(rd, MW_N);                                       // galactic latitude (sin)
    float along = atan(dot(rd, MW_B), dot(rd, MW_A));              // 0 at the core
    float wobble = (fbm(rd * 3.0 + 7.0, 3, pix * 3.0) - 0.5) * 0.10;
    float w = 0.055 + 0.035 * exp(-along * along * 4.0);             // wider near the core
    float band = exp(-pow((b + wobble) / w, 2.0));
    if (band < 0.002) return vec3(0.0);

    int o = uOct + 1;
    float n1 = fbm(rd * 9.0 + 1.3, o, pix * 9.0);
    float n2 = fbm(rd * 32.0 + 4.7, o, pix * 32.0);
    float core = exp(-along * along * 2.2);
    float lum = band * (0.15 + 3.0 * max(n1 - 0.42, 0.0)) * (0.5 + 1.0 * n2) * (0.30 + 1.6 * core);

    vec3 blue = vec3(0.55, 0.62, 0.95);
    vec3 warm = vec3(1.0, 0.82, 0.60);
    vec3 col = mix(blue, warm, core * 0.85) * lum * 0.13;

    // orange-brown emission / dust clouds (like the reference photo)
    float neb = smoothstep(0.52, 0.72, fbm(rd * 6.0 + 21.0, o, pix * 6.0));
    col += vec3(0.85, 0.38, 0.18) * neb * band * (0.3 + core) * 0.07;

    // dark dust lanes along the middle of the band
    float lane = smoothstep(0.50, 0.68, fbm(rd * 14.0 + 2.2, o, pix * 14.0))
               * exp(-pow((b + wobble * 0.6) / (w * 0.45), 2.0));
    col *= 1.0 - 0.85 * lane;
    return col;
}

void main() {
    vec2 uv = gl_FragCoord.xy / uRes * 2.0 - 1.0;
    float aspect = uRes.x / uRes.y;
    float ph = uPhase;
    float pix = 2.0 * TAN_V / uRes.y;

    // slow cinematic camera + parallax (sensor / home-screen offsets)
    float drift = uToggles.z;
    float yaw   = drift * (0.012 * sin(ph * 2.0) + 0.005 * sin(ph * 5.0 + 1.0)) + uCam.x;
    float pitch = drift * (0.010 * sin(ph * 3.0 + 0.5)) + uCam.y;
    float roll  = drift * 0.008 * sin(ph * 2.0 + 2.0);
    vec3 ro = vec3(uCam.z, uCam.w, 0.0) * 0.4
            + drift * vec3(0.18 * sin(ph * 2.0 + 0.3), 0.12 * sin(ph * 3.0), 0.5 * sin(ph + 1.0));
    vec3 rd = normalize(vec3(uv.x * TAN_V * aspect, uv.y * TAN_V, -1.0));
    rd = rotY(yaw) * rotX(pitch) * rotZ(roll) * rd;

    float bTca, bD;
    vec2 pb = sphere(ro, rd, PB_C, PB_R, pix, bTca, bD);

    vec3 col = vec3(0.0010, 0.0022, 0.0070);
    if (pb.y < 1.0) {
        float mw = milkyWayBand(rd);
        if (uToggles.x > 0.5) col += starfield(rd, pix, ph, mw);
        col += milkyWay(rd, pix);
        col += vec3(0.02, 0.06, 0.16) * 0.10 * exp(-length(cross(rd, SUN)) / 0.20); // blue scatter glow

        // Moon (hides the stars / Milky Way behind it; Earth is mixed in afterwards)
        vec3 mc = moonCentre(ph);
        float mTca, mD;
        vec2 mo = sphere(ro, rd, mc, MOON_R, pix, mTca, mD);
        if (mo.y > 0.0) {
            vec3 mP = ro + rd * max(mo.x, 0.0);
            col = mix(col, shadeMoon(rd, mP, mc, mo.x, pix, ph), mo.y);
        }
        // faint glow hugging the lit crescent
        vec3 mdir = normalize(mc - ro);
        float mang = length(cross(rd, mdir));
        float litSide = max(dot(normalize(rd - mdir * dot(rd, mdir)), SUN), 0.0);
        col += vec3(0.85, 0.90, 1.0) * 0.010 * litSide * exp(-max(mang - MOON_R / MOON_DIST, 0.0) / 0.012) * (1.0 - mo.y);
    }
    if (pb.y > 0.0) {
        vec3 P = ro + rd * pb.x;
        col = mix(col, shadeEarth(ro, rd, P, pb.x, pix, ph), pb.y);
    }
    // bright atmosphere rim, strongly forward-scattering towards the rising sun
    col += atmosphere(ro, rd, PB_C, PB_R, bTca, bD, 0.010, vec3(0.30, 0.75, 1.0), 1.2, SUN);
    col += atmosphere(ro, rd, PB_C, PB_R, bTca, bD, 0.0030, vec3(0.70, 0.92, 1.0), 1.6, SUN);

    // ---- the rising Sun: how much of its disc peeks over the limb (same for all pixels) ----
    vec3 sc = PB_C - ro;
    float limbAng = asin(clamp(PB_R / length(sc), 0.0, 1.0));
    float sunOff = acos(clamp(dot(normalize(sc), SUN), -1.0, 1.0));
    float vis = clamp((sunOff - limbAng + SUN_ANG) / (2.0 * SUN_ANG), 0.0, 1.0);
    float glow = 0.35 + 0.65 * vis;                              // light leaks even when just hidden
    float a = length(cross(rd, SUN));
    vec3 flare = vec3(1.0, 0.97, 0.92) * (vis * 6.0 * smoothstep(SUN_ANG * 1.3, SUN_ANG * 0.6, a) * (1.0 - pb.y))
               + vec3(0.95, 0.98, 1.0) * glow * (2.2 * exp(-a / 0.010) + 0.70 * exp(-a / 0.035))
               + vec3(0.30, 0.78, 1.0) * glow * (0.25 * exp(-a / 0.06) + 0.02 * exp(-a / 0.25));
    // soft horizontal anamorphic streak, very subtle
    vec2 sd = vec2(dot(rd, vec3(1.0, 0.0, 0.0)) - SUN.x, dot(rd, vec3(0.0, 1.0, 0.0)) - SUN.y);
    flare += vec3(0.4, 0.8, 1.0) * glow * 0.10 * exp(-abs(sd.y) / 0.004) * exp(-abs(sd.x) / 0.25);
    col += flare;

    col = 1.0 - exp(-col * 1.1);
    col = pow(col, vec3(1.0 / 2.2));
    float dn = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    col += (dn - 0.5) / 255.0;
    fragColor = vec4(col, 1.0);
}
