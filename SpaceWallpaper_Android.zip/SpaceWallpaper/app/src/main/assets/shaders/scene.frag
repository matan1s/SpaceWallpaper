#version 300 es
// ---------------------------------------------------------------------------
//  Deep Space live wallpaper - "Earth sunrise" scene
//  Earth (NASA maps) seen from its night side, the Sun rising behind the limb,
//  and the Milky Way across the sky.
//
//  SEAMLESS LOOP: every animated quantity is a periodic function of uPhase
//  (0..2PI) with integer frequencies; the CPU advances and wraps the phase,
//  so there is never a jump, fade or restart.
// ---------------------------------------------------------------------------
precision highp float;
precision highp int;

uniform mediump sampler3D uNoise;
uniform mediump sampler2D uEarthDay;   // NASA Blue Marble colour map (equirectangular)
uniform mediump sampler2D uEarthAux;   // R clouds, G night lights, B land mask
uniform vec2  uRes;
uniform float uPhase;
uniform vec4  uCam;       // x yaw, y pitch, z/w lateral shift
uniform int   uOct;
uniform vec4  uToggles;   // x stars on/off, z camera drift amount (0..1, parallax slider)
uniform vec3  uSun;       // direction towards the Sun (camera space)
uniform float uRealtime;  // 1 = Earth orientation from uEarthM (real-time sun), 0 = loop animation
uniform mat3  uEarthM;    // camera space -> Earth texture space (real-time mode)
uniform vec2  uStars;     // x density multiplier, y brightness multiplier
uniform vec4  uMoon;      // xy screen position (tan units), z size scale, w visible
uniform mediump sampler2D uMoonTex;
uniform vec4  uPlanets;   // x drifting planets on/off, y depth-of-field strength (0..1)
uniform vec4  uMeteors;   // x meteor frequency (0..1), y loop length in seconds

out vec4 fragColor;

const float TAN_V = 0.62;

// ---- scene layout (camera space, camera looks down -Z) ----
const vec3  PB_C  = vec3(39.65511, -1.20167, -60.08351);  // Earth centre (fills the right side)
const float PB_R  = 40.654;
#define SUN uSun                                         // default: just behind Earth's left limb
const float SUN_ANG = 0.0047;                             // real angular radius of the Sun
const vec3  MW_N  = vec3(-0.95240, 0.23444, 0.19488);     // Milky Way plane normal
const vec3  MW_A  = vec3(-0.01600, 0.59992, -0.79990);    // towards the bright galactic core
const vec3  MW_B  = vec3(-0.30444, -0.76494, -0.56762);
const float MOON_DIST = 45.0;
const float MOON_R0   = 1.35;

float vnoise(vec3 p) { return texture(uNoise, p * (1.0 / 24.0)).r; }

const mat3 OCT = mat3( 0.00,  0.80,  0.60,
                      -0.80,  0.36, -0.48,
                      -0.60, -0.48,  0.64);

// fbm with footprint-based LOD (avoids shimmering of sub-pixel detail)
float fbm(vec3 p, int oct, float footprint) {
    float s = 0.0, a = 0.5, n = 0.0, f = footprint;
    for (int i = 0; i < 8; i++) {
        if (i >= oct) break;
        float fade = clamp(2.0 - f * 3.0, 0.0, 1.0);  // fade out octaves near pixel size
        if (fade <= 0.0) break;
        s += a * fade * vnoise(p);
        n += a * fade;
        p = OCT * p * 2.03;
        f *= 2.03;
        a *= 0.5;
    }
    return n > 0.0 ? s / n : 0.5;
}

float ridged(vec3 p, int oct, float footprint) {
    float s = 0.0, a = 0.5, n = 0.0, f = footprint;
    for (int i = 0; i < 6; i++) {
        if (i >= oct) break;
        float fade = clamp(2.0 - f * 3.0, 0.0, 1.0);
        if (fade <= 0.0) break;
        float v = 1.0 - abs(vnoise(p) * 2.0 - 1.0);
        s += a * fade * v * v;
        n += a * fade;
        p = OCT * p * 2.07;
        f *= 2.07;
        a *= 0.5;
    }
    return n > 0.0 ? s / n : 0.0;
}

mat3 rotY(float a) { float c = cos(a), s = sin(a); return mat3(c, 0.0, -s, 0.0, 1.0, 0.0, s, 0.0, c); }
mat3 rotX(float a) { float c = cos(a), s = sin(a); return mat3(1.0, 0.0, 0.0, 0.0, c, s, 0.0, -s, c); }
mat3 rotZ(float a) { float c = cos(a), s = sin(a); return mat3(c, s, 0.0, -s, c, 0.0, 0.0, 0.0, 1.0); }

uvec3 pcg3(uvec3 v) {
    v = v * 1664525u + 1013904223u;
    v.x += v.y * v.z; v.y += v.z * v.x; v.z += v.x * v.y;
    v ^= v >> 16u;
    v.x += v.y * v.z; v.y += v.z * v.x; v.z += v.x * v.y;
    return v;
}
vec3 hash33(vec3 p) { return vec3(pcg3(uvec3(ivec3(floor(p)) + 65536))) * (1.0 / 4294967295.0); }

// Sphere test with analytic anti-aliased coverage of the limb.
// returns (tEntry, coverage); tca = distance to closest approach, dmin = closest distance to centre
vec2 sphere(vec3 ro, vec3 rd, vec3 c, float r, float pix, out float tca, out float dmin) {
    vec3 oc = c - ro;
    tca = dot(oc, rd);
    dmin = length(oc - rd * tca);
    if (tca <= 0.0) return vec2(-1.0, 0.0);
    float cov = clamp((r - dmin) / (tca * pix) + 0.5, 0.0, 1.0);
    float h = r * r - dmin * dmin;
    return vec2(tca - sqrt(max(h, 0.0)), cov);
}

// Single-scattering style atmosphere approximation (additive light along the ray)
vec3 atmosphere(vec3 ro, vec3 rd, vec3 c, float r, float tca, float dmin,
                float scaleH, vec3 tint, float strength, vec3 L) {
    if (tca <= 0.0) return vec3(0.0);
    float x = (dmin - r) / (scaleH * r);
    float dens;
    if (x > 0.0) {
        dens = exp(-x);
    } else {
        float mu = sqrt(max(1.0 - (dmin / r) * (dmin / r), 0.0)); // 0 at limb .. 1 at disc centre
        dens = exp(-mu * 9.0);
    }
    vec3 limbN = normalize(ro + rd * tca - c);
    float lit = smoothstep(-0.35, 0.55, dot(limbN, L));
    float fwd = pow(max(dot(rd, L), 0.0), 400.0);
    return tint * dens * strength * lit * (0.30 + 6.0 * fwd);
}

// ---------------------------------------------------------------------------
// Equirectangular lookup with explicit LOD (no derivatives => no seam line, safe in branches)
vec4 equirect(sampler2D tex, vec3 d, float footprint, float mu, float texW) {
    float u = atan(d.x, d.z) * 0.15915494 + 0.5;
    float v = acos(clamp(d.y, -1.0, 1.0)) * 0.31830989;
    texW = float(textureSize(tex, 0).x);                    // actual size (tier-dependent)
    float lod = log2(max(footprint * texW * 0.15915494, 1e-4)) + 0.5 * log2(1.0 / max(mu, 0.06));
    return textureLod(tex, vec2(u, v), max(lod, 0.0));
}

vec3 toLinear(vec3 c) { return c * c * (c * 0.3 + 0.7); }    // cheap sRGB -> linear

// Artistic key light for the background planets: follows the real Sun but is swung towards
// the camera so they show a readable phase instead of a thin back-lit sliver.
vec3 planetLight() {
    return uRealtime > 0.5 ? uSun : normalize(uSun + vec3(0.9, 0.35, 1.15));
}


vec3 starfield(vec3 d, float pix, float ph, float band) {
    vec3 col = vec3(0.0);
    for (int l = 0; l < 3; l++) {
        float S = l == 0 ? 60.0 : (l == 1 ? 150.0 : 340.0);
        float dens = ((l == 0 ? 0.10 : (l == 1 ? 0.10 : 0.12)) + band * (l == 0 ? 0.06 : 0.28)) * uStars.x;
        vec3 q = d * S;
        vec3 h = hash33(q + float(l) * 71.0);
        if (h.x > dens) continue;
        vec3 sp = floor(q) + 0.2 + 0.6 * hash33(q + 13.0 + float(l) * 29.0);
        vec3 sdir = normalize(sp);
        float ang = length(cross(d, sdir));
        float size = pix * (l == 0 ? 1.1 : 0.8);
        float b = exp(-ang * ang / (size * size));
        float mag = l == 0 ? 0.55 : (l == 1 ? 0.22 : 0.10);
        mag *= (pow(h.y, 2.0) + 0.15) * uStars.y;
        float k = floor(10.0 + h.z * 30.0);           // integer -> periodic twinkle
        mag *= 0.8 + 0.2 * sin(ph * k + h.y * 6.2831);
        vec3 tint = mix(vec3(0.75, 0.85, 1.0), vec3(1.0, 0.92, 0.80), fract(h.y * 7.0));
        col += tint * b * mag;
    }
    return col;
}


float milkyWayBand(vec3 rd) {
    float b = dot(rd, MW_N);
    return exp(-pow(b / 0.08, 2.0));
}

vec3 shadeEarth(vec3 ro, vec3 rd, vec3 P, float t, float pix, float ph) {
    vec3 N = normalize(P - PB_C);
    float fp = t * pix / PB_R;
    float mu = max(dot(N, -rd), 0.0);
    mat3 tilt = rotZ(-0.35) * rotX(-0.25) * rotY(0.8);  // frames Europe / Africa at the start
    vec3 n0 = tilt * N;
    vec3 q = rotY(-ph) * n0;                             // one rotation per loop, west -> east
    vec3 cq = rotY(-ph - 0.06 * sin(ph)) * n0;           // clouds drift relative to the ground
    if (uRealtime > 0.5) {                               // real-time: geostationary view, real sun
        q = uEarthM * N;
        cq = rotY(-0.05 * sin(ph)) * q;
    }

    vec3 day = toLinear(equirect(uEarthDay, q, fp, mu, 4096.0).rgb);
    vec3 aux = equirect(uEarthAux, q, fp, mu, 2048.0).rgb;
    float cloud = smoothstep(0.08, 0.85, equirect(uEarthAux, cq, fp, mu, 2048.0).r);
    float land = smoothstep(0.3, 0.7, aux.b);
    vec3 alb = mix(day * vec3(0.35, 0.45, 0.62), day, land);

    float ndl = dot(N, SUN);
    float lamb = max(ndl, 0.0);
    float dayF = smoothstep(-0.06, 0.12, ndl);
    vec3 sunCol = vec3(1.0, 0.96, 0.90) * 4.0;
    // night side: faint blue skylight so clouds and oceans are just readable
    vec3 night = vec3(0.10, 0.16, 0.30) * 0.035;

    vec3 surf = alb * (sunCol * lamb + night);
    vec3 hv = normalize(SUN - rd);
    float spec = pow(max(dot(N, hv), 0.0), 300.0) * 6.0 * (0.02 + 0.98 * pow(1.0 - mu, 5.0));
    surf += vec3(1.0, 0.92, 0.80) * spec * (1.0 - land) * lamb;
    surf *= 1.0 - 0.45 * cloud * dayF;

    // golden city lights
    float nightF = 1.0 - smoothstep(-0.12, 0.04, ndl);
    float lights = pow(aux.g, 1.6);
    surf += vec3(1.0, 0.68, 0.30) * lights * 0.55 * nightF * (1.0 - 0.75 * cloud);

    vec3 cl = vec3(0.95, 0.96, 0.98) * (sunCol * (0.03 + 0.97 * lamb) * dayF) + vec3(0.55, 0.65, 0.85) * night * 3.0;
    vec3 col = mix(surf, cl, cloud);

    // atmosphere seen through the limb: turquoise near the sun, deep blue elsewhere
    float haze = pow(1.0 - mu, 4.0);
    float toSun = pow(max(dot(rd, SUN), 0.0), 600.0);
    vec3 skyCol = mix(vec3(0.05, 0.14, 0.40), vec3(0.25, 0.80, 1.0), toSun);
    col += skyCol * haze * (0.015 + 1.5 * toSun + 0.5 * smoothstep(-0.05, 0.4, ndl));
    return col;
}

vec3 milkyWay(vec3 rd, float pix) {
    float b = dot(rd, MW_N);                                       // galactic latitude (sin)
    float along = atan(dot(rd, MW_B), dot(rd, MW_A));              // 0 at the core
    float wobble = (fbm(rd * 3.0 + 7.0, 3, pix * 3.0) - 0.5) * 0.10;
    float w = 0.055 + 0.035 * exp(-along * along * 4.0);             // wider near the core
    float band = exp(-pow((b + wobble) / w, 2.0));
    if (band < 0.002) return vec3(0.0);

    int o = uOct + 1;
    float n1 = fbm(rd * 9.0 + 1.3, o, pix * 9.0);
    float n2 = fbm(rd * 32.0 + 4.7, o, pix * 32.0);
    float core = exp(-along * along * 2.2);
    float lum = band * (0.15 + 3.0 * max(n1 - 0.42, 0.0)) * (0.5 + 1.0 * n2) * (0.30 + 1.6 * core);

    vec3 blue = vec3(0.55, 0.62, 0.95);
    vec3 warm = vec3(1.0, 0.82, 0.60);
    vec3 col = mix(blue, warm, core * 0.85) * lum * 0.13;

    // orange-brown emission / dust clouds (like the reference photo)
    float neb = smoothstep(0.52, 0.72, fbm(rd * 6.0 + 21.0, o, pix * 6.0));
    col += vec3(0.85, 0.38, 0.18) * neb * band * (0.3 + core) * 0.07;

    // dark dust lanes along the middle of the band
    float lane = smoothstep(0.50, 0.68, fbm(rd * 14.0 + 2.2, o, pix * 14.0))
               * exp(-pow((b + wobble * 0.6) / (w * 0.45), 2.0));
    col *= 1.0 - 0.85 * lane;
    return col;
}

vec3 shadeMoon(vec3 rd, vec3 P, vec3 mc, float mr, float t, float pix) {
    vec3 N = normalize(P - mc);
    float fp = t * pix / mr;
    float mu = max(dot(N, -rd), 0.0);
    vec3 q = rotY(2.2) * rotX(0.15) * N;
    vec3 alb = toLinear(equirect(uMoonTex, q, fp, mu, 1024.0).rgb) * 0.42;
    vec3 Lm = planetLight();                       // real Sun in real-time mode, readable phase otherwise
    float ndl = dot(N, Lm);
    // Lommel-Seeliger reflectance (flat lunar disc look); phase follows the same Sun as the Earth
    float ls = max(ndl, 0.0) / (max(ndl, 0.0) + mu + 1e-3) * 2.0;
    // earthshine: light reflected by the Earth's day side onto the Moon's night side
    vec3 toE = normalize(PB_C - mc);
    float earthLit = clamp(0.5 + 0.5 * dot(-toE, Lm), 0.0, 1.0);      // how much of Earth's day side faces the Moon
    float es = (0.35 + 0.65 * max(dot(N, toE), 0.0)) * (0.05 + 0.10 * earthLit);
    return alb * (vec3(1.0, 0.97, 0.93) * 2.6 * ls + vec3(0.35, 0.48, 0.70) * es);
}

// ===========================================================================
//  DRIFTING PLANETS  (enter -> cross very slowly -> exit, periodic in uPhase)
// ===========================================================================
// Each planet travels between two off-screen points A -> B (tangent-space screen coords,
// depth z) exactly f times per loop, so the wrap-around always happens off-screen.
// Depth also changes along the path, which changes size and depth-of-field blur.
struct Planet { vec2 a; vec2 b; vec2 z; float r; float f; float off; float kind; float spin; };

Planet planetDef(int i) {
    if (i == 0) return Planet(vec2(-0.42, 0.44), vec2(0.36, 0.20), vec2(300.0, 250.0), 7.0, 1.0, 0.08, 0.0, 3.0); // gas giant
    if (i == 1) return Planet(vec2(0.05, -0.80), vec2(-0.46, -0.30), vec2(430.0, 380.0), 8.0, 1.0, 0.52, 1.0, 4.0); // ringed
    if (i == 2) return Planet(vec2(-0.40, -0.10), vec2(0.10, 0.72), vec2(760.0, 700.0), 8.0, 1.0, 0.80, 2.0, 5.0); // ice giant
    return Planet(vec2(0.34, -0.58), vec2(-0.38, 0.10), vec2(160.0, 130.0), 1.3, 2.0, 0.30, 3.0, 2.0);             // red rocky
}

vec3 planetCentre(Planet p, float ph) {
    float u = fract(ph * 0.15915494 * p.f + p.off);
    vec2 s = mix(p.a, p.b, u);
    float z = mix(p.z.x, p.z.y, u);
    return vec3(s * z, -z);
}

vec3 shadePlanetSurface(float kind, vec3 N, vec3 q, float fp) {
    vec3 L = planetLight();
    float lat = q.y;
    vec3 alb;
    if (kind < 0.5) {            // Jupiter-like: warm bands, turbulence, a storm
        float w = fbm(q * 3.0 + 4.0, 5, fp * 3.0);
        float band = sin(lat * 12.0 + (w - 0.5) * 3.0);
        alb = mix(vec3(0.66, 0.52, 0.38), vec3(0.90, 0.84, 0.72), 0.5 + 0.35 * band);
        alb = mix(alb, vec3(0.55, 0.30, 0.20), smoothstep(0.6, 0.9, fbm(q * 9.0, 4, fp * 9.0)) * 0.35);
        float spot = exp(-dot(q - normalize(vec3(0.6, -0.35, 0.7)), q - normalize(vec3(0.6, -0.35, 0.7))) * 40.0);
        alb = mix(alb, vec3(0.75, 0.38, 0.25), spot * 0.8);
    } else if (kind < 1.5) {     // Saturn-like: pale gold, soft bands
        float w = fbm(q * 2.5 + 9.0, 4, fp * 2.5);
        float band = sin(lat * 14.0 + (w - 0.5) * 1.5);
        alb = mix(vec3(0.78, 0.68, 0.48), vec3(0.93, 0.86, 0.68), 0.5 + 0.5 * band);
    } else if (kind < 2.5) {     // Neptune-like: deep blue, faint streaks
        float w = fbm(q * 4.0 + 2.0, 4, fp * 4.0);
        alb = mix(vec3(0.16, 0.32, 0.72), vec3(0.32, 0.52, 0.90), 0.5 + 0.5 * sin(lat * 10.0 + w * 2.0));
        alb += vec3(0.5) * smoothstep(0.66, 0.8, fbm(q * vec3(6.0, 20.0, 6.0), 4, fp * 20.0)) * 0.4;
    } else {                     // Mars-like: rust, dark regions, polar cap
        float h = fbm(q * 3.5 + 1.0, 6, fp * 3.5);
        alb = mix(vec3(0.42, 0.18, 0.08), vec3(0.72, 0.36, 0.18), smoothstep(0.35, 0.65, h));
        alb = mix(alb, vec3(0.85, 0.85, 0.88), smoothstep(0.86, 0.92, abs(lat)));
    }
    float ndl = dot(N, L);
    float diff = max(ndl, 0.0);
    float limb = smoothstep(-0.05, 0.25, ndl);
    return toLinear(alb) * (vec3(1.0, 0.97, 0.93) * 1.7 * diff + vec3(0.25, 0.32, 0.45) * 0.012) * (0.4 + 0.6 * limb);
}

// Returns premultiplied colour + coverage of all drifting planets along this ray.
vec4 driftingPlanets(vec3 ro, vec3 rd, float pix, float ph) {
    vec3 col = vec3(0.0);
    float cover = 0.0;
    float focus = 60.0;                                         // camera focused on the Earth
    for (int i = 0; i < 4; i++) {
        Planet p = planetDef(i);
        vec3 c = planetCentre(p, ph);
        // depth-of-field: angular blur grows with distance behind the focal plane
        float blur = uPlanets.y * 0.30 * max(1.0 / focus - 1.0 / (-c.z), 0.0);
        float soft = pix + blur;
        // cheap reject (including a ring if present)
        vec3 oc = c - ro;
        float tc = dot(oc, rd);
        if (tc <= 0.0) continue;
        float reach = p.r * (p.kind > 0.5 && p.kind < 1.5 ? 2.4 : 1.0) + soft * tc * 2.0;
        if (length(oc - rd * tc) > reach) continue;

        float tca, dmin;
        vec2 hit = sphere(ro, rd, c, p.r, soft, tca, dmin);
        mat3 tilt = rotZ(0.3 + float(i) * 0.7) * rotX(0.35);
        vec4 layer = vec4(0.0);
        if (hit.y > 0.0) {
            vec3 N = normalize(ro + rd * hit.x - c);
            vec3 q = rotY(ph * p.spin) * (tilt * N);          // integer spins per loop -> seamless
            float fp = hit.x * soft / p.r;
            layer = vec4(shadePlanetSurface(p.kind, N, q, fp) * hit.y, hit.y);
        }
        if (p.kind > 0.5 && p.kind < 1.5) {                   // Saturn rings
            vec3 rn = normalize(transpose(tilt) * vec3(0.0, 1.0, 0.0));
            float dn = dot(rd, rn);
            if (abs(dn) > 1e-4) {
                float tr = dot(c - ro, rn) / dn;
                vec3 rp = ro + rd * tr - c;
                float rr = length(rp) / p.r;
                if (tr > 0.0 && rr > 1.25 && rr < 2.35) {
                    float bands = 0.55 + 0.45 * sin(rr * 55.0) * sin(rr * 13.0 + 1.0);
                    float gap = smoothstep(0.0, 0.03, abs(rr - 1.95) - 0.035);       // Cassini division
                    float edge = smoothstep(1.25, 1.32, rr) * smoothstep(2.35, 2.25, rr);
                    float a = clamp(bands * gap * edge * 0.85, 0.0, 1.0);
                    vec3 L = planetLight();
                    // planet shadow on the rings
                    vec3 toL = L;
                    float b2 = dot(-rp, toL);
                    float shadow = (b2 > 0.0 && length(-rp - toL * b2) < p.r) ? 0.15 : 1.0;
                    vec3 rc = toLinear(vec3(0.86, 0.78, 0.60)) * (0.25 + 1.4 * abs(dot(L, rn))) * shadow;
                    bool inFront = hit.y <= 0.0 || tr < hit.x;
                    if (inFront) layer = vec4(rc * a, a) + layer * (1.0 - a);
                    else layer += vec4(rc * a, a) * (1.0 - layer.a);
                }
            }
        }
        col = col * (1.0 - layer.a) + layer.rgb;            // later (closer) planets over earlier
        cover = cover + layer.a * (1.0 - cover);
    }
    return vec4(col, cover);
}

// ===========================================================================
//  METEORS  (random times & directions, but fully periodic -> seamless loop)
// ===========================================================================
vec3 meteors(vec3 rd, float pix, float ph) {
    if (uMeteors.x <= 0.0) return vec3(0.0);
    vec2 sp = rd.xy / max(-rd.z, 0.05);                      // sky position in tangent units
    float loopT = ph * 0.15915494;                          // 0..1 within the loop
    float dur = 1.1 / max(uMeteors.y, 1.0);                 // ~1.1 s of flight, in loop units
    vec3 col = vec3(0.0);
    for (int i = 0; i < 16; i++) {
        vec3 h = hash33(vec3(float(i) * 7.0 + 3.0, 11.0, 29.0));
        if (h.z > uMeteors.x) continue;                      // frequency slider
        float start = h.x;                                   // random moment within the loop
        float tt = fract(loopT - start) / dur;              // 0..1 while flying
        if (tt >= 1.0) continue;
        vec3 h2 = hash33(vec3(float(i) * 13.0 + 5.0, 3.0, 17.0));
        vec2 p0 = vec2(-0.30 + 0.45 * h2.x, 0.05 + 0.50 * h2.y);
        float ang = -2.2 - 0.9 * h2.z;                       // heading down-left .. down
        vec2 dir = vec2(cos(ang), sin(ang));
        float len = 0.07 + 0.08 * h.y;
        vec2 head = p0 + dir * (0.25 * tt);
        vec2 dp = sp - head;
        float along = dot(dp, -dir);                          // distance behind the head
        float across = abs(dot(dp, vec2(-dir.y, dir.x)));
        if (along < -pix * 3.0 || along > len) continue;
        float w = pix * 0.9;
        float tail = clamp(1.0 - along / len, 0.0, 1.0);
        float life = sin(3.14159 * tt);
        float core = exp(-across * across / (w * w)) * tail * tail;
        float headGlow = exp(-dot(dp, dp) / (w * w * 4.0));
        col += vec3(0.85, 0.92, 1.0) * (core * 0.9 + headGlow * 1.2) * life;
    }
    return col;
}

void main() {
    vec2 uv = gl_FragCoord.xy / uRes * 2.0 - 1.0;
    float aspect = uRes.x / uRes.y;
    float ph = uPhase;
    float pix = 2.0 * TAN_V / uRes.y;

    // slow cinematic camera + parallax (sensor / home-screen offsets)
    float drift = uToggles.z;
    float yaw   = drift * (0.012 * sin(ph * 2.0) + 0.005 * sin(ph * 5.0 + 1.0)) + uCam.x;
    float pitch = drift * (0.010 * sin(ph * 3.0 + 0.5)) + uCam.y;
    float roll  = drift * 0.008 * sin(ph * 2.0 + 2.0);
    vec3 ro = vec3(uCam.z, uCam.w, 0.0) * 0.4
            + drift * vec3(0.18 * sin(ph * 2.0 + 0.3), 0.12 * sin(ph * 3.0), 0.5 * sin(ph + 1.0));
    vec3 rd = normalize(vec3(uv.x * TAN_V * aspect, uv.y * TAN_V, -1.0));
    rd = rotY(yaw) * rotX(pitch) * rotZ(roll) * rd;

    float bTca, bD;
    vec2 pb = sphere(ro, rd, PB_C, PB_R, pix, bTca, bD);

    vec3 col = vec3(0.0010, 0.0022, 0.0070);
    if (pb.y < 1.0) {
        float mw = milkyWayBand(rd);
        if (uToggles.x > 0.5) col += starfield(rd, pix, ph, mw);
        col += milkyWay(rd, pix);
        col += meteors(rd, pix, ph) * (1.0 - pb.y);
        if (uPlanets.x > 0.5) {
            vec4 pl = driftingPlanets(ro, rd, pix, ph);
            col = col * (1.0 - pl.a) + pl.rgb;
        }
        col += vec3(0.02, 0.06, 0.16) * 0.10 * exp(-length(cross(rd, SUN)) / 0.20) * step(0.0, dot(rd, SUN));
    }
    if (pb.y > 0.0) {
        vec3 P = ro + rd * pb.x;
        col = mix(col, shadeEarth(ro, rd, P, pb.x, pix, ph), pb.y);
    }
    // ---- Moon (user position / size), in front of the Earth ----
    float moonCover = 0.0;
    if (uMoon.w > 0.5) {
        vec3 md = normalize(vec3(uMoon.x, uMoon.y, -1.0));
        vec3 mc = md * MOON_DIST + vec3(0.6 * sin(ph), 0.25 * sin(ph * 2.0 + 1.0), 0.0);
        float mr = MOON_R0 * uMoon.z;
        float mTca, mD;
        vec2 mo = sphere(ro, rd, mc, mr, pix, mTca, mD);
        if (mo.y > 0.0) {
            col = mix(col, shadeMoon(rd, ro + rd * mo.x, mc, mr, mo.x, pix), mo.y);
            moonCover = mo.y;
        }
    }

    // bright atmosphere rim, strongly forward-scattering towards the rising sun
    col += (atmosphere(ro, rd, PB_C, PB_R, bTca, bD, 0.010, vec3(0.30, 0.75, 1.0), 1.2, SUN)
          + atmosphere(ro, rd, PB_C, PB_R, bTca, bD, 0.0030, vec3(0.70, 0.92, 1.0), 1.6, SUN)) * (1.0 - moonCover);

    // ---- the rising Sun: how much of its disc peeks over the limb (same for all pixels) ----
    vec3 sc = PB_C - ro;
    float limbAng = asin(clamp(PB_R / length(sc), 0.0, 1.0));
    float sunOff = acos(clamp(dot(normalize(sc), SUN), -1.0, 1.0));
    float vis = clamp((sunOff - limbAng + SUN_ANG) / (2.0 * SUN_ANG), 0.0, 1.0);
    float leak = exp(-max(limbAng - sunOff, 0.0) / 0.02);        // light leaks when just hidden
    float glow = (0.35 * leak + 0.65 * vis) * step(0.0, dot(rd, SUN));
    float a = length(cross(rd, SUN));
    vec3 flare = vec3(1.0, 0.97, 0.92) * (vis * 6.0 * smoothstep(SUN_ANG * 1.3, SUN_ANG * 0.6, a) * (1.0 - max(pb.y, moonCover)))
               + vec3(0.95, 0.98, 1.0) * glow * (2.2 * exp(-a / 0.010) + 0.70 * exp(-a / 0.035))
               + vec3(0.30, 0.78, 1.0) * glow * (0.25 * exp(-a / 0.06) + 0.02 * exp(-a / 0.25));
    // soft horizontal anamorphic streak, very subtle
    vec2 sd = vec2(dot(rd, vec3(1.0, 0.0, 0.0)) - SUN.x, dot(rd, vec3(0.0, 1.0, 0.0)) - SUN.y);
    flare += vec3(0.4, 0.8, 1.0) * glow * 0.10 * exp(-abs(sd.y) / 0.004) * exp(-abs(sd.x) / 0.25);
    col += flare;

    col = 1.0 - exp(-col * 1.1);
    col = pow(col, vec3(1.0 / 2.2));
    float dn = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    col += (dn - 0.5) / 255.0;
    fragColor = vec4(col, 1.0);
}
