#version 300 es
// ---------------------------------------------------------------------------
//  Deep Space live wallpaper - v3 "Earth night + Milky Way" scene
//  Composition fitted to the reference (S25 Ultra portrait 1440x3120):
//    Earth limb: (100%,10%) -> (47%,62%) -> (100%,98%), Sun behind the limb at ~(48%,64%),
//    Moon at (26%,26%), Milky Way from (45%,0%) to (0%,75%), core near (15%,50%).
//  Output: tone-mapped colour; bloom + grain are added by composite.frag.
//  SEAMLESS LOOP: every animated term is periodic in uPhase (0..2PI).
// ---------------------------------------------------------------------------
precision highp float;
precision highp int;

uniform mediump sampler3D uNoise;
uniform mediump sampler2D uEarthDay;   // NASA Blue Marble (equirectangular)
uniform mediump sampler2D uEarthAux;   // R clouds, G night lights (Black Marble), B land mask
uniform mediump sampler2D uMoonTex;    // lunar map
uniform vec2  uRes;
uniform float uPhase;
uniform vec4  uCam;       // x yaw, y pitch (radians), z/w parallax shift (-1..1)
uniform int   uOct;
uniform vec4  uToggles;   // x stars, z camera drift amount, w flare on/off (settings switch ONLY)
uniform vec3  uSun;       // direction towards the Sun (camera space)
uniform float uRealtime;  // 1 = real-time sun (uSun is the real Sun, Earth does not spin)
uniform mat3  uEarthM;    // camera space -> Earth texture space (base orientation)
uniform float uEarthSpin; // Earth spin angle (radians) applied about the polar axis
uniform vec2  uStars;     // x density, y brightness multipliers
uniform vec4  uMoon;      // xy screen position (fraction, origin top-left), z size scale, w visible
uniform float uMoonBright; // moon brightness multiplier (settings slider, 1 = default)
uniform vec4  uPlanets;   // x drifting planets on/off, y depth-of-field strength
uniform vec4  uMeteors;   // x meteor frequency (0..1), y loop length (s)

out vec4 fragColor;

const float TAN_V = 0.62;
#define SUN uSun

// ---- scene layout (camera space, camera looks down -Z) ----
const vec3  PB_C  = vec3(35.98335, -2.73510, -65.74738);   // Earth centre (off-screen right)
const float PB_R  = 37.7387;
const float SUN_ANG = 0.0047;
const float MOON_DIST = 45.0;
const float MOON_R0   = 1.93;                               // 15% of screen width at default size
// Milky Way great circle through (45%,0%) and (0%,75%); core direction at (15%,50%)
const vec3  MW_N  = vec3(-0.94626, 0.26204, 0.18954);
const vec3  MW_C  = vec3(-0.19641, 0.0, -0.98052);
const float PL_PARALLAX_EARTH = 1.2;                         // per-layer parallax (scene units)
const float PL_PARALLAX_MOON  = 0.45;


float vnoise(vec3 p) { return texture(uNoise, p * (1.0 / 24.0)).r; }

const mat3 OCT = mat3( 0.00,  0.80,  0.60,
                      -0.80,  0.36, -0.48,
                      -0.60, -0.48,  0.64);

// fbm with footprint-based LOD (avoids shimmering of sub-pixel detail)
float fbm(vec3 p, int oct, float footprint) {
    float s = 0.0, a = 0.5, n = 0.0, f = footprint;
    for (int i = 0; i < 8; i++) {
        if (i >= oct) break;
        float fade = clamp(2.0 - f * 3.0, 0.0, 1.0);  // fade out octaves near pixel size
        if (fade <= 0.0) break;
        s += a * fade * vnoise(p);
        n += a * fade;
        p = OCT * p * 2.03;
        f *= 2.03;
        a *= 0.5;
    }
    return n > 0.0 ? s / n : 0.5;
}

float ridged(vec3 p, int oct, float footprint) {
    float s = 0.0, a = 0.5, n = 0.0, f = footprint;
    for (int i = 0; i < 6; i++) {
        if (i >= oct) break;
        float fade = clamp(2.0 - f * 3.0, 0.0, 1.0);
        if (fade <= 0.0) break;
        float v = 1.0 - abs(vnoise(p) * 2.0 - 1.0);
        s += a * fade * v * v;
        n += a * fade;
        p = OCT * p * 2.07;
        f *= 2.07;
        a *= 0.5;
    }
    return n > 0.0 ? s / n : 0.0;
}

mat3 rotY(float a) { float c = cos(a), s = sin(a); return mat3(c, 0.0, -s, 0.0, 1.0, 0.0, s, 0.0, c); }
mat3 rotX(float a) { float c = cos(a), s = sin(a); return mat3(1.0, 0.0, 0.0, 0.0, c, s, 0.0, -s, c); }
mat3 rotZ(float a) { float c = cos(a), s = sin(a); return mat3(c, s, 0.0, -s, c, 0.0, 0.0, 0.0, 1.0); }

uvec3 pcg3(uvec3 v) {
    v = v * 1664525u + 1013904223u;
    v.x += v.y * v.z; v.y += v.z * v.x; v.z += v.x * v.y;
    v ^= v >> 16u;
    v.x += v.y * v.z; v.y += v.z * v.x; v.z += v.x * v.y;
    return v;
}
vec3 hash33(vec3 p) { return vec3(pcg3(uvec3(ivec3(floor(p)) + 65536))) * (1.0 / 4294967295.0); }

// Sphere test with analytic anti-aliased coverage of the limb.
// returns (tEntry, coverage); tca = distance to closest approach, dmin = closest distance to centre
vec2 sphere(vec3 ro, vec3 rd, vec3 c, float r, float pix, out float tca, out float dmin) {
    vec3 oc = c - ro;
    tca = dot(oc, rd);
    dmin = length(oc - rd * tca);
    if (tca <= 0.0) return vec2(-1.0, 0.0);
    float cov = clamp((r - dmin) / (tca * pix) + 0.5, 0.0, 1.0);
    float h = r * r - dmin * dmin;
    return vec2(tca - sqrt(max(h, 0.0)), cov);
}

// Single-scattering style atmosphere approximation (additive light along the ray)
vec3 atmosphere(vec3 ro, vec3 rd, vec3 c, float r, float tca, float dmin,
                float scaleH, vec3 tint, float strength, vec3 L) {
    if (tca <= 0.0) return vec3(0.0);
    float x = (dmin - r) / (scaleH * r);
    float dens;
    if (x > 0.0) {
        dens = exp(-x);
    } else {
        float mu = sqrt(max(1.0 - (dmin / r) * (dmin / r), 0.0)); // 0 at limb .. 1 at disc centre
        dens = exp(-mu * 9.0);
    }
    vec3 limbN = normalize(ro + rd * tca - c);
    float lit = smoothstep(-0.35, 0.55, dot(limbN, L));
    float fwd = pow(max(dot(rd, L), 0.0), 400.0);
    return tint * dens * strength * lit * (0.30 + 6.0 * fwd);
}

// ---------------------------------------------------------------------------

// Equirectangular lookup with explicit LOD (no derivatives => no seam line, safe in branches)
vec4 equirect(sampler2D tex, vec3 d, float footprint, float mu, float texW) {
    float u = atan(d.x, d.z) * 0.15915494 + 0.5;
    float v = acos(clamp(d.y, -1.0, 1.0)) * 0.31830989;
    texW = float(textureSize(tex, 0).x);                    // actual size (tier-dependent)
    float lod = log2(max(footprint * texW * 0.15915494, 1e-4)) + 0.5 * log2(1.0 / max(mu, 0.06));
    return textureLod(tex, vec2(u, v), max(lod, 0.0));
}

vec3 toLinear(vec3 c) { return c * c * (c * 0.3 + 0.7); }    // cheap sRGB -> linear



// Light used for the Earth surface: the real Sun in real-time mode; otherwise the Sun swung
// towards the camera so a wide day crescent runs along the limb (as in the reference photo).
vec3 earthLight() {
    return uRealtime > 0.5 ? uSun : normalize(uSun + 0.60 * vec3(-0.55, 0.10, 0.62));
}
// Artistic key light for the optional drifting planets
vec3 planetLight() {
    return uRealtime > 0.5 ? uSun : normalize(uSun + vec3(0.9, 0.35, 1.15));
}

// screen fraction (origin top-left) -> camera-space direction at rest
vec3 screenDir(vec2 f) {
    float aspect = uRes.x / uRes.y;
    return normalize(vec3((f.x - 0.5) * 2.0 * TAN_V * aspect, (0.5 - f.y) * 2.0 * TAN_V, -1.0));
}

// ===========================================================================
//  STARS: dense fine field + Milky-Way star clouds + bright stars with spikes
// ===========================================================================
vec3 starfield(vec3 d, float pix, float ph, float band) {
    vec3 col = vec3(0.0);
    for (int l = 0; l < 5; l++) {
        float S = l == 0 ? 60.0 : (l == 1 ? 150.0 : (l == 2 ? 340.0 : (l == 3 ? 760.0 : 1500.0)));
        float dens = (l == 0 ? 0.07 : (l == 1 ? 0.10 : (l == 2 ? 0.18 : (l == 3 ? 0.16 : 0.06))))
                   + band * (l == 0 ? 0.05 : (l == 1 ? 0.30 : (l == 2 ? 0.60 : (l == 3 ? 0.84 : 0.94))));
        dens *= uStars.x;
        vec3 q = d * S;
        vec3 h = hash33(q + float(l) * 71.0);
        if (h.x > dens) continue;
        vec3 sp = floor(q) + 0.2 + 0.6 * hash33(q + 13.0 + float(l) * 29.0);
        float ang = length(cross(d, normalize(sp)));
        float size = pix * (l == 0 ? 1.1 : (l == 4 ? 0.65 : 0.75));
        float b = exp(-ang * ang / (size * size));
        float mag = l == 0 ? 0.60 : (l == 1 ? 0.26 : (l == 2 ? 0.12 : (l == 3 ? 0.065 : 0.045)));
        mag *= (pow(h.y, 2.0) + 0.15) * uStars.y * (1.0 + (l >= 2 ? 2.2 : 0.8) * band);
        float k = floor(10.0 + h.z * 30.0);                       // integer -> periodic twinkle
        mag *= 0.75 + 0.25 * sin(ph * k + h.y * 6.2831);
        vec3 tint = mix(vec3(0.62, 0.76, 1.0), vec3(1.0, 0.90, 0.78), fract(h.y * 7.0));
        tint = mix(tint, vec3(0.70, 0.80, 1.0), band * 0.4);      // cooler stars around the band
        col += tint * b * mag;
    }
    return col;
}

// bright stars with 4-point diffraction spikes (screen-aligned)
vec3 brightStar(vec3 rd, vec2 at, float pix, float ph, float mag, float k) {
    vec3 sd = screenDir(at);
    vec3 rx = vec3(1.0, 0.0, 0.0), ry = vec3(0.0, 1.0, 0.0);
    vec3 dv = rd - sd;
    float x = dot(dv, rx), y = dot(dv, ry);
    float r2 = x * x + y * y;
    float w = pix * 0.9;
    float tw = 0.85 + 0.15 * sin(ph * k);
    float core = exp(-r2 / (w * w * 1.6)) * 2.5 + exp(-sqrt(r2) / (pix * 3.0)) * 0.30;
    float spikes = (exp(-abs(x) / (pix * 7.0)) * exp(-y * y / (w * w * 0.25))
                  + exp(-abs(y) / (pix * 7.0)) * exp(-x * x / (w * w * 0.25))) * 0.8;
    return vec3(0.80, 0.88, 1.0) * (core + spikes) * mag * tw;
}

vec3 brightStars(vec3 rd, float pix, float ph) {
    vec3 c = vec3(0.0);
    c += brightStar(rd, vec2(0.55, 0.08), pix, ph, 1.0, 7.0);
    c += brightStar(rd, vec2(0.38, 0.83), pix, ph, 0.9, 9.0);
    c += brightStar(rd, vec2(0.24, 0.74), pix, ph, 0.7, 11.0);
    c += brightStar(rd, vec2(0.10, 0.88), pix, ph, 0.5, 13.0);
    c += brightStar(rd, vec2(0.33, 0.18), pix, ph, 0.45, 5.0);
    c += brightStar(rd, vec2(0.05, 0.36), pix, ph, 0.4, 8.0);
    return c * uStars.y;
}

// ===========================================================================
//  MILKY WAY (procedural: curved band, filamentary dust, warm core, nebulae)
// ===========================================================================
float mwCoords(vec3 rd, out float along) {
    vec3 e2 = cross(MW_N, MW_C);
    along = atan(dot(rd, e2), dot(rd, MW_C));               // 0 at the core
    return dot(rd, MW_N) - 0.05 * along * along;             // slightly bowed band
}

float milkyWayBand(vec3 rd) {
    float along;
    float b = mwCoords(rd, along);
    float w = 0.050 + 0.030 * exp(-along * along * 6.0);
    return exp(-pow(b / w, 2.0));
}

vec3 milkyWay(vec3 rd, float pix) {
    float along;
    float b = mwCoords(rd, along);
    vec3 p = rd * 7.0;
    b += (fbm(p * 0.9 + 3.1, 4, pix * 6.0) - 0.5) * 0.035;      // ragged, organic edges
    float w = 0.045 + 0.030 * exp(-along * along * 6.0);          // wider around the core
    float band = exp(-pow(b / w, 2.0));
    float halo = exp(-pow(b / (w * 2.2), 2.0));
    if (halo < 0.004) return vec3(0.0);

    int o = uOct + 1;
    float core = exp(-along * along * 10.0) * exp(-pow(b / (w * 1.1), 2.0));

    // 1) soft unresolved glow (kept low - the band is mostly made of stars)
    float n1 = fbm(p * 3.0 + 1.3, o, pix * 21.0);
    float clouds = smoothstep(0.42, 0.64, n1);
    float g2 = fbm(p * 7.0 + 8.3, o, pix * 49.0);
    float knots = smoothstep(0.45, 0.70, g2);
    float glow = band * (0.05 + 0.9 * clouds * (0.4 + knots)) + core * (0.25 + 1.2 * clouds * knots) + halo * 0.02;

    // 2) star clouds: dense pixel-scale sparkle whose density follows the clouds
    float stars = 0.0;                                             // resolved stars come from starfield()

    vec3 beige = vec3(1.00, 0.83, 0.64);
    vec3 brown = vec3(0.60, 0.42, 0.30);
    vec3 blue  = vec3(0.60, 0.72, 1.00);
    float g = fbm(p * 6.0 + 4.7, o, pix * 42.0);
    vec3 tint = mix(blue, mix(brown, beige, smoothstep(0.4, 0.7, g)), smoothstep(0.25, 0.85, band) * 0.9);
    vec3 col = tint * glow * 0.13;
    col += vec3(1.0, 0.88, 0.70) * core * core * clouds * 0.30;  // glowing core near (15%,50%)

    // 3) pink / magenta nebulae on the lower-left part of the band
    float nebZone = smoothstep(0.10, 0.40, along) * smoothstep(1.10, 0.55, along);
    float neb = smoothstep(0.50, 0.74, fbm(p * 4.0 + 21.0, o, pix * 28.0)) * nebZone * band;
    col += vec3(0.95, 0.26, 0.62) * neb * 0.22;

    // 4) dark dust: irregular warped clouds + thin filaments along the centre
    vec3 wq = p * 3.0 + vec3(fbm(p * 1.5 + 7.0, 4, pix * 10.0), fbm(p * 1.5 + 17.0, 4, pix * 10.0),
                             fbm(p * 1.5 + 27.0, 4, pix * 10.0)) * 2.5;
    float dust = smoothstep(0.44, 0.56, fbm(wq * 1.3, o, pix * 27.0));
    float fil = smoothstep(0.60, 0.82, ridged(wq * 2.2 + 5.0, o, pix * 47.0));
    float centre = exp(-pow((b + 0.006) / (w * 0.6), 2.0));
    col *= 1.0 - clamp((0.90 * dust + 0.70 * fil) * (0.45 + 0.55 * centre) * smoothstep(0.05, 0.5, band), 0.0, 0.95);
    return col;
}

// ===========================================================================
//  EARTH
// ===========================================================================
vec3 shadeEarth(vec3 rd, vec3 P, vec3 ec, float t, float pix, float ph) {
    vec3 N = normalize(P - ec);
    float fp = t * pix / PB_R;
    float mu = max(dot(N, -rd), 0.0);
    vec3 base = uEarthM * N;
    vec3 q = rotY(-uEarthSpin) * base;

    // clouds drift faster than the ground: two flow phases cross-faded (seamless)
    float ft = ph * 0.15915494 * 6.0;                          // 6 flow cycles per loop
    float f1 = fract(ft), f2 = fract(ft + 0.5);
    float wgt = abs(f1 - 0.5) * 2.0;                           // weight of layer 2
    vec3 c1 = rotY(-uEarthSpin - 0.05 * f1) * base;
    vec3 c2 = rotY(-uEarthSpin - 0.05 * f2) * base;
    float cl1 = equirect(uEarthAux, c1, fp, mu, 4096.0).r;
    float cl2 = equirect(uEarthAux, c2, fp, mu, 4096.0).r;
    float cloud = smoothstep(0.10, 0.85, mix(cl1, cl2, wgt));

    vec3 day = toLinear(equirect(uEarthDay, q, fp, mu, 4096.0).rgb);
    vec3 aux = equirect(uEarthAux, q, fp, mu, 4096.0).rgb;
    float land = smoothstep(0.3, 0.7, aux.b);
    vec3 alb = mix(day * vec3(0.30, 0.42, 0.62), day, land);

    vec3 L = earthLight();
    float ndl = dot(N, L);
    float lamb = max(ndl, 0.0);
    float dayF = smoothstep(-0.10, 0.15, ndl);
    vec3 sunCol = vec3(1.0, 0.97, 0.92) * 3.2;
    vec3 night = vec3(0.10, 0.16, 0.30) * 0.06;                // moon/sky light on the night side

    vec3 surf = alb * (sunCol * lamb + night * (0.6 + 0.8 * land));
    vec3 hv = normalize(L - rd);
    float spec = pow(max(dot(N, hv), 0.0), 220.0) * 4.0 * (0.03 + 0.97 * pow(1.0 - mu, 5.0));
    surf += vec3(1.0, 0.93, 0.82) * spec * (1.0 - land) * lamb * (0.3 + 0.7 * step(0.5, uToggles.w)); // no glint hot-spot when flare is OFF
    surf *= 1.0 - 0.45 * cloud * dayF;

    // golden city lights with a soft shimmer (periodic noise-domain orbit)
    float nightF = 1.0 - smoothstep(-0.18, 0.06, ndl);
    float lights = pow(aux.g, 1.5);
    vec3 orbit = vec3(cos(ph * 9.0), sin(ph * 9.0), 0.0) * 0.6;
    float shimmer = 0.80 + 0.40 * vnoise(q * 260.0 + orbit);
    surf += vec3(1.0, 0.66, 0.28) * lights * 0.95 * shimmer * nightF * (1.0 - 0.8 * cloud);

    vec3 clc = vec3(0.95, 0.96, 0.99) * (sunCol * (0.04 + 0.96 * lamb) * dayF)
             + vec3(0.45, 0.55, 0.80) * night * 2.5;
    vec3 col = mix(surf, clc, cloud);

    // blue haze towards the limb; brighter on the day side and towards the Sun
    float haze = pow(1.0 - mu, 3.0);
    float toSun = pow(max(dot(rd, SUN), 0.0), 500.0) * step(0.5, uToggles.w);   // flare OFF -> no sun hot-spot
    col += mix(vec3(0.04, 0.12, 0.35), vec3(0.30, 0.78, 1.0), toSun) * haze
         * (0.03 + 1.4 * toSun + 0.35 * smoothstep(-0.05, 0.4, ndl));
    return col;
}

// thin bright rim along the whole limb + soft outer glow
vec3 earthRim(vec3 rd, vec3 ec, float tca, float dmin) {
    if (tca <= 0.0) return vec3(0.0);
    float h = (dmin - PB_R) / PB_R;                            // >0 outside, <0 inside the disc
    float rimIn = h < 0.0 ? exp(h * 260.0) : 0.0;              // just inside the limb
    float rimOut = h >= 0.0 ? exp(-h * 220.0) : 0.0;           // thin bright line just outside
    float glow = h >= 0.0 ? exp(-h * 28.0) : exp(h * 25.0) * 0.4;
    vec3 limbN = normalize(rd * tca - ec);
    float lit = 0.45 + 0.55 * smoothstep(-0.5, 0.6, dot(limbN, earthLight()));
    float fwd = pow(max(dot(rd, SUN), 0.0), 300.0) * step(0.5, uToggles.w);     // flare OFF -> even rim
    vec3 c = vec3(0.35, 0.72, 1.0) * (rimOut * 0.9 + rimIn * 0.5) + vec3(0.18, 0.45, 1.0) * glow * 0.30;
    return c * lit * (1.0 + 5.0 * fwd);
}

// ===========================================================================
//  MOON (lit by the true Sun -> thin crescent on the lower-right)
// ===========================================================================
vec3 shadeMoon(vec3 rd, vec3 P, vec3 mc, float mr, float t, float pix) {
    vec3 N = normalize(P - mc);
    float fp = t * pix / mr;
    float mu = max(dot(N, -rd), 0.0);
    vec3 q = rotY(2.2) * rotX(0.15) * N;
    vec3 tex = toLinear(equirect(uMoonTex, q, fp, mu, 1024.0).rgb);
    // stronger crater contrast so the surface reads clearly even on the dark side
    float l = dot(tex, vec3(0.333));
    vec3 alb = mix(vec3(l), tex, 0.6) * (0.55 + 0.9 * smoothstep(0.05, 0.6, l));

    // crescent light: the real Sun, swung slightly towards the camera -> wider lower-right crescent
    vec3 L = uRealtime > 0.5 ? SUN : normalize(SUN + vec3(0.30, -0.05, 0.42));
    float ndl = dot(N, L);
    float ls = max(ndl, 0.0) / (max(ndl, 0.0) + mu + 1e-3) * 2.0;     // Lommel-Seeliger
    float crescent = ls * smoothstep(-0.02, 0.10, ndl);

    // earthshine: lights the whole disc (~25-35% brightness) so craters are visible everywhere
    vec3 toE = normalize(PB_C - mc);
    float es = 0.55 + 0.25 * max(dot(N, toE), 0.0);
    vec3 col = alb * (vec3(1.0, 0.97, 0.93) * 4.2 * crescent + vec3(0.62, 0.70, 0.86) * es * 0.55);

    // very subtle soft rim so the disc separates from the Milky Way
    col += vec3(0.55, 0.65, 0.85) * pow(1.0 - mu, 3.0) * 0.045;
    return col * uMoonBright;
}


// ===========================================================================
//  DRIFTING PLANETS  (enter -> cross very slowly -> exit, periodic in uPhase)
// ===========================================================================
// Each planet travels between two off-screen points A -> B (tangent-space screen coords,
// depth z) exactly f times per loop, so the wrap-around always happens off-screen.
// Depth also changes along the path, which changes size and depth-of-field blur.
struct Planet { vec2 a; vec2 b; vec2 z; float r; float f; float off; float kind; float spin; };

Planet planetDef(int i) {
    if (i == 0) return Planet(vec2(-0.42, 0.44), vec2(0.36, 0.20), vec2(300.0, 250.0), 7.0, 1.0, 0.08, 0.0, 3.0); // gas giant
    if (i == 1) return Planet(vec2(0.05, -0.80), vec2(-0.46, -0.30), vec2(430.0, 380.0), 8.0, 1.0, 0.52, 1.0, 4.0); // ringed
    if (i == 2) return Planet(vec2(-0.40, -0.10), vec2(0.10, 0.72), vec2(760.0, 700.0), 8.0, 1.0, 0.80, 2.0, 5.0); // ice giant
    return Planet(vec2(0.34, -0.58), vec2(-0.38, 0.10), vec2(160.0, 130.0), 1.3, 2.0, 0.30, 3.0, 2.0);             // red rocky
}

vec3 planetCentre(Planet p, float ph) {
    float u = fract(ph * 0.15915494 * p.f + p.off);
    vec2 s = mix(p.a, p.b, u);
    float z = mix(p.z.x, p.z.y, u);
    return vec3(s * z, -z);
}

vec3 shadePlanetSurface(float kind, vec3 N, vec3 q, float fp) {
    vec3 L = planetLight();
    float lat = q.y;
    vec3 alb;
    if (kind < 0.5) {            // Jupiter-like: warm bands, turbulence, a storm
        float w = fbm(q * 3.0 + 4.0, 5, fp * 3.0);
        float band = sin(lat * 12.0 + (w - 0.5) * 3.0);
        alb = mix(vec3(0.66, 0.52, 0.38), vec3(0.90, 0.84, 0.72), 0.5 + 0.35 * band);
        alb = mix(alb, vec3(0.55, 0.30, 0.20), smoothstep(0.6, 0.9, fbm(q * 9.0, 4, fp * 9.0)) * 0.35);
        float spot = exp(-dot(q - normalize(vec3(0.6, -0.35, 0.7)), q - normalize(vec3(0.6, -0.35, 0.7))) * 40.0);
        alb = mix(alb, vec3(0.75, 0.38, 0.25), spot * 0.8);
    } else if (kind < 1.5) {     // Saturn-like: pale gold, soft bands
        float w = fbm(q * 2.5 + 9.0, 4, fp * 2.5);
        float band = sin(lat * 14.0 + (w - 0.5) * 1.5);
        alb = mix(vec3(0.78, 0.68, 0.48), vec3(0.93, 0.86, 0.68), 0.5 + 0.5 * band);
    } else if (kind < 2.5) {     // Neptune-like: deep blue, faint streaks
        float w = fbm(q * 4.0 + 2.0, 4, fp * 4.0);
        alb = mix(vec3(0.16, 0.32, 0.72), vec3(0.32, 0.52, 0.90), 0.5 + 0.5 * sin(lat * 10.0 + w * 2.0));
        alb += vec3(0.5) * smoothstep(0.66, 0.8, fbm(q * vec3(6.0, 20.0, 6.0), 4, fp * 20.0)) * 0.4;
    } else {                     // Mars-like: rust, dark regions, polar cap
        float h = fbm(q * 3.5 + 1.0, 6, fp * 3.5);
        alb = mix(vec3(0.42, 0.18, 0.08), vec3(0.72, 0.36, 0.18), smoothstep(0.35, 0.65, h));
        alb = mix(alb, vec3(0.85, 0.85, 0.88), smoothstep(0.86, 0.92, abs(lat)));
    }
    float ndl = dot(N, L);
    float diff = max(ndl, 0.0);
    float limb = smoothstep(-0.05, 0.25, ndl);
    return toLinear(alb) * (vec3(1.0, 0.97, 0.93) * 1.7 * diff + vec3(0.25, 0.32, 0.45) * 0.012) * (0.4 + 0.6 * limb);
}

// Returns premultiplied colour + coverage of all drifting planets along this ray.
vec4 driftingPlanets(vec3 ro, vec3 rd, float pix, float ph) {
    vec3 col = vec3(0.0);
    float cover = 0.0;
    float focus = 60.0;                                         // camera focused on the Earth
    for (int i = 0; i < 4; i++) {
        Planet p = planetDef(i);
        vec3 c = planetCentre(p, ph);
        // depth-of-field: angular blur grows with distance behind the focal plane
        float blur = uPlanets.y * 0.30 * max(1.0 / focus - 1.0 / (-c.z), 0.0);
        float soft = pix + blur;
        // cheap reject (including a ring if present)
        vec3 oc = c - ro;
        float tc = dot(oc, rd);
        if (tc <= 0.0) continue;
        float reach = p.r * (p.kind > 0.5 && p.kind < 1.5 ? 2.4 : 1.0) + soft * tc * 2.0;
        if (length(oc - rd * tc) > reach) continue;

        float tca, dmin;
        vec2 hit = sphere(ro, rd, c, p.r, soft, tca, dmin);
        mat3 tilt = rotZ(0.3 + float(i) * 0.7) * rotX(0.35);
        vec4 layer = vec4(0.0);
        if (hit.y > 0.0) {
            vec3 N = normalize(ro + rd * hit.x - c);
            vec3 q = rotY(ph * p.spin) * (tilt * N);          // integer spins per loop -> seamless
            float fp = hit.x * soft / p.r;
            layer = vec4(shadePlanetSurface(p.kind, N, q, fp) * hit.y, hit.y);
        }
        if (p.kind > 0.5 && p.kind < 1.5) {                   // Saturn rings
            vec3 rn = normalize(transpose(tilt) * vec3(0.0, 1.0, 0.0));
            float dn = dot(rd, rn);
            if (abs(dn) > 1e-4) {
                float tr = dot(c - ro, rn) / dn;
                vec3 rp = ro + rd * tr - c;
                float rr = length(rp) / p.r;
                if (tr > 0.0 && rr > 1.25 && rr < 2.35) {
                    float bands = 0.55 + 0.45 * sin(rr * 55.0) * sin(rr * 13.0 + 1.0);
                    float gap = smoothstep(0.0, 0.03, abs(rr - 1.95) - 0.035);       // Cassini division
                    float edge = smoothstep(1.25, 1.32, rr) * smoothstep(2.35, 2.25, rr);
                    float a = clamp(bands * gap * edge * 0.85, 0.0, 1.0);
                    vec3 L = planetLight();
                    // planet shadow on the rings
                    vec3 toL = L;
                    float b2 = dot(-rp, toL);
                    float shadow = (b2 > 0.0 && length(-rp - toL * b2) < p.r) ? 0.15 : 1.0;
                    vec3 rc = toLinear(vec3(0.86, 0.78, 0.60)) * (0.25 + 1.4 * abs(dot(L, rn))) * shadow;
                    bool inFront = hit.y <= 0.0 || tr < hit.x;
                    if (inFront) layer = vec4(rc * a, a) + layer * (1.0 - a);
                    else layer += vec4(rc * a, a) * (1.0 - layer.a);
                }
            }
        }
        col = col * (1.0 - layer.a) + layer.rgb;            // later (closer) planets over earlier
        cover = cover + layer.a * (1.0 - cover);
    }
    return vec4(col, cover);
}


// ===========================================================================
//  METEORS  (random times & directions, but fully periodic -> seamless loop)
// ===========================================================================
vec3 meteors(vec3 rd, float pix, float ph) {
    if (uMeteors.x <= 0.0) return vec3(0.0);
    vec2 sp = rd.xy / max(-rd.z, 0.05);                      // sky position in tangent units
    float loopT = ph * 0.15915494;                          // 0..1 within the loop
    float dur = 1.1 / max(uMeteors.y, 1.0);                 // ~1.1 s of flight, in loop units
    vec3 col = vec3(0.0);
    for (int i = 0; i < 16; i++) {
        vec3 h = hash33(vec3(float(i) * 7.0 + 3.0, 11.0, 29.0));
        if (h.z > uMeteors.x) continue;                      // frequency slider
        float start = h.x;                                   // random moment within the loop
        float tt = fract(loopT - start) / dur;              // 0..1 while flying
        if (tt >= 1.0) continue;
        vec3 h2 = hash33(vec3(float(i) * 13.0 + 5.0, 3.0, 17.0));
        vec2 p0 = vec2(-0.30 + 0.45 * h2.x, 0.05 + 0.50 * h2.y);
        float ang = -2.2 - 0.9 * h2.z;                       // heading down-left .. down
        vec2 dir = vec2(cos(ang), sin(ang));
        float len = 0.07 + 0.08 * h.y;
        vec2 head = p0 + dir * (0.25 * tt);
        vec2 dp = sp - head;
        float along = dot(dp, -dir);                          // distance behind the head
        float across = abs(dot(dp, vec2(-dir.y, dir.x)));
        if (along < -pix * 3.0 || along > len) continue;
        float w = pix * 0.9;
        float tail = clamp(1.0 - along / len, 0.0, 1.0);
        float life = sin(3.14159 * tt);
        float core = exp(-across * across / (w * w)) * tail * tail;
        float headGlow = exp(-dot(dp, dp) / (w * w * 4.0));
        col += vec3(0.85, 0.92, 1.0) * (core * 0.9 + headGlow * 1.2) * life;
    }
    return col;
}



void main() {
    vec2 uv = gl_FragCoord.xy / uRes * 2.0 - 1.0;
    float aspect = uRes.x / uRes.y;
    float ph = uPhase;
    float pix = 2.0 * TAN_V / uRes.y;

    // slow cinematic camera rotation + gyroscope rotation (affects every layer equally)
    float drift = uToggles.z;
    float yaw   = drift * (0.008 * sin(ph * 2.0) + 0.004 * sin(ph * 5.0 + 1.0)) + uCam.x;
    float pitch = drift * (0.006 * sin(ph * 3.0 + 0.5)) + uCam.y;
    float roll  = drift * 0.005 * sin(ph * 2.0 + 2.0);
    vec3 ro = vec3(0.0);
    vec3 rd = normalize(vec3(uv.x * TAN_V * aspect, uv.y * TAN_V, -1.0));
    rd = rotY(yaw) * rotX(pitch) * rotZ(roll) * rd;

    // per-layer parallax: stars / Milky Way move least, Moon more, Earth most
    vec2 sh = uCam.zw;
    vec3 ec = PB_C + vec3(sh * PL_PARALLAX_EARTH, 0.0)
            + drift * vec3(0.35 * sin(ph * 2.0 + 0.3), 0.25 * sin(ph * 3.0), 0.0);

    float bTca, bD;
    vec2 pb = sphere(ro, rd, ec, PB_R, pix, bTca, bD);

    // ---- sky ----
    vec3 col = vec3(0.0006, 0.0010, 0.0032);
    if (pb.y < 1.0) {
        float mw = milkyWayBand(rd);
        if (uToggles.x > 0.5) {
            col += starfield(rd, pix, ph, mw);
            col += brightStars(rd, pix, ph);
        }
        col += milkyWay(rd, pix);
        col += meteors(rd, pix, ph);
        if (uPlanets.x > 0.5) {
            vec4 pl = driftingPlanets(ro, rd, pix, ph);
            col = col * (1.0 - pl.a) + pl.rgb;
        }
    }

    // ---- Moon (in front of the Milky Way) ----
    float moonCover = 0.0;
    if (uMoon.w > 0.5) {
        vec3 md = screenDir(uMoon.xy);
        vec3 mc = md * MOON_DIST + vec3(sh * PL_PARALLAX_MOON, 0.0)
                + vec3(0.30 * sin(ph), 0.15 * sin(ph * 2.0 + 1.0), 0.0);
        float mr = MOON_R0 * uMoon.z;
        float mTca, mD;
        vec2 mo = sphere(ro, rd, mc, mr, pix * 1.8, mTca, mD);         // slightly soft edge
        if (mo.y > 0.0) {
            col = mix(col, shadeMoon(rd, rd * mo.x, mc, mr, mo.x, pix), mo.y);
            moonCover = mo.y;
        }
    }

    // ---- Earth ----
    if (pb.y > 0.0) {
        vec3 P = rd * pb.x;
        col = mix(col, shadeEarth(rd, P, ec, pb.x, pix, ph), pb.y);
    }
    col += earthRim(rd, ec, bTca, bD) * (1.0 - moonCover);

    // ---- sunrise flare: starburst on the limb + full-width anamorphic streak ----
    if (uToggles.w > 0.5) {
        float breathe = 0.80 + 0.20 * sin(ph * 16.0) + 0.06 * sin(ph * 37.0);
        vec3 sc = ec;
        float limbAng = asin(clamp(PB_R / length(sc), 0.0, 1.0));
        float sunOff = acos(clamp(dot(normalize(sc), SUN), -1.0, 1.0));
        float vis = clamp((sunOff - limbAng + SUN_ANG) / (2.0 * SUN_ANG), 0.0, 1.0);
        float leak = exp(-max(limbAng - sunOff, 0.0) / 0.02);
        float glow = (0.40 * leak + 0.60 * vis) * breathe * step(0.0, dot(rd, SUN));
        vec3 dv = rd - SUN;
        float x = dv.x, y = dv.y;
        float a = length(cross(rd, SUN));
        float th = atan(y, x);
        float rays = pow(abs(cos(th * 4.0)), 40.0) * exp(-a / 0.025) * 0.6
                   + pow(abs(cos(th * 4.0 + 0.39)), 60.0) * exp(-a / 0.015) * 0.35;
        vec3 flare = vec3(1.0, 0.98, 0.95) * vis * 6.0 * smoothstep(SUN_ANG * 1.3, SUN_ANG * 0.6, a) * (1.0 - pb.y)
                   + vec3(0.95, 0.98, 1.0) * glow * (2.6 * exp(-a / 0.008) + 0.9 * exp(-a / 0.03) + rays)
                   + vec3(0.30, 0.70, 1.0) * glow * (0.30 * exp(-a / 0.08) + 0.04 * exp(-a / 0.3));
        // anamorphic streak: thin, across the whole width, fading to the edges
        float streak = exp(-abs(y) / 0.0022) * (0.75 * exp(-abs(x) / 0.30) + 0.35 * exp(-abs(x) / 0.06));
        streak += exp(-abs(y) / 0.008) * exp(-abs(x) / 0.12) * 0.15;
        flare += vec3(0.45, 0.75, 1.0) * streak * glow * 1.3;
        col += flare;
    }

    // filmic tone-map + gamma (bloom, grain and dithering are applied in composite.frag)
    col = 1.0 - exp(-col * 1.15);
    col = pow(col, vec3(1.0 / 2.2));
    fragColor = vec4(col, 1.0);
}
