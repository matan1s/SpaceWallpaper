#version 300 es
// ---------------------------------------------------------------------------
//  Deep Space - STATIC SKY BAKE (v3.4)
//  Runs ONCE (on load / when star settings, quality or screen size change), never per frame.
//  Renders the procedural Milky Way, nebulae, the star field and the bright stars into two
//  textures covering the visible tangent plane plus a margin for camera / parallax motion:
//    out 0 (RGB10_A2): Milky Way + nebulae          rgb = cbrt(c / MW_SCALE)
//    out 1 (RGBA8)   : stars                          rgb = cbrt(c / ST_SCALE)
//                      a = twinkle code of the dominant star at this texel (exact, 0..255):
//                          code <  240: k = 10 + 2*(code/16), phase = (code%16) * 2PI/16, amp 0.25
//                          code >= 240: bright star, k = code - 236, amp 0.15
//  scene.frag samples these and only animates the twinkle per frame.
// ---------------------------------------------------------------------------
precision highp float;
precision highp int;

uniform mediump sampler3D uNoise;
uniform vec2  uBakeRes;      // bake target size (pixels)
uniform vec2  uTanExt;       // tangent-plane half extent covered by the bake (x, y)
uniform float uAspect;       // screen aspect (w / h) - bright stars are placed in screen fractions
uniform float uPix;          // angular size of one SCENE pixel (stars are sized in scene pixels)
uniform int   uOct;
uniform vec2  uStars;        // x density, y brightness multipliers
uniform float uStarsOn;      // 0 = no stars at all

layout(location = 0) out vec4 outMilkyWay;
layout(location = 1) out vec4 outStars;

#include "common.glsl"

// screen fraction (origin top-left) -> camera-space direction at rest
vec3 screenDir(vec2 f) {
    return normalize(vec3((f.x - 0.5) * 2.0 * TAN_V * uAspect, (0.5 - f.y) * 2.0 * TAN_V, -1.0));
}

// ---- Milky Way geometry ----
float mwCoords(vec3 rd, out float along) {
    vec3 e2 = cross(MW_N, MW_C);
    along = atan(dot(rd, e2), dot(rd, MW_C));               // 0 at the core
    return dot(rd, MW_N) - 0.05 * along * along;             // slightly bowed band
}

float milkyWayBand(vec3 rd) {
    float along;
    float b = mwCoords(rd, along);
    float w = 0.050 + 0.030 * exp(-along * along * 6.0);
    return exp(-pow(b / w, 2.0));
}

// ---- star field: returns colour, and the dominant star's twinkle code ----
vec3 starfield(vec3 d, float pix, float band, inout float best, inout float code) {
    vec3 col = vec3(0.0);
    for (int l = 0; l < 5; l++) {
        float S = l == 0 ? 60.0 : (l == 1 ? 150.0 : (l == 2 ? 340.0 : (l == 3 ? 760.0 : 1500.0)));
        float dens = (l == 0 ? 0.07 : (l == 1 ? 0.10 : (l == 2 ? 0.18 : (l == 3 ? 0.16 : 0.06))))
                   + band * (l == 0 ? 0.05 : (l == 1 ? 0.30 : (l == 2 ? 0.60 : (l == 3 ? 0.84 : 0.94))));
        dens *= uStars.x;
        vec3 q = d * S;
        vec3 h = hash33(q + float(l) * 71.0);
        if (h.x > dens) continue;
        vec3 sp = floor(q) + 0.2 + 0.6 * hash33(q + 13.0 + float(l) * 29.0);
        float ang = length(cross(d, normalize(sp)));
        float size = pix * (l == 0 ? 1.1 : (l == 4 ? 0.65 : 0.75));
        float b = exp(-ang * ang / (size * size));
        float mag = l == 0 ? 0.60 : (l == 1 ? 0.26 : (l == 2 ? 0.12 : (l == 3 ? 0.065 : 0.045)));
        mag *= (pow(h.y, 2.0) + 0.15) * uStars.y * (1.0 + (l >= 2 ? 2.2 : 0.8) * band);
        vec3 tint = mix(vec3(0.62, 0.76, 1.0), vec3(1.0, 0.90, 0.78), fract(h.y * 7.0));
        tint = mix(tint, vec3(0.70, 0.80, 1.0), band * 0.4);      // cooler stars around the band
        vec3 c = tint * b * mag;
        col += c;
        float lum = b * mag;
        if (lum > best) {                                         // same k / phase as v3.3
            best = lum;
            float ki = clamp(floor(h.z * 15.0), 0.0, 14.0);       // k = 10 + 2*ki  (10..38)
            float pi = floor(fract(h.y) * 16.0);                  // phase = pi * 2PI/16
            code = ki * 16.0 + pi;
        }
    }
    return col;
}

// bright stars with 4-point diffraction spikes (screen-aligned)
vec3 brightStar(vec3 rd, vec2 at, float pix, float mag, float k, inout float best, inout float code) {
    vec3 sd = screenDir(at);
    vec3 dv = rd - sd;
    float x = dv.x, y = dv.y;
    float r2 = x * x + y * y;
    float w = pix * 0.9;
    float core = exp(-r2 / (w * w * 1.6)) * 2.5 + exp(-sqrt(r2) / (pix * 3.0)) * 0.30;
    float spikes = (exp(-abs(x) / (pix * 7.0)) * exp(-y * y / (w * w * 0.25))
                  + exp(-abs(y) / (pix * 7.0)) * exp(-x * x / (w * w * 0.25))) * 0.8;
    float lum = (core + spikes) * mag * uStars.y;
    if (lum > best) {
        best = lum;
        code = 236.0 + k;                                         // k 4..19 -> 240..255
    }
    return vec3(0.80, 0.88, 1.0) * lum;
}

vec3 brightStars(vec3 rd, float pix, inout float best, inout float code) {
    vec3 c = vec3(0.0);
    c += brightStar(rd, vec2(0.55, 0.08), pix, 1.0, 7.0, best, code);
    c += brightStar(rd, vec2(0.38, 0.83), pix, 0.9, 9.0, best, code);
    c += brightStar(rd, vec2(0.24, 0.74), pix, 0.7, 11.0, best, code);
    c += brightStar(rd, vec2(0.10, 0.88), pix, 0.5, 13.0, best, code);
    c += brightStar(rd, vec2(0.33, 0.18), pix, 0.45, 5.0, best, code);
    c += brightStar(rd, vec2(0.05, 0.36), pix, 0.4, 8.0, best, code);
    return c;
}

// ---- Milky Way: curved band, star clouds, warm core, magenta nebulae, filamentary dust ----
vec3 milkyWay(vec3 rd, float pix) {
    float along;
    float b = mwCoords(rd, along);
    vec3 p = rd * 7.0;
    b += (fbm(p * 0.9 + 3.1, 4, pix * 6.0) - 0.5) * 0.035;      // ragged, organic edges
    float w = 0.045 + 0.030 * exp(-along * along * 6.0);          // wider around the core
    float band = exp(-pow(b / w, 2.0));
    float halo = exp(-pow(b / (w * 2.2), 2.0));
    if (halo < 0.004) return vec3(0.0);

    int o = uOct + 1;
    float core = exp(-along * along * 10.0) * exp(-pow(b / (w * 1.1), 2.0));

    float n1 = fbm(p * 3.0 + 1.3, o, pix * 21.0);
    float clouds = smoothstep(0.42, 0.64, n1);
    float g2 = fbm(p * 7.0 + 8.3, o, pix * 49.0);
    float knots = smoothstep(0.45, 0.70, g2);
    float glow = band * (0.05 + 0.9 * clouds * (0.4 + knots)) + core * (0.25 + 1.2 * clouds * knots) + halo * 0.02;

    vec3 beige = vec3(1.00, 0.83, 0.64);
    vec3 brown = vec3(0.60, 0.42, 0.30);
    vec3 blue  = vec3(0.60, 0.72, 1.00);
    float g = fbm(p * 6.0 + 4.7, o, pix * 42.0);
    vec3 tint = mix(blue, mix(brown, beige, smoothstep(0.4, 0.7, g)), smoothstep(0.25, 0.85, band) * 0.9);
    vec3 col = tint * glow * 0.13;
    col += vec3(1.0, 0.88, 0.70) * core * core * clouds * 0.30;  // glowing core near (15%,50%)

    float nebZone = smoothstep(0.10, 0.40, along) * smoothstep(1.10, 0.55, along);
    float neb = smoothstep(0.50, 0.74, fbm(p * 4.0 + 21.0, o, pix * 28.0)) * nebZone * band;
    col += vec3(0.95, 0.26, 0.62) * neb * 0.22;

    vec3 wq = p * 3.0 + vec3(fbm(p * 1.5 + 7.0, 4, pix * 10.0), fbm(p * 1.5 + 17.0, 4, pix * 10.0),
                             fbm(p * 1.5 + 27.0, 4, pix * 10.0)) * 2.5;
    float dust = smoothstep(0.44, 0.56, fbm(wq * 1.3, o, pix * 27.0));
    float fil = smoothstep(0.60, 0.82, ridged(wq * 2.2 + 5.0, o, pix * 47.0));
    float centre = exp(-pow((b + 0.006) / (w * 0.6), 2.0));
    col *= 1.0 - clamp((0.90 * dust + 0.70 * fil) * (0.45 + 0.55 * centre) * smoothstep(0.05, 0.5, band), 0.0, 0.95);
    return col;
}

// static dither (+-0.5 LSB) so the encoded gradients never band
float dither(vec2 fc, float salt) {
    return fract(52.9829189 * fract(dot(fc + salt, vec2(0.06711056, 0.00583715)))) - 0.5;
}

void main() {
    vec2 st = gl_FragCoord.xy / uBakeRes;                          // 0..1 over the tangent rectangle
    vec2 tp = (st * 2.0 - 1.0) * uTanExt;
    vec3 rd = normalize(vec3(tp, -1.0));
    float pix = uPix;

    vec3 mw = milkyWay(rd, pix);
    vec3 stars = vec3(0.0);
    float best = 0.0, code = 0.0;
    if (uStarsOn > 0.5) {
        float band = milkyWayBand(rd);
        stars = starfield(rd, pix, band, best, code) + brightStars(rd, pix, best, code);
    }
    vec3 encMW = pow(clamp(mw / MW_SCALE, 0.0, 1.0), vec3(1.0 / 3.0));
    vec3 encST = pow(clamp(stars / ST_SCALE, 0.0, 1.0), vec3(1.0 / 3.0));
    encMW += dither(gl_FragCoord.xy, 0.0) / 1023.0;               // RGB10 target
    encST += dither(gl_FragCoord.xy, 7.0) / 255.0 * step(1e-5, dot(stars, vec3(1.0)));
    outMilkyWay = vec4(clamp(encMW, 0.0, 1.0), 1.0);
    outStars = vec4(clamp(encST, 0.0, 1.0), code / 255.0);
}
