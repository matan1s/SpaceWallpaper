package com.matan.spacewallpaper;

import java.util.Random;

/**
 * Meteor / shooting-star schedule, computed on the CPU once per frame (a few dozen float ops)
 * instead of every pixel testing 16 meteors with hash functions on the GPU (v3.3).
 *
 * 16 meteor "slots" get a random start moment inside the loop, a random start point, heading and
 * tail length (fixed seed -> the same every run). The frequency slider enables a subset of slots.
 * Everything is a function of the loop position, so the loop stays seamless. At most two meteors
 * are passed to the shader. No allocations after construction.
 */
final class Meteors {
    private static final int SLOTS = 16;
    private static final float FLIGHT_SECONDS = 1.1f;

    private final float[] start = new float[SLOTS];
    private final float[] enable = new float[SLOTS];
    private final float[] len = new float[SLOTS];
    private final float[] p0x = new float[SLOTS];
    private final float[] p0y = new float[SLOTS];
    private final float[] heading = new float[SLOTS];

    /** shader uniforms: head.x, head.y (tangent units), heading (rad), life (0..1; 0 = none) */
    final float[] a = new float[4];
    final float[] b = new float[4];
    float lenA, lenB;

    Meteors() {
        Random r = new Random(20261026L);
        for (int i = 0; i < SLOTS; i++) {
            start[i] = r.nextFloat();
            enable[i] = r.nextFloat();
            len[i] = 0.07f + 0.08f * r.nextFloat();
            p0x[i] = -0.30f + 0.45f * r.nextFloat();
            p0y[i] = 0.05f + 0.50f * r.nextFloat();
            heading[i] = -2.2f - 0.9f * r.nextFloat();        // down-left .. down
        }
    }

    /**
     * @param loopT       position in the loop, 0..1
     * @param amount      fraction of slots enabled (0 = meteors off)
     * @param loopSeconds loop length, converts the flight time into loop units
     */
    void update(double loopT, float amount, float loopSeconds) {
        a[3] = 0f;
        b[3] = 0f;
        if (amount <= 0f) return;
        double dur = FLIGHT_SECONDS / Math.max(loopSeconds, 1f);
        int found = 0;
        for (int i = 0; i < SLOTS && found < 2; i++) {
            if (enable[i] > amount) continue;
            double rel = loopT - start[i];
            rel -= Math.floor(rel);                              // fract -> periodic
            double tt = rel / dur;
            if (tt >= 1.0) continue;
            float life = (float) Math.sin(Math.PI * tt);
            float hx = p0x[i] + (float) (Math.cos(heading[i]) * 0.25 * tt);
            float hy = p0y[i] + (float) (Math.sin(heading[i]) * 0.25 * tt);
            float[] out = found == 0 ? a : b;
            out[0] = hx;
            out[1] = hy;
            out[2] = heading[i];
            out[3] = life;
            if (found == 0) lenA = len[i]; else lenB = len[i];
            found++;
        }
    }
}
