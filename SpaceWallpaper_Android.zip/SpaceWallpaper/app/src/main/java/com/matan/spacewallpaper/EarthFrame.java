package com.matan.spacewallpaper;

/**
 * Orientation of the Earth globe on screen.
 *
 * Builds the 3x3 matrix (camera space -> Earth texture space) that puts a chosen latitude /
 * longitude under a chosen screen point, with north pointing up (optionally tilted).
 * Earth centre and radius must match scene.frag (PB_C / PB_R).
 */
final class EarthFrame {
    /** Earth centre / radius in camera space - must match scene.frag */
    static final double CX = 35.98335, CY = -2.73510, CZ = -65.74738, R = 37.7387;
    /** Shader camera: tan(half vertical FOV) and the target portrait aspect (S25 Ultra) */
    private static final double TAN_V = 0.62, ASPECT = 1440.0 / 3120.0;

    private EarthFrame() {}

    /**
     * @param outColMajor 9 floats, column-major (ready for glUniformMatrix3fv)
     * @param outRowMajor 9 doubles, row-major (for CPU maths), may be null
     * @param fx, fy screen point as fraction of width / height (origin top-left)
     */
    static void build(float[] outColMajor, double[] outRowMajor, double latDeg, double lonDeg,
                      double fx, double fy, double tiltDeg) {
        // globe point under the screen point
        double dx = (fx - 0.5) * 2.0 * TAN_V * ASPECT, dy = (0.5 - fy) * 2.0 * TAN_V, dz = -1.0;
        double dl = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= dl; dy /= dl; dz /= dl;
        double b = dx * CX + dy * CY + dz * CZ;
        double h = b * b - (CX * CX + CY * CY + CZ * CZ) + R * R;
        double t = b - Math.sqrt(Math.max(h, 0.0));
        double nx = (dx * t - CX) / R, ny = (dy * t - CY) / R, nz = (dz * t - CZ) / R;

        // camera-space frame at that point: right, up, normal (+ optional tilt)
        double ux = -nx * ny, uy = 1.0 - ny * ny, uz = -nz * ny;
        double ul = Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux /= ul; uy /= ul; uz /= ul;
        double rx = uy * nz - uz * ny, ry = uz * nx - ux * nz, rz = ux * ny - uy * nx;   // up x n
        double a = Math.toRadians(tiltDeg), ca = Math.cos(a), sa = Math.sin(a);
        double ux2 = ux * ca + rx * sa, uy2 = uy * ca + ry * sa, uz2 = uz * ca + rz * sa;
        double rx2 = rx * ca - ux * sa, ry2 = ry * ca - uy * sa, rz2 = rz * ca - uz * sa;

        // texture-space frame at lat/lon: east, north, outward normal
        double la = Math.toRadians(latDeg), lo = Math.toRadians(lonDeg);
        double px = Math.cos(la) * Math.sin(lo), py = Math.sin(la), pz = Math.cos(la) * Math.cos(lo);
        double qx = -px * py, qy = 1.0 - py * py, qz = -pz * py;
        double ql = Math.sqrt(qx * qx + qy * qy + qz * qz);
        qx /= ql; qy /= ql; qz /= ql;
        double ex = qy * pz - qz * py, ey = qz * px - qx * pz, ez = qx * py - qy * px;   // north x p

        // M = [e q p] * [r u n]^T
        double[] T = {ex, qx, px, ey, qy, py, ez, qz, pz};
        double[] C = {rx2, ux2, nx, ry2, uy2, ny, rz2, uz2, nz};
        double[] m = outRowMajor != null ? outRowMajor : new double[9];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                m[i * 3 + j] = T[i * 3] * C[j * 3] + T[i * 3 + 1] * C[j * 3 + 1] + T[i * 3 + 2] * C[j * 3 + 2];
            }
        }
        for (int col = 0; col < 3; col++) {
            for (int row = 0; row < 3; row++) {
                outColMajor[col * 3 + row] = (float) m[row * 3 + col];
            }
        }
    }
}
