package com.matan.spacewallpaper;

import android.opengl.GLSurfaceView;
import android.util.Log;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;

/**
 * Creates the wallpaper's OpenGL ES 3 context with LOW GPU scheduling priority
 * (EGL_IMG_context_priority, supported by Adreno / Snapdragon). The GPU then always runs the
 * launcher's frames first, so the wallpaper can never delay a home-screen swipe; it simply fills
 * the idle time. Falls back to a normal context when the extension is missing or refused.
 */
final class LowPriorityContextFactory implements GLSurfaceView.EGLContextFactory {
    private static final String TAG = "LowPriorityContext";
    private static final int EGL_CONTEXT_CLIENT_VERSION = 0x3098;
    private static final int EGL_CONTEXT_PRIORITY_LEVEL_IMG = 0x3100;
    private static final int EGL_CONTEXT_PRIORITY_LOW_IMG = 0x3103;

    /** for the debug overlay: true when the last context really got low priority */
    static volatile boolean lowPriorityActive;

    private final boolean lowPriority;

    LowPriorityContextFactory(boolean lowPriority) {
        this.lowPriority = lowPriority;
    }

    @Override
    public EGLContext createContext(EGL10 egl, EGLDisplay display, EGLConfig config) {
        if (lowPriority) {
            String ext = egl.eglQueryString(display, EGL10.EGL_EXTENSIONS);
            if (ext != null && ext.contains("EGL_IMG_context_priority")) {
                int[] attrs = {EGL_CONTEXT_CLIENT_VERSION, 3,
                        EGL_CONTEXT_PRIORITY_LEVEL_IMG, EGL_CONTEXT_PRIORITY_LOW_IMG, EGL10.EGL_NONE};
                EGLContext c = egl.eglCreateContext(display, config, EGL10.EGL_NO_CONTEXT, attrs);
                if (c != null && c != EGL10.EGL_NO_CONTEXT) {
                    lowPriorityActive = true;
                    return c;
                }
                Log.w(TAG, "low-priority context refused, using a normal one");
            }
        }
        lowPriorityActive = false;
        int[] attrs = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL10.EGL_NONE};
        return egl.eglCreateContext(display, config, EGL10.EGL_NO_CONTEXT, attrs);
    }

    @Override
    public void destroyContext(EGL10 egl, EGLDisplay display, EGLContext context) {
        if (!egl.eglDestroyContext(display, context)) {
            Log.w(TAG, "eglDestroyContext failed: 0x" + Integer.toHexString(egl.eglGetError()));
        }
    }
}
