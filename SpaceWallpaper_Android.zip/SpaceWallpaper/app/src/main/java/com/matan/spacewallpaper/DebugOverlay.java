package com.matan.spacewallpaper;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.opengl.GLES30;
import android.opengl.GLUtils;

/**
 * Optional on-screen performance readout (Settings > "Performance overlay").
 *
 *   FPS 30.0 / target 30    IDLE | SWIPE | MOVE
 *   CPU 0.6 ms   GPU 1.8 ms (max 2.4)
 *   scene 1080x2340 (75%)   bloom 1
 *   thermal 0   sky bake 21 ms   GPU prio LOW
 *
 * Statistics are averaged over 0.5 s windows. The text bitmap is redrawn and uploaded only when a
 * window closes (twice per second); everything is pre-allocated, so it adds no per-frame garbage.
 * GPU time comes from GL_EXT_disjoint_timer_query (measured by SpaceRenderer), "n/a" if unsupported.
 */
final class DebugOverlay {
    private static final int TW = 720, TH = 216;
    private static final long WINDOW_NS = 500_000_000L;

    private final Bitmap bitmap = Bitmap.createBitmap(TW, TH, Bitmap.Config.ARGB_8888);
    private final Canvas canvas = new Canvas(bitmap);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint panel = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final char[] buf = new char[96];
    private int len;

    private int tex;
    private int prog, uTex, uRect;
    private boolean dirty = true;

    // window accumulators
    private long windowStart;
    private int frames;
    private double cpuSum, gpuSum, gpuMax;
    private int gpuCount;
    // published values
    private float fps, cpuMs, gpuMs = -1f, gpuMaxMs;
    private float bakeMs = -1f;

    DebugOverlay() {
        text.setColor(Color.WHITE);
        text.setTextSize(34f);
        text.setTypeface(Typeface.MONOSPACE);
        panel.setColor(0xB0000000);
    }

    /** GL thread, after context (re)creation. */
    void onSurfaceCreated(int program) {
        prog = program;
        if (prog != 0) {
            uTex = GLES30.glGetUniformLocation(prog, "uTex");
            uRect = GLES30.glGetUniformLocation(prog, "uRect");
        }
        int[] t = new int[1];
        GLES30.glGenTextures(1, t, 0);
        tex = t[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex);
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bitmap, 0);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
        windowStart = 0L;
        dirty = true;
    }

    void setBakeMs(float ms) {
        bakeMs = ms;
        dirty = true;
    }

    /**
     * Records one frame. gpuMsOrNeg < 0 = no GPU result this frame.
     * @return true when a new 0.5 s window was published (text will be refreshed)
     */
    boolean frame(long nowNs, float cpuMsThis, float gpuMsOrNeg) {
        if (windowStart == 0L) {
            windowStart = nowNs;
            return false;
        }
        frames++;
        cpuSum += cpuMsThis;
        if (gpuMsOrNeg >= 0f) {
            gpuSum += gpuMsOrNeg;
            gpuCount++;
            if (gpuMsOrNeg > gpuMax) gpuMax = gpuMsOrNeg;
        }
        long dt = nowNs - windowStart;
        if (dt < WINDOW_NS) return false;
        fps = (float) (frames * 1e9 / dt);
        cpuMs = (float) (cpuSum / Math.max(frames, 1));
        if (gpuCount > 0) {
            gpuMs = (float) (gpuSum / gpuCount);
            gpuMaxMs = (float) gpuMax;
        }
        frames = 0;
        gpuCount = 0;
        cpuSum = gpuSum = gpuMax = 0.0;
        windowStart = nowNs;
        dirty = true;
        return true;
    }

    /** Draws the overlay at the top-left (below the status bar). GL thread. */
    void draw(int surfW, int surfH, int targetFps, int state, int sceneW, int sceneH, int scalePct,
              int bloomPasses, int thermal, boolean timerSupported) {
        if (prog == 0 || tex == 0) return;
        if (dirty) {
            redraw(targetFps, state, sceneW, sceneH, scalePct, bloomPasses, thermal, timerSupported);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex);
            GLUtils.texSubImage2D(GLES30.GL_TEXTURE_2D, 0, 0, 0, bitmap);
            dirty = false;
        }
        int w = Math.round(surfW * 0.70f);
        int h = Math.round(w * (float) TH / TW);
        int x = Math.round(surfW * 0.04f);
        int y = surfH - Math.round(surfH * 0.065f) - h;                 // GL origin is bottom-left
        GLES30.glViewport(x, y, w, h);
        GLES30.glEnable(GLES30.GL_BLEND);
        GLES30.glBlendFunc(GLES30.GL_ONE, GLES30.GL_ONE_MINUS_SRC_ALPHA);
        GLES30.glUseProgram(prog);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex);
        GLES30.glUniform1i(uTex, 0);
        GLES30.glUniform4f(uRect, x, y, w, h);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
        GLES30.glDisable(GLES30.GL_BLEND);
        GLES30.glViewport(0, 0, surfW, surfH);
    }

    // ------------------------------------------------------------------ text (allocation-free)
    private void redraw(int targetFps, int state, int sceneW, int sceneH, int scalePct,
                        int bloomPasses, int thermal, boolean timerSupported) {
        canvas.drawColor(0, PorterDuff.Mode.CLEAR);
        canvas.drawRoundRect(0f, 0f, TW, TH, 18f, 18f, panel);
        float lh = 46f, x = 18f, y = 44f;

        len = 0;
        put("FPS ");
        putFloat1(fps);
        put(" / target ");
        if (targetFps > 0) putInt(targetFps); else put("display");
        put(state == 2 ? "  SWIPE" : state == 1 ? "  MOVE" : "  IDLE");
        canvas.drawText(buf, 0, len, x, y, text);

        len = 0;
        put("CPU ");
        putFloat1(cpuMs);
        put(" ms   GPU ");
        if (timerSupported && gpuMs >= 0f) {
            putFloat1(gpuMs);
            put(" ms (max ");
            putFloat1(gpuMaxMs);
            put(")");
        } else {
            put("n/a");
        }
        canvas.drawText(buf, 0, len, x, y + lh, text);

        len = 0;
        put("scene ");
        putInt(sceneW);
        put("x");
        putInt(sceneH);
        put(" (");
        putInt(scalePct);
        put("%)   bloom ");
        putInt(bloomPasses);
        canvas.drawText(buf, 0, len, x, y + 2 * lh, text);

        len = 0;
        put("thermal ");
        putInt(thermal);
        put("   sky bake ");
        if (bakeMs >= 0f) {
            putInt(Math.round(bakeMs));
            put(" ms");
        } else {
            put("-");
        }
        put("   GPU prio ");
        put(LowPriorityContextFactory.lowPriorityActive ? "LOW" : "normal");
        canvas.drawText(buf, 0, len, x, y + 3 * lh, text);
    }

    private void put(String s) {
        for (int i = 0; i < s.length() && len < buf.length; i++) buf[len++] = s.charAt(i);
    }

    private void putInt(int v) {
        if (v < 0) {
            put("-");
            v = -v;
        }
        int start = len;
        do {
            if (len >= buf.length) return;
            buf[len++] = (char) ('0' + v % 10);
            v /= 10;
        } while (v > 0);
        for (int i = start, j = len - 1; i < j; i++, j--) {                // reverse digits
            char c = buf[i];
            buf[i] = buf[j];
            buf[j] = c;
        }
    }

    private void putFloat1(float v) {
        int t = Math.round(Math.max(v, 0f) * 10f);
        putInt(t / 10);
        put(".");
        putInt(t % 10);
    }
}
