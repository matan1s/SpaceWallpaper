package com.matan.spacewallpaper;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Random;

/**
 * Builds a small tileable 64^3 band-limited noise volume once (about 256 KB).
 * All planet, cloud and moon detail in the shader is sampled from it, which is far cheaper
 * than computing procedural noise per pixel.
 */
final class NoiseTexture {
    static final int SIZE = 64;
    private static ByteBuffer cached;

    private NoiseTexture() {}

    static synchronized ByteBuffer get() {
        if (cached == null) cached = build(1234L);
        cached.position(0);
        return cached;
    }

    private static ByteBuffer build(long seed) {
        final int n = SIZE, n3 = n * n * n;
        Random rnd = new Random(seed);
        float[] a = new float[n3];
        float[] b = new float[n3];
        for (int i = 0; i < n3; i++) a[i] = rnd.nextFloat();

        final float[] k = {1f / 16f, 4f / 16f, 6f / 16f, 4f / 16f, 1f / 16f};
        // separable wrap-around blur along x, y, z
        for (int axis = 0; axis < 3; axis++) {
            for (int z = 0; z < n; z++) {
                for (int y = 0; y < n; y++) {
                    for (int x = 0; x < n; x++) {
                        float s = 0f;
                        for (int t = -2; t <= 2; t++) {
                            int xx = x, yy = y, zz = z;
                            if (axis == 0) xx = (x + t + n) % n;
                            else if (axis == 1) yy = (y + t + n) % n;
                            else zz = (z + t + n) % n;
                            s += a[(zz * n + yy) * n + xx] * k[t + 2];
                        }
                        b[(z * n + y) * n + x] = s;
                    }
                }
            }
            float[] tmp = a; a = b; b = tmp;
        }

        double mean = 0;
        for (float v : a) mean += v;
        mean /= n3;
        double var = 0;
        for (float v : a) var += (v - mean) * (v - mean);
        double sd = Math.sqrt(var / n3);

        ByteBuffer buf = ByteBuffer.allocateDirect(n3).order(ByteOrder.nativeOrder());
        for (int i = 0; i < n3; i++) {
            double v = (a[i] - mean) / (sd * 3.2) * 0.5 + 0.5;
            v = Math.max(0.0, Math.min(1.0, v));
            buf.put((byte) (int) Math.round(v * 255.0));
        }
        buf.position(0);
        return buf;
    }
}
