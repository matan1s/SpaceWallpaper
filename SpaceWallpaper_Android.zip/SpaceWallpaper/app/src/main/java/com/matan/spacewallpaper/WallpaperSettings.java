package com.matan.spacewallpaper;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * All user settings. Immutable snapshots are created ONLY when a preference changes (via a
 * SharedPreferences listener) and handed to the renderer, so the GL thread never touches
 * SharedPreferences and never allocates per frame.
 */
public final class WallpaperSettings {

    public static final String PREFS = "space_wallpaper_settings";

    public static final String KEY_QUALITY = "quality";          // render quality: battery | balanced | high
    public static final String KEY_FPS = "fps";                  // motion frame rate: 60 | auto (display rate)
    public static final String KEY_SPEED = "speed";              // very_slow | slow | normal
    public static final String KEY_PARALLAX = "parallax";
    public static final String KEY_PARALLAX_AMOUNT = "parallax_amount";   // 0..100
    public static final String KEY_MOTION = "motion";
    public static final String KEY_MOTION_AMOUNT = "motion_amount";       // 0..100
    public static final String KEY_STARS = "stars";
    public static final String KEY_STAR_DENSITY = "star_density";         // 0..100
    public static final String KEY_STAR_BRIGHTNESS = "star_brightness";   // 0..100
    public static final String KEY_REALTIME_SUN = "realtime_sun";
    public static final String KEY_MOON = "moon";
    public static final String KEY_MOON_SIZE = "moon_size";               // 0..100 (50 = natural)
    public static final String KEY_MOON_X = "moon_px";                    // 0..100 % of screen width (left..right)
    public static final String KEY_MOON_Y = "moon_py";                    // 0..100 % of screen height (top..bottom)
    public static final String KEY_FLARE = "flare";
    public static final String KEY_MOON_BRIGHTNESS = "moon_brightness";  // 0..100 (50 = default)
    public static final String KEY_CLOUDS = "clouds";
    public static final String KEY_CLOUD_OPACITY = "cloud_opacity";      // 0..100
    public static final String KEY_FLARE_INTENSITY = "flare_intensity";  // 0..100 (100 = v3.1 strength)
    public static final String KEY_EARTH_LIGHT = "earth_light";          // 0..100 (50 = default)
    public static final String KEY_CITY_LIGHTS = "city_lights";          // 0..100 (50 = default)
    public static final String KEY_KEEP_EUROPE = "keep_europe";
    public static final String KEY_PLANETS = "planets";
    public static final String KEY_DOF = "dof";                           // 0..100 depth-of-field strength
    public static final String KEY_METEORS = "meteors";
    public static final String KEY_METEOR_FREQ = "meteor_freq";           // 0..100
    public static final String KEY_ADAPTIVE_POWER = "adaptive_power";
    public static final String KEY_DEBUG_OVERLAY = "debug_overlay";
    /** settings schema version - used for one-time migrations */
    private static final String KEY_SCHEMA = "schema_version";
    private static final int SCHEMA = 34;
    /** kept only so older builds' preference files stay valid */
    public static final String KEY_SPACECRAFT = "spacecraft";

    public static final String QUALITY_BATTERY = "battery";
    public static final String QUALITY_BALANCED = "balanced";
    public static final String QUALITY_HIGH = "high";
    public static final String FPS_60 = "60";
    public static final String FPS_AUTO = "auto";
    public static final String SPEED_VERY_SLOW = "very_slow";
    public static final String SPEED_SLOW = "slow";
    public static final String SPEED_NORMAL = "normal";

    public final String quality;
    public final String fps;
    public final String speed;
    public final boolean parallax;
    public final int parallaxAmount;
    public final boolean motion;
    public final int motionAmount;
    public final boolean stars;
    public final int starDensity;
    public final int starBrightness;
    public final boolean realtimeSun;
    public final boolean moon;
    public final int moonSize;
    public final int moonX;
    public final int moonY;
    public final boolean planets;
    public final int dof;
    public final boolean meteors;
    public final int meteorFreq;
    public final boolean adaptivePower;
    public final boolean flare;
    public final int moonBrightness;
    public final boolean clouds;
    public final int cloudOpacity;
    public final int flareIntensity;
    public final int earthLight;
    public final int cityLights;
    public final boolean keepEurope;
    public final boolean debugOverlay;
    public final boolean spacecraft = false;

    private WallpaperSettings(SharedPreferences p) {
        quality = p.getString(KEY_QUALITY, QUALITY_BALANCED);  // v3.4: Balanced is the default
        fps = p.getString(KEY_FPS, FPS_60);
        speed = p.getString(KEY_SPEED, SPEED_VERY_SLOW);
        parallax = p.getBoolean(KEY_PARALLAX, true);
        parallaxAmount = p.getInt(KEY_PARALLAX_AMOUNT, 50);
        motion = p.getBoolean(KEY_MOTION, true);
        motionAmount = p.getInt(KEY_MOTION_AMOUNT, 50);
        stars = p.getBoolean(KEY_STARS, true);
        starDensity = p.getInt(KEY_STAR_DENSITY, 50);
        starBrightness = p.getInt(KEY_STAR_BRIGHTNESS, 50);
        realtimeSun = p.getBoolean(KEY_REALTIME_SUN, false);
        moon = p.getBoolean(KEY_MOON, true);
        moonSize = p.getInt(KEY_MOON_SIZE, 50);
        moonX = p.getInt(KEY_MOON_X, 26);      // reference composition: (26%, 26%)
        moonY = p.getInt(KEY_MOON_Y, 26);
        planets = p.getBoolean(KEY_PLANETS, false);   // off by default: keeps the reference look
        dof = p.getInt(KEY_DOF, 60);
        meteors = p.getBoolean(KEY_METEORS, true);
        meteorFreq = p.getInt(KEY_METEOR_FREQ, 30);
        adaptivePower = p.getBoolean(KEY_ADAPTIVE_POWER, true);
        flare = p.getBoolean(KEY_FLARE, true);
        moonBrightness = p.getInt(KEY_MOON_BRIGHTNESS, 50);
        clouds = p.getBoolean(KEY_CLOUDS, true);
        cloudOpacity = p.getInt(KEY_CLOUD_OPACITY, 100);
        flareIntensity = p.getInt(KEY_FLARE_INTENSITY, 50);   // default = 50% of the v3.1 flare
        earthLight = p.getInt(KEY_EARTH_LIGHT, 50);
        cityLights = p.getInt(KEY_CITY_LIGHTS, 50);
        keepEurope = p.getBoolean(KEY_KEEP_EUROPE, false);
        debugOverlay = p.getBoolean(KEY_DEBUG_OVERLAY, false);
    }

    public static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static WallpaperSettings load(Context c) {
        return new WallpaperSettings(prefs(c));
    }

    /**
     * One-time migration to v3.4: earlier versions defaulted to High (full resolution), which is
     * what made home-screen swipes stutter. Existing installs are moved to the new Balanced default
     * once; afterwards the user's own choice is always respected.
     */
    public static void migrate(Context c) {
        SharedPreferences p = prefs(c);
        if (p.getInt(KEY_SCHEMA, 0) >= SCHEMA) return;
        p.edit().putString(KEY_QUALITY, QUALITY_BALANCED).putInt(KEY_SCHEMA, SCHEMA).apply();
    }

    public boolean isBatterySaver() { return QUALITY_BATTERY.equals(quality); }

    /** Length of one seamless loop in seconds. */
    public float loopSeconds() {
        switch (speed) {
            case SPEED_NORMAL: return 120f;
            case SPEED_SLOW: return 240f;
            default: return 480f;
        }
    }

    /** Fraction of the screen resolution the scene is rendered at (GPU-upscaled). */
    public float renderScale() {
        switch (quality) {
            case QUALITY_BATTERY: return 0.5f;
            case QUALITY_BALANCED: return 0.75f;
            default: return 1.0f;          // native panel resolution
        }
    }

    /** Max noise octaves for procedural detail. */
    public int octaves() {
        switch (quality) {
            case QUALITY_BATTERY: return 4;
            case QUALITY_BALANCED: return 5;
            default: return 7;
        }
    }

    /** Texture down-sampling: 1 = full-size maps, 2 = half-size (Battery Saver). */
    public int textureSampleSize() {
        return isBatterySaver() ? 2 : 1;
    }

    /**
     * Frame rate while something is MOVING (home-screen swipe, phone tilt). When idle the wallpaper
     * always runs at 30 FPS (see FramePacer). Battery: 30; otherwise the user's choice:
     * 60, or 0 = follow the display (up to 120 Hz).
     */
    public int targetFps() {
        if (isBatterySaver()) return 30;
        return FPS_AUTO.equals(fps) ? 0 : 60;
    }

    /** Bloom blur passes (H+V pairs): 0 = no bloom. */
    public int bloomPasses() {
        switch (quality) {
            case QUALITY_BATTERY: return 0;
            case QUALITY_BALANCED: return 1;
            default: return 2;
        }
    }

    // ---- slider helpers (0..100 -> useful ranges) ----
    public float parallaxFactor() { return parallax ? parallaxAmount / 50f : 0f; }   // 0..2 (1 = default)
    public float motionFactor() { return motion ? motionAmount / 50f : 0f; }         // 0..2
    public float starDensityFactor() { return 0.25f + starDensity / 100f * 1.75f; }   // 0.25..2.0
    public float starBrightnessFactor() { return 0.2f + starBrightness / 100f * 1.8f; } // 0.2..2.0
    /** Moon size multiplier: 0 -> 0.5x, 50 -> 1x, 100 -> 2.5x */
    public float moonScale() {
        return moonSize <= 50 ? 0.5f + moonSize / 100f : 1f + (moonSize - 50) / 50f * 1.5f;
    }
    public float dofStrength() { return dof / 100f; }
    /** Flare strength actually applied: 0 when switched off; 0% intensity == off. */
    public float flareFactor() { return flare ? flareIntensity / 100f : 0f; }
    /** Cloud opacity 0..1 (0 when the cloud layer is switched off). */
    public float cloudOpacityFactor() { return clouds ? cloudOpacity / 100f : 0f; }
    /** Sunlight on the Earth: 0 -> 0.15x, 50 -> 1x, 100 -> 2x */
    public float earthLightFactor() {
        return earthLight <= 50 ? 0.15f + earthLight / 50f * 0.85f : 1f + (earthLight - 50) / 50f;
    }
    /** City lights: 0 -> off, 50 -> 1x, 100 -> 2x */
    public float cityLightsFactor() { return cityLights / 50f; }
    /** Moon brightness multiplier: 0 -> 0.4x, 50 -> 1x, 100 -> 1.8x */
    public float moonBrightnessFactor() {
        return moonBrightness <= 50 ? 0.4f + moonBrightness / 50f * 0.6f : 1f + (moonBrightness - 50) / 50f * 0.8f;
    }
    /** fraction of the 16 meteor slots used per loop (0 = off) */
    public float meteorAmount() { return meteors ? 0.08f + meteorFreq / 100f * 0.92f : 0f; }
}
