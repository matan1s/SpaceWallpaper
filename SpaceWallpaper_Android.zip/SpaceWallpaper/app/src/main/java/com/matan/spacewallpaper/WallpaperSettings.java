package com.matan.spacewallpaper;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * All user settings. Immutable snapshots are handed to the renderer so the GL thread
 * never touches SharedPreferences and never allocates per frame.
 */
public final class WallpaperSettings {

    public static final String PREFS = "space_wallpaper_settings";

    public static final String KEY_QUALITY = "quality";      // battery | balanced | high
    public static final String KEY_FPS = "fps";              // 60 | auto
    public static final String KEY_SPEED = "speed";          // very_slow | slow | normal
    public static final String KEY_PARALLAX = "parallax";
    public static final String KEY_MOTION = "motion";
    public static final String KEY_SPACECRAFT = "spacecraft";
    public static final String KEY_STARS = "stars";

    public static final String QUALITY_BATTERY = "battery";
    public static final String QUALITY_BALANCED = "balanced";
    public static final String QUALITY_HIGH = "high";
    public static final String FPS_60 = "60";
    public static final String FPS_AUTO = "auto";
    public static final String SPEED_VERY_SLOW = "very_slow";
    public static final String SPEED_SLOW = "slow";
    public static final String SPEED_NORMAL = "normal";

    // Defaults requested: Very Slow + High Quality + gentle parallax
    public final String quality;
    public final String fps;
    public final String speed;
    public final boolean parallax;
    public final boolean motion;
    public final boolean spacecraft;
    public final boolean stars;

    private WallpaperSettings(SharedPreferences p) {
        quality = p.getString(KEY_QUALITY, QUALITY_HIGH);
        fps = p.getString(KEY_FPS, FPS_60);
        speed = p.getString(KEY_SPEED, SPEED_VERY_SLOW);
        parallax = p.getBoolean(KEY_PARALLAX, true);
        motion = p.getBoolean(KEY_MOTION, true);
        spacecraft = p.getBoolean(KEY_SPACECRAFT, true);
        stars = p.getBoolean(KEY_STARS, true);
    }

    public static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static WallpaperSettings load(Context c) {
        return new WallpaperSettings(prefs(c));
    }

    /**
     * Length of one full seamless loop in seconds. Every animated value is periodic over this
     * period, and the phase advances continuously, so the loop point is invisible.
     */
    public float loopSeconds() {
        switch (speed) {
            case SPEED_NORMAL: return 120f;
            case SPEED_SLOW: return 240f;
            default: return 480f;
        }
    }

    /** Fraction of the screen resolution the scene is rendered at (then upscaled on the GPU). */
    public float renderScale() {
        switch (quality) {
            case QUALITY_BATTERY: return 0.5f;
            case QUALITY_BALANCED: return 0.66f;
            default: return 0.85f;
        }
    }

    /** Max noise octaves for surface and cloud detail. */
    public int octaves() {
        switch (quality) {
            case QUALITY_BATTERY: return 4;
            case QUALITY_BALANCED: return 5;
            default: return 6;
        }
    }

    /** 0 = no limit (let the display decide, up to 120 Hz). */
    public int targetFps() {
        return FPS_AUTO.equals(fps) ? 0 : 60;
    }
}
