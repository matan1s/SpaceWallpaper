package com.matan.spacewallpaper;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Launcher screen: live preview + all settings + "set as wallpaper".
 * Also used as the wallpaper's settings screen. Every change is written to SharedPreferences
 * and picked up immediately by both this preview and the running wallpaper.
 */
public class SettingsActivity extends Activity {

    private GLSurfaceView preview;
    private SpaceRenderer renderer;
    private MotionParallax motion;
    private SharedPreferences prefs;
    private boolean resumed;

    private final SharedPreferences.OnSharedPreferenceChangeListener prefListener =
            (sp, key) -> {
                WallpaperSettings s = WallpaperSettings.load(this);
                renderer.setSettings(s);
                if (resumed) {
                    if (s.motion) motion.start(); else motion.stop();
                }
                updateDependentControls(s);
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = WallpaperSettings.prefs(this);
        WallpaperSettings s = WallpaperSettings.load(this);

        renderer = new SpaceRenderer(this, s);
        motion = new MotionParallax(this, renderer);

        preview = findViewById(R.id.preview);
        preview.setEGLContextClientVersion(3);
        preview.setEGLConfigChooser(8, 8, 8, 8, 0, 0);
        preview.setPreserveEGLContextOnPause(true);
        preview.setRenderer(renderer);
        preview.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);

        bindRadio(R.id.rg_quality, WallpaperSettings.KEY_QUALITY, s.quality,
                new int[]{R.id.q_battery, R.id.q_balanced, R.id.q_high},
                new String[]{WallpaperSettings.QUALITY_BATTERY, WallpaperSettings.QUALITY_BALANCED,
                        WallpaperSettings.QUALITY_HIGH});
        bindRadio(R.id.rg_fps, WallpaperSettings.KEY_FPS, s.fps,
                new int[]{R.id.fps_60, R.id.fps_auto},
                new String[]{WallpaperSettings.FPS_60, WallpaperSettings.FPS_AUTO});
        bindRadio(R.id.rg_speed, WallpaperSettings.KEY_SPEED, s.speed,
                new int[]{R.id.sp_very_slow, R.id.sp_slow, R.id.sp_normal},
                new String[]{WallpaperSettings.SPEED_VERY_SLOW, WallpaperSettings.SPEED_SLOW,
                        WallpaperSettings.SPEED_NORMAL});

        bindSwitch(R.id.sw_parallax, WallpaperSettings.KEY_PARALLAX, s.parallax);
        bindSwitch(R.id.sw_motion, WallpaperSettings.KEY_MOTION, s.motion);
        bindSwitch(R.id.sw_stars, WallpaperSettings.KEY_STARS, s.stars);
        bindSwitch(R.id.sw_realtime_sun, WallpaperSettings.KEY_REALTIME_SUN, s.realtimeSun);
        bindSwitch(R.id.sw_moon, WallpaperSettings.KEY_MOON, s.moon);
        bindSwitch(R.id.sw_planets, WallpaperSettings.KEY_PLANETS, s.planets);
        bindSwitch(R.id.sw_meteors, WallpaperSettings.KEY_METEORS, s.meteors);
        bindSwitch(R.id.sw_adaptive_power, WallpaperSettings.KEY_ADAPTIVE_POWER, s.adaptivePower);
        bindSwitch(R.id.sw_flare, WallpaperSettings.KEY_FLARE, s.flare);
        bindSwitch(R.id.sw_clouds, WallpaperSettings.KEY_CLOUDS, s.clouds);
        bindSwitch(R.id.sw_keep_europe, WallpaperSettings.KEY_KEEP_EUROPE, s.keepEurope);

        bindSeek(R.id.sb_parallax, R.id.val_parallax, WallpaperSettings.KEY_PARALLAX_AMOUNT, s.parallaxAmount);
        bindSeek(R.id.sb_motion, R.id.val_motion, WallpaperSettings.KEY_MOTION_AMOUNT, s.motionAmount);
        bindSeek(R.id.sb_star_density, R.id.val_star_density, WallpaperSettings.KEY_STAR_DENSITY, s.starDensity);
        bindSeek(R.id.sb_star_brightness, R.id.val_star_brightness, WallpaperSettings.KEY_STAR_BRIGHTNESS, s.starBrightness);
        bindSeek(R.id.sb_moon_size, R.id.val_moon_size, WallpaperSettings.KEY_MOON_SIZE, s.moonSize);
        bindSeek(R.id.sb_moon_x, R.id.val_moon_x, WallpaperSettings.KEY_MOON_X, s.moonX);
        bindSeek(R.id.sb_moon_y, R.id.val_moon_y, WallpaperSettings.KEY_MOON_Y, s.moonY);
        bindSeek(R.id.sb_moon_brightness, R.id.val_moon_brightness, WallpaperSettings.KEY_MOON_BRIGHTNESS, s.moonBrightness);
        bindSeek(R.id.sb_cloud_opacity, R.id.val_cloud_opacity, WallpaperSettings.KEY_CLOUD_OPACITY, s.cloudOpacity);
        bindSeek(R.id.sb_flare_intensity, R.id.val_flare_intensity, WallpaperSettings.KEY_FLARE_INTENSITY, s.flareIntensity);
        bindSeek(R.id.sb_earth_light, R.id.val_earth_light, WallpaperSettings.KEY_EARTH_LIGHT, s.earthLight);
        bindSeek(R.id.sb_city_lights, R.id.val_city_lights, WallpaperSettings.KEY_CITY_LIGHTS, s.cityLights);
        bindSeek(R.id.sb_dof, R.id.val_dof, WallpaperSettings.KEY_DOF, s.dof);
        bindSeek(R.id.sb_meteor_freq, R.id.val_meteor_freq, WallpaperSettings.KEY_METEOR_FREQ, s.meteorFreq);

        findViewById(R.id.btn_set).setOnClickListener(v -> openLiveWallpaperPicker());
        findViewById(R.id.btn_reset).setOnClickListener(v -> {
            prefs.edit().clear().apply();
            Toast.makeText(this, R.string.reset_done, Toast.LENGTH_SHORT).show();
            recreate();                                   // rebind every control to the defaults
        });
        updateDependentControls(s);
        prefs.registerOnSharedPreferenceChangeListener(prefListener);
    }

    /** Enables / disables controls that depend on other settings. */
    private void updateDependentControls(WallpaperSettings s) {
        // FPS is linked to quality: Battery Saver locks 30 FPS
        boolean fpsFree = !s.isBatterySaver();
        RadioGroup fps = findViewById(R.id.rg_fps);
        for (int i = 0; i < fps.getChildCount(); i++) {
            fps.getChildAt(i).setEnabled(fpsFree);
            fps.getChildAt(i).setAlpha(fpsFree ? 1f : 0.4f);
        }
        findViewById(R.id.fps_locked).setVisibility(fpsFree ? View.GONE : View.VISIBLE);

        setEnabledDim(R.id.sb_parallax, s.parallax);
        setEnabledDim(R.id.sb_motion, s.motion);
        setEnabledDim(R.id.sb_star_density, s.stars);
        setEnabledDim(R.id.sb_star_brightness, s.stars);
        setEnabledDim(R.id.sb_moon_size, s.moon);
        setEnabledDim(R.id.sb_moon_x, s.moon);
        setEnabledDim(R.id.sb_moon_y, s.moon);
        setEnabledDim(R.id.sb_moon_brightness, s.moon);
        setEnabledDim(R.id.sb_cloud_opacity, s.clouds);
        setEnabledDim(R.id.sb_flare_intensity, s.flare);
        setEnabledDim(R.id.sb_dof, s.planets);
        setEnabledDim(R.id.sb_meteor_freq, s.meteors);
    }

    private void setEnabledDim(int id, boolean enabled) {
        View v = findViewById(id);
        v.setEnabled(enabled);
        v.setAlpha(enabled ? 1f : 0.4f);
    }

    private void bindRadio(int groupId, String key, String current, int[] ids, String[] values) {
        RadioGroup g = findViewById(groupId);
        for (int i = 0; i < ids.length; i++) {
            if (values[i].equals(current)) g.check(ids[i]);
        }
        g.setOnCheckedChangeListener((group, checkedId) -> {
            for (int i = 0; i < ids.length; i++) {
                if (ids[i] == checkedId) prefs.edit().putString(key, values[i]).apply();
            }
        });
    }

    private void bindSwitch(int id, String key, boolean current) {
        CompoundButton b = findViewById(id);
        b.setChecked(current);
        b.setOnCheckedChangeListener((btn, checked) -> prefs.edit().putBoolean(key, checked).apply());
    }

    private void bindSeek(int seekId, int valueId, String key, int current) {
        SeekBar sb = findViewById(seekId);
        TextView val = findViewById(valueId);
        sb.setProgress(current);
        val.setText(current + "%");
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                val.setText(progress + "%");
                if (fromUser) prefs.edit().putInt(key, progress).apply();   // live preview while dragging
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void openLiveWallpaperPicker() {
        Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
        i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, SpaceWallpaperService.class));
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            } catch (ActivityNotFoundException e2) {
                Toast.makeText(this, R.string.no_live_wallpaper, Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        renderer.resetClock();
        preview.onResume();
        if (WallpaperSettings.load(this).motion) motion.start();
    }

    @Override
    protected void onPause() {
        resumed = false;
        motion.stop();
        preview.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener);
        super.onDestroy();
    }
}
