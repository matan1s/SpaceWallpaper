package com.matan.spacewallpaper;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.Toast;

/** Launcher screen: live preview + settings + "set as wallpaper". Also used as the wallpaper's settings screen. */
public class SettingsActivity extends Activity {

    private GLSurfaceView preview;
    private SpaceRenderer renderer;
    private MotionParallax motion;
    private SharedPreferences prefs;
    private boolean resumed;

    private final SharedPreferences.OnSharedPreferenceChangeListener prefListener =
            (sp, key) -> {
                WallpaperSettings s = WallpaperSettings.load(this);
                renderer.setSettings(s);
                if (resumed) {
                    if (s.motion) motion.start(); else motion.stop();
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = WallpaperSettings.prefs(this);
        WallpaperSettings s = WallpaperSettings.load(this);

        renderer = new SpaceRenderer(this, s);
        motion = new MotionParallax(this, renderer);

        preview = findViewById(R.id.preview);
        preview.setEGLContextClientVersion(3);
        preview.setEGLConfigChooser(8, 8, 8, 8, 0, 0);
        preview.setPreserveEGLContextOnPause(true);
        preview.setRenderer(renderer);
        preview.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);

        bindRadio(R.id.rg_quality, WallpaperSettings.KEY_QUALITY, s.quality,
                new int[]{R.id.q_battery, R.id.q_balanced, R.id.q_high},
                new String[]{WallpaperSettings.QUALITY_BATTERY, WallpaperSettings.QUALITY_BALANCED,
                        WallpaperSettings.QUALITY_HIGH});
        bindRadio(R.id.rg_fps, WallpaperSettings.KEY_FPS, s.fps,
                new int[]{R.id.fps_60, R.id.fps_auto},
                new String[]{WallpaperSettings.FPS_60, WallpaperSettings.FPS_AUTO});
        bindRadio(R.id.rg_speed, WallpaperSettings.KEY_SPEED, s.speed,
                new int[]{R.id.sp_very_slow, R.id.sp_slow, R.id.sp_normal},
                new String[]{WallpaperSettings.SPEED_VERY_SLOW, WallpaperSettings.SPEED_SLOW,
                        WallpaperSettings.SPEED_NORMAL});

        bindSwitch(R.id.sw_parallax, WallpaperSettings.KEY_PARALLAX, s.parallax);
        bindSwitch(R.id.sw_motion, WallpaperSettings.KEY_MOTION, s.motion);
        bindSwitch(R.id.sw_stars, WallpaperSettings.KEY_STARS, s.stars);

        findViewById(R.id.btn_set).setOnClickListener(v -> openLiveWallpaperPicker());
        prefs.registerOnSharedPreferenceChangeListener(prefListener);
    }

    private void bindRadio(int groupId, String key, String current, int[] ids, String[] values) {
        RadioGroup g = findViewById(groupId);
        for (int i = 0; i < ids.length; i++) {
            if (values[i].equals(current)) g.check(ids[i]);
        }
        g.setOnCheckedChangeListener((group, checkedId) -> {
            for (int i = 0; i < ids.length; i++) {
                if (ids[i] == checkedId) prefs.edit().putString(key, values[i]).apply();
            }
        });
    }

    private void bindSwitch(int id, String key, boolean current) {
        CompoundButton b = findViewById(id);
        b.setChecked(current);
        b.setOnCheckedChangeListener((btn, checked) -> prefs.edit().putBoolean(key, checked).apply());
    }

    private void openLiveWallpaperPicker() {
        Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
        i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, SpaceWallpaperService.class));
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            } catch (ActivityNotFoundException e2) {
                Toast.makeText(this, R.string.no_live_wallpaper, Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        renderer.resetClock();
        preview.onResume();
        if (WallpaperSettings.load(this).motion) motion.start();
    }

    @Override
    protected void onPause() {
        resumed = false;
        motion.stop();
        preview.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener);
        super.onDestroy();
    }
}
