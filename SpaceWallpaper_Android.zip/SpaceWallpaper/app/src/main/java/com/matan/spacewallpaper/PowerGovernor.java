package com.matan.spacewallpaper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;

/**
 * Decides the EFFECTIVE quality and frame rate from: the user's quality tier, what is happening
 * on screen (idle / swiping / tilting), the battery and the phone's thermal state.
 *
 * Frame rate
 *  - Idle (nothing moving for MOTION_HOLD_NS): 30 FPS - the animation is slow anyway.
 *  - Swiping between home screens or tilting the phone: the "motion" rate (60, or the display
 *    rate when the user picked 120 FPS / Automatic).
 *  - Thermal SEVERE: max 30, CRITICAL or worse: 20 while moving / 15 idle.
 *  - Low battery (<= 20%, not charging) or system Power Saving, when "Adaptive power" is on: 30.
 *
 * Quality
 *  - Thermal MODERATE: render scale <= 0.6, <= 4 noise octaves, 1 bloom pass.
 *  - Thermal SEVERE or worse: render scale <= 0.5, no bloom.
 *  - Texture size is never changed automatically (decoding 4K maps would itself cause a hitch);
 *    half-size maps are used only when the user picks Battery.
 *
 * All state is volatile primitives: the GL thread reads it every frame with no locks or allocations.
 */
final class PowerGovernor {
    /** how long after the last swipe / tilt the wallpaper keeps its motion frame rate */
    static final long MOTION_HOLD_NS = 1_500_000_000L;
    /** how long after the last home-screen offset change we consider the user to be swiping */
    static final long SWIPE_HOLD_NS = 300_000_000L;
    private static final int LOW_BATTERY_PERCENT = 20;

    // thermal status values (PowerManager.THERMAL_STATUS_*, API 29+)
    static final int THERMAL_NONE = 0, THERMAL_MODERATE = 2, THERMAL_SEVERE = 3, THERMAL_CRITICAL = 4;

    private static volatile boolean lowBattery;
    private static volatile boolean powerSave;
    private static volatile int thermal = THERMAL_NONE;
    private static volatile long lastSwipeNs = Long.MIN_VALUE / 2;
    private static volatile long lastMotionNs = Long.MIN_VALUE / 2;

    private PowerGovernor() {}

    // ------------------------------------------------------------------ inputs (any thread)
    /** Home-screen page offset changed (onOffsetsChanged). */
    static void markSwipe() {
        long now = System.nanoTime();
        lastSwipeNs = now;
        lastMotionNs = now;
    }

    /** Phone tilted, wallpaper became visible, etc. */
    static void markInteraction() { lastMotionNs = System.nanoTime(); }

    static void setThermal(int status) { thermal = status; }

    static int thermal() { return thermal; }

    // ------------------------------------------------------------------ state
    static boolean isSwiping(long nowNs) { return nowNs - lastSwipeNs < SWIPE_HOLD_NS; }

    static boolean isMoving(long nowNs) { return nowNs - lastMotionNs < MOTION_HOLD_NS; }

    /** True when the battery / power-save state forces the low-power tier. */
    static boolean constrained(WallpaperSettings s) {
        return s.adaptivePower && (lowBattery || powerSave);
    }

    // ------------------------------------------------------------------ effective values
    /** Target frame rate right now; 0 = follow the display refresh rate. */
    static int fps(WallpaperSettings s, long nowNs) {
        boolean moving = isMoving(nowNs);
        int t = thermal;
        if (t >= THERMAL_CRITICAL) return moving ? 20 : 15;
        if (!moving) return 30;                                  // idle: slow animation, 30 FPS is plenty
        if (t >= THERMAL_SEVERE || s.isBatterySaver() || constrained(s)) return 30;
        return s.targetFps();                                    // 60, or 0 = display rate
    }

    static float renderScale(WallpaperSettings s) {
        float sc = s.renderScale();
        int t = thermal;
        if (t >= THERMAL_SEVERE) return Math.min(sc, 0.5f);
        if (t >= THERMAL_MODERATE) return Math.min(sc, 0.6f);
        return sc;
    }

    static int textureSampleSize(WallpaperSettings s) {
        return s.textureSampleSize();                            // 2 only in Battery
    }

    static int octaves(WallpaperSettings s) {
        int o = s.octaves();
        if (constrained(s) || thermal >= THERMAL_MODERATE) o = Math.min(4, o);
        return o;
    }

    /** Number of bloom blur passes (0 = bloom off). */
    static int bloomPasses(WallpaperSettings s) {
        if (constrained(s) || thermal >= THERMAL_SEVERE) return 0;
        int p = s.bloomPasses();
        return thermal >= THERMAL_MODERATE ? Math.min(1, p) : p;
    }

    /** Bloom strength used by the composite pass. */
    static float bloomAmount(WallpaperSettings s) {
        return WallpaperSettings.QUALITY_HIGH.equals(s.quality) ? 0.9f : 0.75f;
    }

    // ------------------------------------------------------------------ system listeners
    /** Registers battery + power-save listeners; returns the receiver to unregister later. */
    static BroadcastReceiver register(Context c) {
        BroadcastReceiver r = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent i) {
                if (Intent.ACTION_BATTERY_CHANGED.equals(i.getAction())) {
                    update(ctx, i);
                } else {
                    refreshPowerSave(ctx);
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_BATTERY_CHANGED);
        f.addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED);
        Intent sticky;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            sticky = c.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            sticky = c.registerReceiver(r, f);
        }
        if (sticky != null) update(c, sticky);
        refreshPowerSave(c);
        return r;
    }

    static void unregister(Context c, BroadcastReceiver r) {
        if (r == null) return;
        try {
            c.unregisterReceiver(r);
        } catch (IllegalArgumentException ignored) {
            // already unregistered
        }
    }

    private static void update(Context ctx, Intent battery) {
        int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                || status == BatteryManager.BATTERY_STATUS_FULL;
        int pct = (level >= 0 && scale > 0) ? level * 100 / scale : 100;
        lowBattery = !charging && pct <= LOW_BATTERY_PERCENT;
        refreshPowerSave(ctx);
    }

    private static void refreshPowerSave(Context ctx) {
        PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
        powerSave = pm != null && pm.isPowerSaveMode();
    }
}
