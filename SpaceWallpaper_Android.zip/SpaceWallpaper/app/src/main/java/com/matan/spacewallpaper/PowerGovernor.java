package com.matan.spacewallpaper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;

/**
 * Adaptive power management, shared by the wallpaper engine and the renderer.
 *
 *  - Low battery (<= 20% and not charging) or the system Power Saving mode
 *      -> forces the Battery Saver tier: 30 FPS, 50% resolution, half-size textures.
 *  - Idle (no tilt, touch or home-screen swipe for IDLE_AFTER_MS)
 *      -> caps the frame rate at 30 FPS; any interaction restores it instantly.
 *
 * Only active when the user keeps "Adaptive power" on. All state is volatile primitives,
 * so the GL thread can read it every frame without locks or allocations.
 */
final class PowerGovernor {
    static final long IDLE_AFTER_MS = 20_000L;
    private static final int LOW_BATTERY_PERCENT = 20;

    private static volatile boolean lowBattery;
    private static volatile boolean powerSave;
    private static volatile long lastInteractionMs = System.currentTimeMillis();

    private PowerGovernor() {}

    // ------------------------------------------------------------------ inputs
    static void markInteraction() { lastInteractionMs = System.currentTimeMillis(); }

    static boolean isIdle(long nowMs) { return nowMs - lastInteractionMs > IDLE_AFTER_MS; }

    /** True when the battery / power-save state forces the low-power tier. */
    static boolean constrained(WallpaperSettings s) {
        return s.adaptivePower && (lowBattery || powerSave);
    }

    // ------------------------------------------------------------------ effective values
    static int fps(WallpaperSettings s, long nowMs) {
        if (s.isBatterySaver() || constrained(s)) return 30;
        int f = s.targetFps();                                   // 60, or 0 = display rate (up to 120)
        if (s.adaptivePower && isIdle(nowMs)) return 30;         // nothing is moving: calm down
        return f;
    }

    static float renderScale(WallpaperSettings s) {
        return constrained(s) ? Math.min(0.5f, s.renderScale()) : s.renderScale();
    }

    static int textureSampleSize(WallpaperSettings s) {
        return constrained(s) ? 2 : s.textureSampleSize();
    }

    /** Bloom strength: off in the low-power tier. */
    static float bloomAmount(WallpaperSettings s) {
        if (s.isBatterySaver() || constrained(s)) return 0f;
        return WallpaperSettings.QUALITY_BALANCED.equals(s.quality) ? 0.7f : 0.9f;
    }

    static int octaves(WallpaperSettings s) {
        return constrained(s) ? Math.min(4, s.octaves()) : s.octaves();
    }

    // ------------------------------------------------------------------ system listeners
    /** Registers battery + power-save listeners; returns the receiver to unregister later. */
    static BroadcastReceiver register(Context c) {
        BroadcastReceiver r = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent i) {
                if (Intent.ACTION_BATTERY_CHANGED.equals(i.getAction())) {
                    update(ctx, i);
                } else {
                    refreshPowerSave(ctx);
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_BATTERY_CHANGED);
        f.addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED);
        Intent sticky;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            sticky = c.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            sticky = c.registerReceiver(r, f);
        }
        if (sticky != null) update(c, sticky);
        refreshPowerSave(c);
        return r;
    }

    static void unregister(Context c, BroadcastReceiver r) {
        if (r == null) return;
        try {
            c.unregisterReceiver(r);
        } catch (IllegalArgumentException ignored) {
            // already unregistered
        }
    }

    private static void update(Context ctx, Intent battery) {
        int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                || status == BatteryManager.BATTERY_STATUS_FULL;
        int pct = (level >= 0 && scale > 0) ? level * 100 / scale : 100;
        lowBattery = !charging && pct <= LOW_BATTERY_PERCENT;
        refreshPowerSave(ctx);
    }

    private static void refreshPowerSave(Context ctx) {
        PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
        powerSave = pm != null && pm.isPowerSaveMode();
    }
}
