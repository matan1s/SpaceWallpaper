package com.matan.spacewallpaper;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

/**
 * Gentle tilt parallax from the fused gravity sensor (cheap, low power).
 * A slowly adapting baseline re-centres the view, so holding the phone at any angle
 * always settles back to the composed shot; only small tilts move the camera.
 * Registered only while the wallpaper is visible and the setting is on.
 */
final class MotionParallax implements SensorEventListener {
    private static final float RANGE = 0.30f;       // gravity delta (in g) mapped to full effect
    private static final float BASELINE_RATE = 0.012f;

    private final SensorManager sm;
    private final Sensor sensor;
    private final SpaceRenderer renderer;
    private boolean running;
    private boolean hasBaseline;
    private float baseX, baseZ;

    MotionParallax(Context c, SpaceRenderer renderer) {
        this.renderer = renderer;
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        Sensor s = sm != null ? sm.getDefaultSensor(Sensor.TYPE_GRAVITY) : null;
        if (s == null && sm != null) s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensor = s;
    }

    void start() {
        if (running || sensor == null) return;
        running = true;
        hasBaseline = false;
        sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME);
    }

    void stop() {
        if (!running) return;
        running = false;
        sm.unregisterListener(this);
        renderer.setTilt(0f, 0f);
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        float gx = e.values[0] / SensorManager.GRAVITY_EARTH;
        float gz = e.values[2] / SensorManager.GRAVITY_EARTH;
        if (!hasBaseline) {
            baseX = gx;
            baseZ = gz;
            hasBaseline = true;
        }
        baseX += (gx - baseX) * BASELINE_RATE;
        baseZ += (gz - baseZ) * BASELINE_RATE;
        float dx = clamp((gx - baseX) / RANGE);
        float dz = clamp((gz - baseZ) / RANGE);
        renderer.setTilt(-dx, dz);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private static float clamp(float v) {
        return Math.max(-1f, Math.min(1f, v));
    }
}
