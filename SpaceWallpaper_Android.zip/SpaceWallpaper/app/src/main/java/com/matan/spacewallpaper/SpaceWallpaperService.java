package com.matan.spacewallpaper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.SharedPreferences;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.service.wallpaper.WallpaperService;
import android.view.Choreographer;
import android.view.Surface;
import android.view.SurfaceHolder;

/**
 * The actual Android live wallpaper.
 *
 * Battery behaviour:
 *  - Rendering runs only while the wallpaper is visible. Screen off, apps covering it,
 *    or the wallpaper not shown => GL thread paused, sensors unregistered, no frames.
 *  - Frames are paced by Choreographer (vsync): 60 FPS cap by default, or "Auto" = display rate (up to 120 Hz).
 *  - The scene is rendered at a reduced resolution and upscaled by the GPU (quality setting).
 */
public class SpaceWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new SpaceEngine();
    }

    final class SpaceEngine extends Engine
            implements SharedPreferences.OnSharedPreferenceChangeListener {

        /** GLSurfaceView that draws into the wallpaper's surface instead of a window. */
        final class WallpaperGLView extends GLSurfaceView {
            WallpaperGLView(Context c) { super(c); }

            @Override
            public SurfaceHolder getHolder() { return getSurfaceHolder(); }

            void release() { super.onDetachedFromWindow(); }
        }

        private WallpaperGLView glView;
        private SpaceRenderer renderer;
        private MotionParallax motion;
        private SharedPreferences prefs;
        private WallpaperSettings cfg;
        private boolean visible;
        private long lastFrameNanos;
        private BroadcastReceiver powerReceiver;
        private BroadcastReceiver tzReceiver;
        private int appliedFps = -1;

        private final Choreographer.FrameCallback frameCallback = new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                if (!visible) return;
                // effective FPS: quality tier + battery / power-save / idle state
                int fps = PowerGovernor.fps(cfg, System.currentTimeMillis());
                if (fps != appliedFps) applyFrameRateHint(getSurfaceHolder());
                long interval = fps > 0 ? 1_000_000_000L / fps : 0L;
                // 2 ms tolerance so a 60 FPS cap on a 120 Hz panel renders exactly every 2nd vsync
                if (frameTimeNanos - lastFrameNanos >= interval - 2_000_000L) {
                    lastFrameNanos = frameTimeNanos;
                    glView.requestRender();
                }
                Choreographer.getInstance().postFrameCallback(this);
            }
        };

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            setTouchEventsEnabled(false);         // no gestures: the flare is controlled only in settings
            Context c = SpaceWallpaperService.this;
            prefs = WallpaperSettings.prefs(c);
            cfg = WallpaperSettings.load(c);
            renderer = new SpaceRenderer(c, cfg);
            motion = new MotionParallax(c, renderer);

            glView = new WallpaperGLView(c);
            glView.setEGLContextClientVersion(3);
            glView.setEGLConfigChooser(8, 8, 8, 8, 0, 0);
            glView.setPreserveEGLContextOnPause(true);
            glView.setRenderer(renderer);
            glView.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);

            prefs.registerOnSharedPreferenceChangeListener(this);
            powerReceiver = PowerGovernor.register(c);
            tzReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context ctx, android.content.Intent i) { renderer.refreshLocation(); }
            };
            android.content.IntentFilter tzf = new android.content.IntentFilter(android.content.Intent.ACTION_TIMEZONE_CHANGED);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                c.registerReceiver(tzReceiver, tzf, Context.RECEIVER_NOT_EXPORTED);
            } else {
                c.registerReceiver(tzReceiver, tzf);
            }
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            if (isVisible == visible) return;
            visible = isVisible;
            if (visible) {
                PowerGovernor.markInteraction();
                renderer.resetClock();
                glView.onResume();
                if (cfg.motion) motion.start();
                lastFrameNanos = 0L;
                Choreographer.getInstance().removeFrameCallback(frameCallback);
                Choreographer.getInstance().postFrameCallback(frameCallback);
            } else {
                Choreographer.getInstance().removeFrameCallback(frameCallback);
                motion.stop();
                glView.onPause();
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            applyFrameRateHint(holder);
            if (visible) glView.requestRender();
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset, float xStep, float yStep,
                                     int xPixels, int yPixels) {
            // home-screen page swipes move the camera a little (only if the launcher sends offsets)
            renderer.setPageOffset(xStep > 0f && xStep < 1f ? xOffset - 0.5f : 0f);
            PowerGovernor.markInteraction();
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
            cfg = WallpaperSettings.load(SpaceWallpaperService.this);
            renderer.setSettings(cfg);
            if (visible) {
                if (cfg.motion) motion.start(); else motion.stop();
            }
            applyFrameRateHint(getSurfaceHolder());
        }

        private void applyFrameRateHint(SurfaceHolder holder) {
            int fps = PowerGovernor.fps(cfg, System.currentTimeMillis());
            appliedFps = fps;                                   // remember, even if the hint is unsupported
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || holder == null) return;
            try {
                Surface s = holder.getSurface();
                if (s != null && s.isValid()) {
                    s.setFrameRate(fps, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
                }
            } catch (Exception ignored) {
                // purely a hint; some devices/states reject it
            }
        }

        @Override
        public void onDestroy() {
            visible = false;
            Choreographer.getInstance().removeFrameCallback(frameCallback);
            motion.stop();
            prefs.unregisterOnSharedPreferenceChangeListener(this);
            PowerGovernor.unregister(SpaceWallpaperService.this, powerReceiver);
            PowerGovernor.unregister(SpaceWallpaperService.this, tzReceiver);
            glView.release();
            super.onDestroy();
        }
    }
}
