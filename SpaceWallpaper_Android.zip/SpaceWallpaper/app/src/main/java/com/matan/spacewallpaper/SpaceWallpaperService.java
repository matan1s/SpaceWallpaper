package com.matan.spacewallpaper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.PowerManager;
import android.service.wallpaper.WallpaperService;
import android.view.Choreographer;
import android.view.SurfaceHolder;

/**
 * The actual Android live wallpaper.
 *
 * Never slowing down the launcher (v3.4):
 *  - Low-priority GPU context (LowPriorityContextFactory): the launcher's frames always run first.
 *  - NO display frame-rate vote. v3.3 called Surface.setFrameRate(60 / 30) on the wallpaper
 *    surface, which can hold a 120 Hz panel at 60 Hz while you swipe. Pacing is now done only by
 *    skipping vsyncs with Choreographer, so the launcher keeps the full refresh rate.
 *  - Frame pacing with Choreographer (no busy loop, no Thread.sleep): 30 FPS when idle - between
 *    idle frames the main thread is not even woken every vsync (postFrameCallbackDelayed) -
 *    and the motion rate (60, or the display rate if the user chose it) while swiping or tilting.
 *  - onOffsetsChanged only stores a float and a timestamp: no GL work, no allocation.
 *  - Thermal listener: quality drops automatically when the phone heats up (PowerGovernor).
 *  - Rendering stops completely while the wallpaper is not visible (app on top, screen off):
 *    GL thread paused, sensors unregistered, no frame callbacks.
 */
public class SpaceWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new SpaceEngine();
    }

    final class SpaceEngine extends Engine
            implements SharedPreferences.OnSharedPreferenceChangeListener {

        /** GLSurfaceView that draws into the wallpaper's surface instead of a window. */
        final class WallpaperGLView extends GLSurfaceView {
            WallpaperGLView(Context c) { super(c); }

            @Override
            public SurfaceHolder getHolder() { return getSurfaceHolder(); }

            void release() { super.onDetachedFromWindow(); }
        }

        private WallpaperGLView glView;
        private SpaceRenderer renderer;
        private MotionParallax motion;
        private SharedPreferences prefs;
        private volatile WallpaperSettings cfg;
        private boolean visible;
        private long lastFrameNanos;
        private boolean sleeping;              // true while waiting with postFrameCallbackDelayed
        private float lastXOffset = Float.NaN;
        private BroadcastReceiver powerReceiver;
        private BroadcastReceiver tzReceiver;
        private PowerManager.OnThermalStatusChangedListener thermalListener;

        private final Choreographer.FrameCallback frameCallback = new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                sleeping = false;
                if (!visible) return;
                long now = System.nanoTime();
                int fps = PowerGovernor.fps(cfg, now);                // 0 = every vsync
                long interval = fps > 0 ? 1_000_000_000L / fps : 0L;
                // 2 ms tolerance so e.g. 60 FPS on a 120 Hz panel renders exactly every 2nd vsync
                if (frameTimeNanos - lastFrameNanos >= interval - 2_000_000L) {
                    lastFrameNanos = frameTimeNanos;
                    glView.requestRender();
                }
                Choreographer ch = Choreographer.getInstance();
                long untilNext = lastFrameNanos + interval - frameTimeNanos;
                if (fps > 0 && fps <= 30 && untilNext > 12_000_000L) {
                    // idle: sleep until ~1 vsync before the next frame instead of waking every vsync
                    sleeping = true;
                    ch.postFrameCallbackDelayed(this, (untilNext - 10_000_000L) / 1_000_000L);
                } else {
                    ch.postFrameCallback(this);
                }
            }
        };

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            setTouchEventsEnabled(false);         // no gestures: the flare is controlled only in settings
            setOffsetNotificationsEnabled(true);
            Context c = SpaceWallpaperService.this;
            WallpaperSettings.migrate(c);
            prefs = WallpaperSettings.prefs(c);
            cfg = WallpaperSettings.load(c);
            renderer = new SpaceRenderer(c, cfg);
            motion = new MotionParallax(c, renderer);

            glView = new WallpaperGLView(c);
            glView.setEGLContextClientVersion(3);
            glView.setEGLConfigChooser(8, 8, 8, 8, 0, 0);
            glView.setEGLContextFactory(new LowPriorityContextFactory(true));
            glView.setPreserveEGLContextOnPause(true);
            glView.setRenderer(renderer);
            glView.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);

            prefs.registerOnSharedPreferenceChangeListener(this);
            powerReceiver = PowerGovernor.register(c);
            tzReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context ctx, Intent i) { renderer.refreshLocation(); }
            };
            IntentFilter tzf = new IntentFilter(Intent.ACTION_TIMEZONE_CHANGED);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                c.registerReceiver(tzReceiver, tzf, Context.RECEIVER_NOT_EXPORTED);
            } else {
                c.registerReceiver(tzReceiver, tzf);
            }
            // thermal state -> automatic quality reduction (Android 10+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    PowerGovernor.setThermal(pm.getCurrentThermalStatus());
                    thermalListener = PowerGovernor::setThermal;
                    pm.addThermalStatusListener(c.getMainExecutor(), thermalListener);
                }
            }
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            if (isVisible == visible) return;
            visible = isVisible;
            Choreographer ch = Choreographer.getInstance();
            ch.removeFrameCallback(frameCallback);
            sleeping = false;
            if (visible) {
                PowerGovernor.markInteraction();
                renderer.resetClock();
                glView.onResume();
                if (cfg.motion) motion.start();
                lastFrameNanos = 0L;
                ch.postFrameCallback(frameCallback);
            } else {
                motion.stop();
                glView.onPause();                 // GL thread stops: zero rendering while hidden
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            if (visible) glView.requestRender();
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset, float xStep, float yStep,
                                     int xPixels, int yPixels) {
            // swipe between home screens: store one float + a timestamp, nothing else
            float off = xStep > 0f && xStep < 1f ? xOffset - 0.5f : 0f;
            renderer.setPageOffset(off);
            if (off != lastXOffset) {
                lastXOffset = off;
                PowerGovernor.markSwipe();
                if (sleeping && visible) {
                    // idle pacer is asleep: wake it now so the swipe gets frames immediately
                    Choreographer ch = Choreographer.getInstance();
                    ch.removeFrameCallback(frameCallback);
                    sleeping = false;
                    ch.postFrameCallback(frameCallback);
                }
            }
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
            // settings are read ONLY here (on change), never per frame
            cfg = WallpaperSettings.load(SpaceWallpaperService.this);
            renderer.setSettings(cfg);
            if (visible) {
                if (cfg.motion) motion.start(); else motion.stop();
                glView.requestRender();
            }
        }

        @Override
        public void onDestroy() {
            visible = false;
            Choreographer.getInstance().removeFrameCallback(frameCallback);
            motion.stop();
            prefs.unregisterOnSharedPreferenceChangeListener(this);
            PowerGovernor.unregister(SpaceWallpaperService.this, powerReceiver);
            PowerGovernor.unregister(SpaceWallpaperService.this, tzReceiver);
            if (thermalListener != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null) pm.removeThermalStatusListener(thermalListener);
            }
            glView.release();
            super.onDestroy();
        }
    }
}
