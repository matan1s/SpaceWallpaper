package com.matan.spacewallpaper;

import java.util.TimeZone;

/**
 * Real-time day/night cycle.
 *
 * The camera is "geostationary" above the user's approximate location (longitude derived from
 * the device time zone, so no location permission is needed). The Earth therefore stays still,
 * and the Sun direction is computed from the real date and time (solar declination, equation of
 * time, Greenwich sidereal time), so the terminator, the lit side and the city lights on the
 * globe match reality all day long. The Moon is lit by the same Sun, so its phase stays consistent.
 *
 * All arrays are pre-allocated; update() allocates nothing.
 */
final class SunClock {
    /** Earth centre / radius in camera space - must match scene.frag */
    private static final double CX = 39.65511, CY = -1.20167, CZ = -60.08351, R = 40.654;
    /** Screen point (tangent units) where the user's location is placed on the globe */
    private static final double VIEW_X = 0.20, VIEW_Y = 0.12;
    /** Latitude used for the view (the time zone gives longitude only) */
    private static final double DEFAULT_LAT_DEG = 31.0;

    /** column-major 3x3, camera space -> Earth texture space (for glUniformMatrix3fv) */
    final float[] earthM = new float[9];
    /** direction to the Sun in camera space */
    final float[] sun = new float[3];

    private final double[] m = new double[9];   // row-major working copy
    private long lastUpdateMs;
    private boolean dirty = true;
    private double lonDeg = Double.NaN;

    void refreshLocation() {
        TimeZone tz = TimeZone.getDefault();
        lonDeg = tz.getRawOffset() / 3600000.0 * 15.0;
        buildFrame(DEFAULT_LAT_DEG, lonDeg);
        dirty = true;
    }

    /** Recomputes at most once per second. */
    void update(long nowMs) {
        if (Double.isNaN(lonDeg)) refreshLocation();
        if (!dirty && Math.abs(nowMs - lastUpdateMs) < 1000L) return;
        dirty = false;
        lastUpdateMs = nowMs;

        // --- low-precision solar ephemeris (accurate to ~0.01 deg, plenty for a wallpaper) ---
        double n = nowMs / 86400000.0 - 10957.5;                    // days since J2000.0
        double L = Math.toRadians((280.460 + 0.9856474 * n) % 360.0);
        double g = Math.toRadians((357.528 + 0.9856003 * n) % 360.0);
        double lam = L + Math.toRadians(1.915) * Math.sin(g) + Math.toRadians(0.020) * Math.sin(2 * g);
        double eps = Math.toRadians(23.439 - 0.0000004 * n);
        double dec = Math.asin(Math.sin(eps) * Math.sin(lam));
        double ra = Math.atan2(Math.cos(eps) * Math.sin(lam), Math.cos(lam));
        double gmst = Math.toRadians((280.46061837 + 360.98564736629 * n) % 360.0);
        double lon = ra - gmst;                                         // sub-solar longitude

        // sub-solar point in Earth texture space (x = east at lon 90, y = north, z = lon 0)
        double sx = Math.cos(dec) * Math.sin(lon);
        double sy = Math.sin(dec);
        double sz = Math.cos(dec) * Math.cos(lon);
        // camera space = M^T * s
        sun[0] = (float) (m[0] * sx + m[3] * sy + m[6] * sz);
        sun[1] = (float) (m[1] * sx + m[4] * sy + m[7] * sz);
        sun[2] = (float) (m[2] * sx + m[5] * sy + m[8] * sz);
    }

    /** Builds M so that the chosen lat/lon faces the camera at (VIEW_X, VIEW_Y), north up. */
    private void buildFrame(double latDeg, double lonDeg) {
        // point on the globe under the chosen screen position
        double dx = VIEW_X, dy = VIEW_Y, dz = -1.0;
        double dl = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= dl; dy /= dl; dz /= dl;
        double b = dx * CX + dy * CY + dz * CZ;
        double h = b * b - (CX * CX + CY * CY + CZ * CZ) + R * R;
        double t = b - Math.sqrt(Math.max(h, 0.0));
        double nx = (dx * t - CX) / R, ny = (dy * t - CY) / R, nz = (dz * t - CZ) / R;
        // camera-space frame at that point: right, up, normal
        double ux = -nx * ny, uy = 1.0 - ny * ny, uz = -nz * ny;
        double ul = Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux /= ul; uy /= ul; uz /= ul;
        double rx = uy * nz - uz * ny, ry = uz * nx - ux * nz, rz = ux * ny - uy * nx;   // up x n

        // texture-space frame at lat/lon: east, north, outward normal
        double la = Math.toRadians(latDeg), lo = Math.toRadians(lonDeg);
        double px = Math.cos(la) * Math.sin(lo), py = Math.sin(la), pz = Math.cos(la) * Math.cos(lo);
        double qx = -px * py, qy = 1.0 - py * py, qz = -pz * py;                     // north
        double ql = Math.sqrt(qx * qx + qy * qy + qz * qz);
        qx /= ql; qy /= ql; qz /= ql;
        double ex = qy * pz - qz * py, ey = qz * px - qx * pz, ez = qx * py - qy * px; // north x p

        // M = [e q p] * [r u n]^T   (row-major into m)
        double[] T = {ex, qx, px, ey, qy, py, ez, qz, pz};   // rows of [e q p]
        double[] Cc = {rx, ux, nx, ry, uy, ny, rz, uz, nz};  // rows of [r u n]
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                // (T * C^T)[i][j] = sum_k T[i][k] * C[j][k]
                m[i * 3 + j] = T[i * 3] * Cc[j * 3] + T[i * 3 + 1] * Cc[j * 3 + 1] + T[i * 3 + 2] * Cc[j * 3 + 2];
            }
        }
        // column-major for GL
        for (int col = 0; col < 3; col++) {
            for (int row = 0; row < 3; row++) {
                earthM[col * 3 + row] = (float) m[row * 3 + col];
            }
        }
    }
}
