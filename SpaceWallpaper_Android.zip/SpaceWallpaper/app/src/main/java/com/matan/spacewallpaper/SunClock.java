package com.matan.spacewallpaper;

import java.util.TimeZone;

/**
 * Real-time day/night cycle.
 *
 * The view is "geostationary" above the user's approximate location (longitude from the device
 * time zone - no location permission needed), placed at the same screen point where Europe sits
 * in the default composition. The Sun direction comes from the real date and time (solar
 * declination, equation of time, Greenwich sidereal time), so the terminator, the day side and
 * the city lights match reality. Allocation-free after construction.
 */
final class SunClock {
    private static final double VIEW_FX = 0.70, VIEW_FY = 0.52;
    private static final double DEFAULT_LAT_DEG = 31.0;

    /** column-major 3x3, camera space -> Earth texture space */
    final float[] earthM = new float[9];
    /** direction to the Sun in camera space */
    final float[] sun = new float[3];

    private final double[] m = new double[9];
    private long lastUpdateMs;
    private boolean dirty = true;
    private double lonDeg = Double.NaN;

    void refreshLocation() {
        lonDeg = TimeZone.getDefault().getRawOffset() / 3600000.0 * 15.0;
        EarthFrame.build(earthM, m, DEFAULT_LAT_DEG, lonDeg, VIEW_FX, VIEW_FY, -15.0);
        dirty = true;
    }

    /** Recomputes at most once per second. */
    void update(long nowMs) {
        if (Double.isNaN(lonDeg)) refreshLocation();
        if (!dirty && Math.abs(nowMs - lastUpdateMs) < 1000L) return;
        dirty = false;
        lastUpdateMs = nowMs;

        double n = nowMs / 86400000.0 - 10957.5;                    // days since J2000.0
        double L = Math.toRadians((280.460 + 0.9856474 * n) % 360.0);
        double g = Math.toRadians((357.528 + 0.9856003 * n) % 360.0);
        double lam = L + Math.toRadians(1.915) * Math.sin(g) + Math.toRadians(0.020) * Math.sin(2 * g);
        double eps = Math.toRadians(23.439 - 0.0000004 * n);
        double dec = Math.asin(Math.sin(eps) * Math.sin(lam));
        double ra = Math.atan2(Math.cos(eps) * Math.sin(lam), Math.cos(lam));
        double gmst = Math.toRadians((280.46061837 + 360.98564736629 * n) % 360.0);
        double lon = ra - gmst;                                         // sub-solar longitude

        double sx = Math.cos(dec) * Math.sin(lon), sy = Math.sin(dec), sz = Math.cos(dec) * Math.cos(lon);
        sun[0] = (float) (m[0] * sx + m[3] * sy + m[6] * sz);           // M^T * s
        sun[1] = (float) (m[1] * sx + m[4] * sy + m[7] * sz);
        sun[2] = (float) (m[2] * sx + m[5] * sy + m[8] * sz);
    }
}
