package com.matan.spacewallpaper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.os.SystemClock;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * GPU renderer shared by the live wallpaper and the in-app preview.
 *
 * ONE-OFF work (only when settings / quality / screen size change - never per frame):
 *   - sky.frag bakes the static sky (Milky Way, nebulae, star field, bright stars) into two
 *     textures covering the screen plus a margin for camera / parallax motion.
 *   - Earth / Moon / cloud maps are decoded and uploaded with mipmaps.
 *
 * Per frame (no allocations, no SharedPreferences, no shader compiles):
 *   1. scene.frag      -> scene target (screen x renderScale): baked sky + twinkle, Earth, clouds,
 *                         Moon, meteors (scheduled on the CPU), flare
 *   2. bright.frag     -> bloom target (1/4 of the scene): bright-pass + downsample
 *   3. blur.frag x2/x4 -> one (Balanced) or two (High) separable H+V passes
 *      Bloom fades out while the user swipes between home screens, so swipe frames are cheapest.
 *   4. composite.frag  -> screen: upscale + bloom + film grain + dithering
 *   5. overlay.frag    -> optional performance overlay
 *
 * Seamless infinite loop: the phase advances with real time and wraps at 2*PI; every animated
 * term in the shaders is periodic in the phase. Pausing freezes the phase.
 */
public final class SpaceRenderer implements GLSurfaceView.Renderer {
    private static final String TAG = "SpaceRenderer";
    private static final double TWO_PI = Math.PI * 2.0;
    private static final float TAN_V = 0.62f;
    // GL_EXT_texture_filter_anisotropic / GL_EXT_disjoint_timer_query tokens
    private static final int GL_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FE;
    private static final int GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FF;
    private static final int GL_TIME_ELAPSED_EXT = 0x88BF;
    private static final int GL_GPU_DISJOINT_EXT = 0x8FBB;
    private static final int GL_RGB10_A2 = 0x8059;
    /** Sun just behind the Earth's limb at ~(48%, 64%) of the screen - fitted to the reference */
    private static final float[] DEFAULT_SUN = {-0.00981108f, -0.17333015f, -0.98481491f};

    private final Context appContext;
    private volatile WallpaperSettings settings;

    // inputs written by the UI thread (sensors / home-screen offsets) - plain volatile floats
    private volatile float tiltX, tiltY, pageOffset;
    // smoothed camera state (GL thread only)
    private float sTiltX, sTiltY, sPage, sDrift = 1f;
    private float bloomFade = 1f;

    private double phase;
    private long lastNanos;
    private int frameCounter;
    private volatile boolean resetClock = true;
    private volatile boolean refreshLocation;

    // programs
    private int progScene, progSky, progBright, progBlur, progComposite, progOverlay;
    private int vao;
    // textures
    private int noiseTex, earthDayTex, earthAuxTex, moonTex, cloudTex, regionDayTex, regionAuxTex;
    private float maxAniso = 0f;                       // 0 = anisotropic filtering not supported
    private int loadedSampleSize = -1;
    // render targets
    private int sceneFbo, sceneTex, sceneW, sceneH;
    private int bloomFboA, bloomTexA, bloomFboB, bloomTexB, bloomW, bloomH;
    private int surfW = 1, surfH = 1;
    private float builtScale = -1f;
    // baked static sky
    private int skyFbo, skyTexA, skyTexB, skyW, skyH;
    private float tanExtX, tanExtY;
    private int bakedW = -1, bakedH = -1, bakedOct = -1, bakedDensity = -1, bakedBrightness = -1;
    private boolean bakedStars;

    private final SunClock sunClock = new SunClock();
    private final Meteors meteors = new Meteors();
    private final DebugOverlay overlay = new DebugOverlay();
    /** Default orientation: Gibraltar under (70%, 52%), north tilted 15 deg - Europe upper right */
    private final float[] baseEarthM = new float[9];

    // scene uniforms
    private int uNoise, uRes, uPhase, uCam, uOct, uToggles, uEarthDay, uEarthAux, uMoonTex,
            uSun, uRealtime, uEarthM, uEarthSpin, uMoon, uMoonBright, uPlanets,
            uCloudTex, uClouds, uLight, uRegionDay, uRegionAux, uSkyA, uSkyB, uTanExt,
            uMeteorA, uMeteorB, uMeteorLen;
    // sky bake uniforms
    private int ukNoise, ukBakeRes, ukTanExt, ukAspect, ukPix, ukOct, ukStars, ukStarsOn;
    // post uniforms
    private int ubTex, ubSrcTexel, ubThreshold, ulTex, ulDir, ucScene, ucBloom, ucScreen, ucBloomAmt, ucSeed;

    // GPU timer queries (performance overlay)
    private boolean timerSupported;
    private final int[] queries = new int[4];
    private final boolean[] queryPending = new boolean[4];
    private int queryIdx;

    private final int[] tmp = new int[1];
    private final int[] tex6 = new int[6];
    private final float[] tmpF = new float[1];
    private final int[] invalidateAttachments = {GLES30.GL_COLOR_ATTACHMENT0};
    private final int[] drawBuffers2 = {GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_COLOR_ATTACHMENT1};

    public SpaceRenderer(Context context, WallpaperSettings initial) {
        appContext = context.getApplicationContext();
        settings = initial;
        phase = 0.0;
        EarthFrame.build(baseEarthM, null, 36.0, -5.5, 0.70, 0.52, -15.0);
    }

    /** New settings snapshot (created by the prefs listener only when something changed). */
    public void setSettings(WallpaperSettings s) { settings = s; }

    /** Normalised device tilt in [-1, 1] (after the slow re-centering baseline). */
    public void setTilt(float x, float y) { tiltX = x; tiltY = y; }

    /** Home screen page offset in [-0.5, 0.5]. Only stores a float: no GL work, no allocation. */
    public void setPageOffset(float o) { pageOffset = o; }

    /** Call when rendering resumes so the paused time is not counted. */
    public void resetClock() { resetClock = true; }

    /** Time zone changed (e.g. travel): recompute the location used by the real-time sun. */
    public void refreshLocation() { refreshLocation = true; }

    // ------------------------------------------------------------------------------------------
    @Override
    public void onSurfaceCreated(GL10 unused, EGLConfig config) {
        // all shaders are compiled HERE only (context creation), never while drawing
        String vs = readAsset("shaders/fullscreen.vert");
        progScene = buildProgram(vs, readShader("scene.frag"));
        progSky = buildProgram(vs, readShader("sky.frag"));
        progBright = buildProgram(vs, readShader("bright.frag"));
        progBlur = buildProgram(vs, readShader("blur.frag"));
        progComposite = buildProgram(vs, readShader("composite.frag"));
        progOverlay = buildProgram(vs, readShader("overlay.frag"));

        if (progScene != 0) {
            uNoise = loc(progScene, "uNoise");
            uRes = loc(progScene, "uRes");
            uPhase = loc(progScene, "uPhase");
            uCam = loc(progScene, "uCam");
            uOct = loc(progScene, "uOct");
            uToggles = loc(progScene, "uToggles");
            uEarthDay = loc(progScene, "uEarthDay");
            uEarthAux = loc(progScene, "uEarthAux");
            uMoonTex = loc(progScene, "uMoonTex");
            uSun = loc(progScene, "uSun");
            uRealtime = loc(progScene, "uRealtime");
            uEarthM = loc(progScene, "uEarthM");
            uEarthSpin = loc(progScene, "uEarthSpin");
            uMoon = loc(progScene, "uMoon");
            uMoonBright = loc(progScene, "uMoonBright");
            uCloudTex = loc(progScene, "uCloudTex");
            uClouds = loc(progScene, "uClouds");
            uLight = loc(progScene, "uLight");
            uRegionDay = loc(progScene, "uRegionDay");
            uRegionAux = loc(progScene, "uRegionAux");
            uPlanets = loc(progScene, "uPlanets");
            uSkyA = loc(progScene, "uSkyA");
            uSkyB = loc(progScene, "uSkyB");
            uTanExt = loc(progScene, "uTanExt");
            uMeteorA = loc(progScene, "uMeteorA");
            uMeteorB = loc(progScene, "uMeteorB");
            uMeteorLen = loc(progScene, "uMeteorLen");
        }
        if (progSky != 0) {
            ukNoise = loc(progSky, "uNoise");
            ukBakeRes = loc(progSky, "uBakeRes");
            ukTanExt = loc(progSky, "uTanExt");
            ukAspect = loc(progSky, "uAspect");
            ukPix = loc(progSky, "uPix");
            ukOct = loc(progSky, "uOct");
            ukStars = loc(progSky, "uStars");
            ukStarsOn = loc(progSky, "uStarsOn");
        }
        if (progBright != 0) {
            ubTex = loc(progBright, "uTex");
            ubSrcTexel = loc(progBright, "uSrcTexel");
            ubThreshold = loc(progBright, "uThreshold");
        }
        if (progBlur != 0) {
            ulTex = loc(progBlur, "uTex");
            ulDir = loc(progBlur, "uDir");
        }
        if (progComposite != 0) {
            ucScene = loc(progComposite, "uScene");
            ucBloom = loc(progComposite, "uBloom");
            ucScreen = loc(progComposite, "uScreen");
            ucBloomAmt = loc(progComposite, "uBloomAmt");
            ucSeed = loc(progComposite, "uSeed");
        }
        overlay.onSurfaceCreated(progOverlay);

        GLES30.glGenVertexArrays(1, tmp, 0);
        vao = tmp[0];

        GLES30.glGenTextures(1, tmp, 0);
        noiseTex = tmp[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, noiseTex);
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1);
        int n = NoiseTexture.SIZE;
        GLES30.glTexImage3D(GLES30.GL_TEXTURE_3D, 0, GLES30.GL_R8, n, n, n, 0,
                GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, NoiseTexture.get());
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_R, GLES30.GL_REPEAT);

        String ext = GLES30.glGetString(GLES30.GL_EXTENSIONS);
        // anisotropic filtering (sharp Earth maps / clouds at the grazing limb)
        maxAniso = 0f;
        if (ext != null && ext.contains("GL_EXT_texture_filter_anisotropic")) {
            GLES30.glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, tmpF, 0);
            maxAniso = tmpF[0];
        }
        // GPU timing for the performance overlay
        timerSupported = ext != null && ext.contains("GL_EXT_disjoint_timer_query");
        if (timerSupported) {
            GLES30.glGenQueries(queries.length, queries, 0);
            for (int i = 0; i < queryPending.length; i++) queryPending[i] = false;
        }

        // maps are loaded lazily (per quality tier); the sky is (re)baked on first draw
        earthDayTex = earthAuxTex = moonTex = cloudTex = regionDayTex = regionAuxTex = 0;
        loadedSampleSize = -1;
        sunClock.refreshLocation();

        GLES30.glDisable(GLES30.GL_DEPTH_TEST);
        GLES30.glDisable(GLES30.GL_BLEND);
        sceneFbo = sceneTex = bloomFboA = bloomTexA = bloomFboB = bloomTexB = 0;
        skyFbo = skyTexA = skyTexB = 0;
        bakedW = -1;
        builtScale = -1f;
        resetClock = true;
    }

    @Override
    public void onSurfaceChanged(GL10 unused, int width, int height) {
        surfW = Math.max(1, width);
        surfH = Math.max(1, height);
        builtScale = -1f; // rebuild offscreen targets (and the sky bake) for the new size
        bakedW = -1;
    }

    @Override
    public void onDrawFrame(GL10 unused) {
        final long t0 = System.nanoTime();
        final WallpaperSettings s = settings;

        // ---- time / phase (double precision, wrapped => runs forever without drift) ----
        float dt;
        if (resetClock || lastNanos == 0L) {
            dt = 0f;
            resetClock = false;
        } else {
            dt = Math.min((t0 - lastNanos) / 1e9f, 0.1f);
        }
        lastNanos = t0;
        phase += dt * TWO_PI / s.loopSeconds();
        if (phase >= TWO_PI) phase -= TWO_PI;
        frameCounter = (frameCounter + 1) & 1023;

        // ---- smoothed parallax inputs ----
        // home-screen offset: short time constant (~50 ms) - follows the launcher closely, only
        // removes jitter; phone tilt: slower (~0.3 s) for a calm, floating feel
        float kPage = 1f - (float) Math.exp(-dt / 0.05f);
        float kTilt = 1f - (float) Math.exp(-dt * 3.5f);
        float tx = s.motion ? tiltX : 0f;
        float ty = s.motion ? tiltY : 0f;
        float pg = s.parallax ? pageOffset : 0f;
        sTiltX += (tx - sTiltX) * kTilt;
        sTiltY += (ty - sTiltY) * kTilt;
        sPage += (pg - sPage) * kPage;
        sDrift += (s.parallaxFactor() - sDrift) * kTilt * 0.5f;

        float mf = s.motionFactor();
        float pf = s.parallaxFactor();
        float yaw = -0.006f * sTiltX * mf - 0.010f * sPage * pf;    // rotation: moves the far sky
        float pitch = 0.005f * sTiltY * mf;
        float shiftX = 0.9f * sTiltX * mf + 1.4f * sPage * pf;      // shift: Earth most, Moon less
        float shiftY = 0.6f * sTiltY * mf;

        if (progScene == 0 || progComposite == 0) {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
            GLES30.glClearColor(0f, 0f, 0f, 1f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
            return;
        }

        // one-off work, only when something changed
        ensureTargets(PowerGovernor.renderScale(s));
        ensureTextures(PowerGovernor.textureSampleSize(s));
        ensureSky(s);
        if (refreshLocation) {
            refreshLocation = false;
            sunClock.refreshLocation();
        }
        if (s.realtimeSun) sunClock.update(System.currentTimeMillis());
        meteors.update(phase / TWO_PI, s.meteorAmount(), s.loopSeconds());

        // bloom: fades out while swiping between home screens (cheapest possible swipe frames)
        boolean swiping = PowerGovernor.isSwiping(t0);
        int passes = PowerGovernor.bloomPasses(s);
        float fadeTarget = (swiping || passes == 0) ? 0f : 1f;
        bloomFade += (fadeTarget - bloomFade) * (1f - (float) Math.exp(-dt * 14f));
        if (dt == 0f) bloomFade = fadeTarget;
        float bloomAmt = PowerGovernor.bloomAmount(s) * bloomFade;
        boolean doBloom = passes > 0 && bloomAmt > 0.01f && progBright != 0 && progBlur != 0;

        // GPU timing (overlay only)
        boolean timing = s.debugOverlay && timerSupported;
        float gpuMs = timing ? collectGpuTime() : -1f;
        if (timing && !queryPending[queryIdx]) {
            GLES30.glBeginQuery(GL_TIME_ELAPSED_EXT, queries[queryIdx]);
        } else {
            timing = false;
        }

        // ---- 1. scene ----
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, sceneFbo);
        GLES30.glInvalidateFramebuffer(GLES30.GL_FRAMEBUFFER, 1, invalidateAttachments, 0);
        GLES30.glViewport(0, 0, sceneW, sceneH);
        GLES30.glUseProgram(progScene);
        bindTex(0, GLES30.GL_TEXTURE_3D, noiseTex, uNoise);
        bindTex(1, GLES30.GL_TEXTURE_2D, earthDayTex, uEarthDay);
        bindTex(2, GLES30.GL_TEXTURE_2D, earthAuxTex, uEarthAux);
        bindTex(3, GLES30.GL_TEXTURE_2D, moonTex, uMoonTex);
        bindTex(4, GLES30.GL_TEXTURE_2D, cloudTex, uCloudTex);
        bindTex(5, GLES30.GL_TEXTURE_2D, regionDayTex, uRegionDay);
        bindTex(6, GLES30.GL_TEXTURE_2D, regionAuxTex, uRegionAux);
        bindTex(7, GLES30.GL_TEXTURE_2D, skyTexA, uSkyA);
        bindTex(8, GLES30.GL_TEXTURE_2D, skyTexB, uSkyB);
        GLES30.glUniform2f(uTanExt, tanExtX, tanExtY);
        GLES30.glUniform2f(uRes, sceneW, sceneH);
        GLES30.glUniform1f(uPhase, (float) phase);
        GLES30.glUniform4f(uCam, yaw, pitch, shiftX, shiftY);
        GLES30.glUniform1i(uOct, PowerGovernor.octaves(s));
        // flare: driven ONLY by the settings switch (no gesture, no time-of-day override)
        GLES30.glUniform4f(uToggles, s.stars ? 1f : 0f, 0f, sDrift, s.flare ? 1f : 0f);
        if (s.realtimeSun) {
            GLES30.glUniform3fv(uSun, 1, sunClock.sun, 0);
            GLES30.glUniformMatrix3fv(uEarthM, 1, false, sunClock.earthM, 0);
            GLES30.glUniform1f(uRealtime, 1f);
            GLES30.glUniform1f(uEarthSpin, 0f);                   // geostationary view
        } else {
            GLES30.glUniform3fv(uSun, 1, DEFAULT_SUN, 0);
            GLES30.glUniformMatrix3fv(uEarthM, 1, false, baseEarthM, 0);
            GLES30.glUniform1f(uRealtime, 0f);
            // one full rotation per loop, or a gentle sway that keeps Europe in view
            float spin = s.keepEurope ? (float) (0.30 * Math.sin(phase)) : (float) phase;
            GLES30.glUniform1f(uEarthSpin, spin);
        }
        GLES30.glUniform4f(uMoon, s.moonX / 100f, s.moonY / 100f, s.moonScale(), s.moon ? 1f : 0f);
        GLES30.glUniform1f(uMoonBright, s.moonBrightnessFactor());
        GLES30.glUniform4f(uClouds, s.clouds ? 1f : 0f, s.cloudOpacityFactor(), 0f, 0f);
        GLES30.glUniform4f(uLight, s.flareFactor(), s.earthLightFactor(), s.cityLightsFactor(), 0f);
        GLES30.glUniform4f(uPlanets, s.planets ? 1f : 0f, s.dofStrength(), 0f, 0f);
        GLES30.glUniform4fv(uMeteorA, 1, meteors.a, 0);
        GLES30.glUniform4fv(uMeteorB, 1, meteors.b, 0);
        GLES30.glUniform2f(uMeteorLen, meteors.lenA, meteors.lenB);
        GLES30.glBindVertexArray(vao);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);

        // ---- 2-3. bloom ----
        if (doBloom) {
            GLES30.glViewport(0, 0, bloomW, bloomH);
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloomFboA);
            GLES30.glInvalidateFramebuffer(GLES30.GL_FRAMEBUFFER, 1, invalidateAttachments, 0);
            GLES30.glUseProgram(progBright);
            bindTex(0, GLES30.GL_TEXTURE_2D, sceneTex, ubTex);
            GLES30.glUniform2f(ubSrcTexel, 1f / sceneW, 1f / sceneH);
            GLES30.glUniform1f(ubThreshold, 0.70f);              // city lights stay crisp
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);

            GLES30.glUseProgram(progBlur);
            for (int pass = 0; pass < passes; pass++) {
                float radius = passes == 1 ? 2f : (pass == 0 ? 1f : 2f);
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloomFboB);
                bindTex(0, GLES30.GL_TEXTURE_2D, bloomTexA, ulTex);
                GLES30.glUniform2f(ulDir, radius / bloomW, 0f);
                GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloomFboA);
                bindTex(0, GLES30.GL_TEXTURE_2D, bloomTexB, ulTex);
                GLES30.glUniform2f(ulDir, 0f, radius / bloomH);
                GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
            }
        }

        // ---- 4. composite to the screen ----
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        GLES30.glViewport(0, 0, surfW, surfH);
        GLES30.glUseProgram(progComposite);
        bindTex(0, GLES30.GL_TEXTURE_2D, sceneTex, ucScene);
        bindTex(1, GLES30.GL_TEXTURE_2D, bloomTexA, ucBloom);
        GLES30.glUniform2f(ucScreen, surfW, surfH);
        GLES30.glUniform1f(ucBloomAmt, doBloom ? bloomAmt : 0f);
        GLES30.glUniform1f(ucSeed, frameCounter);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);

        if (timing) {
            GLES30.glEndQuery(GL_TIME_ELAPSED_EXT);
            queryPending[queryIdx] = true;
            queryIdx = (queryIdx + 1) % queries.length;
        }

        // ---- 5. performance overlay (optional) ----
        if (s.debugOverlay) {
            float cpuMs = (System.nanoTime() - t0) / 1e6f;
            overlay.frame(t0, cpuMs, gpuMs);
            int state = swiping ? 2 : (PowerGovernor.isMoving(t0) ? 1 : 0);
            overlay.draw(surfW, surfH, PowerGovernor.fps(s, t0), state, sceneW, sceneH,
                    Math.round(sceneW * 100f / surfW), doBloom ? passes : 0,
                    PowerGovernor.thermal(), timerSupported);
        }
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
    }

    // ------------------------------------------------------------------------------------------
    /** Oldest finished GPU timer result in ms, or -1. Never blocks. */
    private float collectGpuTime() {
        float result = -1f;
        GLES30.glGetIntegerv(GL_GPU_DISJOINT_EXT, tmp, 0);
        boolean disjoint = tmp[0] != 0;
        for (int i = 0; i < queries.length; i++) {
            int idx = (queryIdx + i) % queries.length;           // oldest first
            if (!queryPending[idx]) continue;
            GLES30.glGetQueryObjectuiv(queries[idx], GLES30.GL_QUERY_RESULT_AVAILABLE, tmp, 0);
            if (tmp[0] == 0) break;
            GLES30.glGetQueryObjectuiv(queries[idx], GLES30.GL_QUERY_RESULT, tmp, 0);
            queryPending[idx] = false;
            if (!disjoint) result = (tmp[0] & 0xFFFFFFFFL) / 1e6f;
        }
        return result;
    }

    /**
     * Bakes the static sky (sky.frag) when needed. The bake resolution follows the user's quality
     * tier (not the thermal scale), so heating up never triggers a re-bake. Texels coincide with
     * scene pixels at rest; the margin (whole pixels) covers camera drift, tilt and page parallax.
     */
    private void ensureSky(WallpaperSettings s) {
        float tierScale = s.renderScale();
        int w = Math.max(1, Math.round(surfW * tierScale));
        int h = Math.max(1, Math.round(surfH * tierScale));
        int oct = s.octaves();
        if (skyFbo != 0 && w == bakedW && h == bakedH && oct == bakedOct && s.stars == bakedStars
                && s.starDensity == bakedDensity && s.starBrightness == bakedBrightness) {
            return;
        }
        long b0 = SystemClock.elapsedRealtimeNanos();
        float hx = TAN_V * w / h;
        int mx = (int) Math.ceil(0.06 / (2.0 * hx / w));
        int my = (int) Math.ceil(0.04 / (2.0 * TAN_V / h));
        int bw = w + 2 * mx, bh = h + 2 * my;
        tanExtX = hx * bw / w;
        tanExtY = TAN_V * bh / h;

        if (skyFbo == 0 || bw != skyW || bh != skyH) {
            deleteTarget(skyFbo, skyTexA);
            deleteTarget(0, skyTexB);
            skyW = bw;
            skyH = bh;
            skyTexA = createTex(bw, bh, GL_RGB10_A2);            // Milky Way: 10 bits for dark gradients
            skyTexB = createTex(bw, bh, GLES30.GL_RGBA8);        // stars + twinkle code
            GLES30.glGenFramebuffers(1, tmp, 0);
            skyFbo = tmp[0];
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, skyFbo);
            GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0,
                    GLES30.GL_TEXTURE_2D, skyTexA, 0);
            GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT1,
                    GLES30.GL_TEXTURE_2D, skyTexB, 0);
            GLES30.glDrawBuffers(2, drawBuffers2, 0);
            int status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER);
            if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) {
                Log.e(TAG, "Sky framebuffer incomplete: 0x" + Integer.toHexString(status));
            }
        }
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, skyFbo);
        GLES30.glViewport(0, 0, bw, bh);
        if (progSky != 0) {
            GLES30.glUseProgram(progSky);
            bindTex(0, GLES30.GL_TEXTURE_3D, noiseTex, ukNoise);
            GLES30.glUniform2f(ukBakeRes, bw, bh);
            GLES30.glUniform2f(ukTanExt, tanExtX, tanExtY);
            GLES30.glUniform1f(ukAspect, (float) w / h);
            GLES30.glUniform1f(ukPix, 2f * TAN_V / h);
            GLES30.glUniform1i(ukOct, oct);
            GLES30.glUniform2f(ukStars, s.starDensityFactor(), s.starBrightnessFactor());
            GLES30.glUniform1f(ukStarsOn, s.stars ? 1f : 0f);
            GLES30.glBindVertexArray(vao);
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
        } else {
            GLES30.glClearColor(0f, 0f, 0f, 0f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
        }
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        bakedW = w;
        bakedH = h;
        bakedOct = oct;
        bakedStars = s.stars;
        bakedDensity = s.starDensity;
        bakedBrightness = s.starBrightness;
        if (s.debugOverlay) {
            GLES30.glFinish();                                   // measure the bake (overlay only)
            overlay.setBakeMs((SystemClock.elapsedRealtimeNanos() - b0) / 1e6f);
        }
    }

    /** Reads a shader asset and inlines shaders/common.glsl where it is included. */
    private String readShader(String name) {
        String src = readAsset("shaders/" + name);
        String inc = "#include \"common.glsl\"";
        int at = src.indexOf(inc);
        if (at >= 0) {
            src = src.substring(0, at) + readAsset("shaders/common.glsl") + src.substring(at + inc.length());
        }
        return src;
    }

    // ------------------------------------------------------------------------------------------
    private static int loc(int prog, String name) { return GLES30.glGetUniformLocation(prog, name); }

    private static void bindTex(int unit, int target, int tex, int uniform) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit);
        GLES30.glBindTexture(target, tex);
        GLES30.glUniform1i(uniform, unit);
    }

    private void ensureTargets(float scale) {
        if (scale == builtScale && sceneFbo != 0) return;
        deleteTarget(sceneFbo, sceneTex);
        deleteTarget(bloomFboA, bloomTexA);
        deleteTarget(bloomFboB, bloomTexB);
        sceneW = Math.max(1, Math.round(surfW * scale));
        sceneH = Math.max(1, Math.round(surfH * scale));
        bloomW = Math.max(1, sceneW / 4);
        bloomH = Math.max(1, sceneH / 4);
        sceneTex = createTex(sceneW, sceneH);
        sceneFbo = createFbo(sceneTex);
        bloomTexA = createTex(bloomW, bloomH);
        bloomFboA = createFbo(bloomTexA);
        bloomTexB = createTex(bloomW, bloomH);
        bloomFboB = createFbo(bloomTexB);
        // start the bloom target black so the first composite never reads garbage
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloomFboA);
        GLES30.glClearColor(0f, 0f, 0f, 1f);
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        builtScale = scale;
    }

    private void deleteTarget(int fbo, int tex) {
        if (fbo != 0) {
            tmp[0] = fbo;
            GLES30.glDeleteFramebuffers(1, tmp, 0);
        }
        if (tex != 0) {
            tmp[0] = tex;
            GLES30.glDeleteTextures(1, tmp, 0);
        }
    }

    private int createTex(int w, int h) {
        return createTex(w, h, GLES30.GL_RGBA8);
    }

    private int createTex(int w, int h, int internalFormat) {
        GLES30.glGenTextures(1, tmp, 0);
        int t = tmp[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t);
        GLES30.glTexStorage2D(GLES30.GL_TEXTURE_2D, 1, internalFormat, w, h);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
        return t;
    }

    private int createFbo(int tex) {
        GLES30.glGenFramebuffers(1, tmp, 0);
        int f = tmp[0];
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, f);
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0,
                GLES30.GL_TEXTURE_2D, tex, 0);
        int status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER);
        if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) {
            Log.e(TAG, "Framebuffer incomplete: 0x" + Integer.toHexString(status));
        }
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        return f;
    }

    /** (Re)loads the texture maps when the quality tier changes (low power = half size). */
    private void ensureTextures(int sampleSize) {
        if (sampleSize == loadedSampleSize && earthDayTex != 0) return;
        if (earthDayTex != 0) {
            tex6[0] = earthDayTex;
            tex6[1] = earthAuxTex;
            tex6[2] = moonTex;
            tex6[3] = cloudTex;
            tex6[4] = regionDayTex;
            tex6[5] = regionAuxTex;
            GLES30.glDeleteTextures(6, tex6, 0);
        }
        earthDayTex = loadTexture("textures/earth_day.jpg", sampleSize);
        earthAuxTex = loadTexture("textures/earth_aux.jpg", sampleSize);
        moonTex = loadTexture("textures/moon.jpg", sampleSize);
        cloudTex = loadSingleChannel("textures/earth_clouds.jpg", sampleSize);
        // hi-res Europe / North Africa maps (blended over the global ones in the shader)
        regionDayTex = loadTexture("textures/region_day.jpg", sampleSize);
        regionAuxTex = loadTexture("textures/region_aux.jpg", sampleSize);
        loadedSampleSize = sampleSize;
    }

    /**
     * Loads a greyscale map as a single-channel GL_R8 texture (1/4 of the memory of RGBA),
     * mip-mapped, trilinear + anisotropic. Used for the 4K cloud layer (~11 MB on the GPU).
     */
    private int loadSingleChannel(String asset, int sampleSize) {
        GLES30.glGenTextures(1, tmp, 0);
        int id = tmp[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id);
        Bitmap bmp = null;
        try (InputStream in = appContext.getAssets().open(asset)) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inSampleSize = sampleSize;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            bmp = BitmapFactory.decodeStream(in, null, o);
        } catch (IOException e) {
            Log.e(TAG, "Cannot load " + asset, e);
        }
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1);
        if (bmp != null) {
            int w = bmp.getWidth(), h = bmp.getHeight();
            ByteBuffer buf = ByteBuffer.allocateDirect(w * h);
            int[] row = new int[w];
            for (int y = 0; y < h; y++) {
                bmp.getPixels(row, 0, w, 0, y, w, 1);
                for (int x = 0; x < w; x++) buf.put((byte) ((row[x] >> 16) & 0xFF));
            }
            buf.position(0);
            bmp.recycle();
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R8, w, h, 0,
                    GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, buf);
            GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D);
        } else {
            byte[] none = {0};
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R8, 1, 1, 0,
                    GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, ByteBuffer.wrap(none));
        }
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
        if (maxAniso > 1f) {
            GLES30.glTexParameterf(GLES30.GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, maxAniso);
        }
        return id;
    }

    private int loadTexture(String asset, int sampleSize) {
        GLES30.glGenTextures(1, tmp, 0);
        int id = tmp[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id);
        Bitmap bmp = null;
        try (InputStream in = appContext.getAssets().open(asset)) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inSampleSize = sampleSize;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            bmp = BitmapFactory.decodeStream(in, null, o);
        } catch (IOException e) {
            Log.e(TAG, "Cannot load " + asset, e);
        }
        if (bmp != null) {
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0);
            bmp.recycle();
            GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D);
        } else {
            byte[] grey = {(byte) 20, (byte) 30, (byte) 50, (byte) 255};
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, 1, 1, 0,
                    GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, ByteBuffer.wrap(grey));
        }
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
        if (maxAniso > 1f) {
            GLES30.glTexParameterf(GLES30.GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, maxAniso);
        }
        return id;
    }

    private String readAsset(String name) {
        try (InputStream in = appContext.getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            Log.e(TAG, "Cannot read " + name, e);
            return "";
        }
    }

    private static int compile(int type, String src) {
        int sh = GLES30.glCreateShader(type);
        GLES30.glShaderSource(sh, src);
        GLES30.glCompileShader(sh);
        int[] ok = new int[1];
        GLES30.glGetShaderiv(sh, GLES30.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            Log.e(TAG, "Shader compile error: " + GLES30.glGetShaderInfoLog(sh));
            GLES30.glDeleteShader(sh);
            return 0;
        }
        return sh;
    }

    private static int buildProgram(String vs, String fs) {
        int v = compile(GLES30.GL_VERTEX_SHADER, vs);
        int f = compile(GLES30.GL_FRAGMENT_SHADER, fs);
        if (v == 0 || f == 0) return 0;
        int p = GLES30.glCreateProgram();
        GLES30.glAttachShader(p, v);
        GLES30.glAttachShader(p, f);
        GLES30.glLinkProgram(p);
        GLES30.glDeleteShader(v);
        GLES30.glDeleteShader(f);
        int[] ok = new int[1];
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) {
            Log.e(TAG, "Program link error: " + GLES30.glGetProgramInfoLog(p));
            GLES30.glDeleteProgram(p);
            return 0;
        }
        return p;
    }
}
