package com.matan.spacewallpaper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * GPU renderer shared by the live wallpaper and the in-app preview.
 *
 * Pipeline per frame (no allocations):
 *   1. scene.frag      -> scene target (screen x renderScale, RGBA8)
 *   2. bright.frag     -> bloom A (1/4 of the scene target): bright-pass + downsample
 *   3. blur.frag x4    -> A -> B -> A -> B -> A  (separable Gaussian, two radii)
 *   4. composite.frag  -> screen: upscale + bloom + film grain + dithering
 * Battery Saver (or the PowerGovernor's low-power tier) skips passes 2-3.
 *
 * Seamless infinite loop: the phase advances with real time and wraps at 2*PI; every animated
 * term in the shader is periodic in the phase. Pausing freezes the phase.
 */
public final class SpaceRenderer implements GLSurfaceView.Renderer {
    private static final String TAG = "SpaceRenderer";
    private static final double TWO_PI = Math.PI * 2.0;
    /** Sun just behind the Earth's limb at ~(48%, 64%) of the screen - fitted to the reference */
    private static final float[] DEFAULT_SUN = {-0.00981108f, -0.17333015f, -0.98481491f};

    private final Context appContext;
    private volatile WallpaperSettings settings;

    // inputs written by the UI thread (sensors / home-screen offsets)
    private volatile float tiltX, tiltY, pageOffset;
    // smoothed camera state (GL thread only)
    private float sTiltX, sTiltY, sPage, sDrift = 1f;

    private double phase;
    private long lastNanos;
    private int frameCounter;
    private volatile boolean resetClock = true;
    private volatile boolean refreshLocation;

    // programs
    private int progScene, progBright, progBlur, progComposite;
    private int vao;
    // textures
    private int noiseTex, earthDayTex, earthAuxTex, moonTex;
    private int loadedSampleSize = -1;
    // render targets
    private int sceneFbo, sceneTex, sceneW, sceneH;
    private int bloomFboA, bloomTexA, bloomFboB, bloomTexB, bloomW, bloomH;
    private int surfW = 1, surfH = 1;
    private float builtScale = -1f;

    private final SunClock sunClock = new SunClock();
    /** Default orientation: Gibraltar under (70%, 52%), north tilted 15 deg - Europe upper right */
    private final float[] baseEarthM = new float[9];

    // scene uniforms
    private int uNoise, uRes, uPhase, uCam, uOct, uToggles, uEarthDay, uEarthAux, uMoonTex,
            uSun, uRealtime, uEarthM, uEarthSpin, uStars, uMoon, uPlanets, uMeteors;
    // post uniforms
    private int ubTex, ubSrcTexel, ubThreshold, ulTex, ulDir, ucScene, ucBloom, ucScreen, ucBloomAmt, ucSeed;

    private final int[] tmp = new int[1];
    private final int[] tex3 = new int[3];
    private final int[] invalidateAttachments = {GLES30.GL_COLOR_ATTACHMENT0};

    public SpaceRenderer(Context context, WallpaperSettings initial) {
        appContext = context.getApplicationContext();
        settings = initial;
        phase = 0.0;
        EarthFrame.build(baseEarthM, null, 36.0, -5.5, 0.70, 0.52, -15.0);
    }

    public void setSettings(WallpaperSettings s) { settings = s; }

    /** Normalised device tilt in [-1, 1] (after the slow re-centering baseline). */
    public void setTilt(float x, float y) { tiltX = x; tiltY = y; }

    /** Home screen page offset in [-0.5, 0.5]. */
    public void setPageOffset(float o) { pageOffset = o; }

    /** Call when rendering resumes so the paused time is not counted. */
    public void resetClock() { resetClock = true; }

    /** Time zone changed (e.g. travel): recompute the location used by the real-time sun. */
    public void refreshLocation() { refreshLocation = true; }

    // ------------------------------------------------------------------------------------------
    @Override
    public void onSurfaceCreated(GL10 unused, EGLConfig config) {
        String vs = readAsset("shaders/fullscreen.vert");
        progScene = buildProgram(vs, readAsset("shaders/scene.frag"));
        progBright = buildProgram(vs, readAsset("shaders/bright.frag"));
        progBlur = buildProgram(vs, readAsset("shaders/blur.frag"));
        progComposite = buildProgram(vs, readAsset("shaders/composite.frag"));

        if (progScene != 0) {
            uNoise = loc(progScene, "uNoise");
            uRes = loc(progScene, "uRes");
            uPhase = loc(progScene, "uPhase");
            uCam = loc(progScene, "uCam");
            uOct = loc(progScene, "uOct");
            uToggles = loc(progScene, "uToggles");
            uEarthDay = loc(progScene, "uEarthDay");
            uEarthAux = loc(progScene, "uEarthAux");
            uMoonTex = loc(progScene, "uMoonTex");
            uSun = loc(progScene, "uSun");
            uRealtime = loc(progScene, "uRealtime");
            uEarthM = loc(progScene, "uEarthM");
            uEarthSpin = loc(progScene, "uEarthSpin");
            uStars = loc(progScene, "uStars");
            uMoon = loc(progScene, "uMoon");
            uPlanets = loc(progScene, "uPlanets");
            uMeteors = loc(progScene, "uMeteors");
        }
        if (progBright != 0) {
            ubTex = loc(progBright, "uTex");
            ubSrcTexel = loc(progBright, "uSrcTexel");
            ubThreshold = loc(progBright, "uThreshold");
        }
        if (progBlur != 0) {
            ulTex = loc(progBlur, "uTex");
            ulDir = loc(progBlur, "uDir");
        }
        if (progComposite != 0) {
            ucScene = loc(progComposite, "uScene");
            ucBloom = loc(progComposite, "uBloom");
            ucScreen = loc(progComposite, "uScreen");
            ucBloomAmt = loc(progComposite, "uBloomAmt");
            ucSeed = loc(progComposite, "uSeed");
        }

        GLES30.glGenVertexArrays(1, tmp, 0);
        vao = tmp[0];

        GLES30.glGenTextures(1, tmp, 0);
        noiseTex = tmp[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, noiseTex);
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1);
        int n = NoiseTexture.SIZE;
        GLES30.glTexImage3D(GLES30.GL_TEXTURE_3D, 0, GLES30.GL_R8, n, n, n, 0,
                GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, NoiseTexture.get());
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_R, GLES30.GL_REPEAT);

        // Earth / Moon maps are loaded lazily per quality tier in onDrawFrame
        earthDayTex = earthAuxTex = moonTex = 0;
        loadedSampleSize = -1;
        sunClock.refreshLocation();

        GLES30.glDisable(GLES30.GL_DEPTH_TEST);
        GLES30.glDisable(GLES30.GL_BLEND);
        sceneFbo = sceneTex = bloomFboA = bloomTexA = bloomFboB = bloomTexB = 0;
        builtScale = -1f;
        resetClock = true;
    }

    @Override
    public void onSurfaceChanged(GL10 unused, int width, int height) {
        surfW = Math.max(1, width);
        surfH = Math.max(1, height);
        builtScale = -1f; // rebuild offscreen targets for the new size
    }

    @Override
    public void onDrawFrame(GL10 unused) {
        final WallpaperSettings s = settings;

        // ---- time / phase (double precision, wrapped => runs forever without drift) ----
        long now = System.nanoTime();
        float dt;
        if (resetClock || lastNanos == 0L) {
            dt = 0f;
            resetClock = false;
        } else {
            dt = Math.min((now - lastNanos) / 1e9f, 0.1f);
        }
        lastNanos = now;
        phase += dt * TWO_PI / s.loopSeconds();
        if (phase >= TWO_PI) phase -= TWO_PI;
        frameCounter = (frameCounter + 1) & 1023;

        // ---- smoothed parallax inputs (gyroscope + home-screen pages) ----
        float k = 1f - (float) Math.exp(-dt * 3.5f);
        float tx = s.motion ? tiltX : 0f;
        float ty = s.motion ? tiltY : 0f;
        float pg = s.parallax ? pageOffset : 0f;
        sTiltX += (tx - sTiltX) * k;
        sTiltY += (ty - sTiltY) * k;
        sPage += (pg - sPage) * k;
        sDrift += (s.parallaxFactor() - sDrift) * k * 0.5f;

        float mf = s.motionFactor();
        float pf = s.parallaxFactor();
        float yaw = -0.006f * sTiltX * mf - 0.010f * sPage * pf;    // rotation: moves the far sky
        float pitch = 0.005f * sTiltY * mf;
        float shiftX = 0.9f * sTiltX * mf + 1.4f * sPage * pf;      // shift: Earth most, Moon less
        float shiftY = 0.6f * sTiltY * mf;

        if (progScene == 0 || progComposite == 0) {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
            GLES30.glClearColor(0f, 0f, 0f, 1f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
            return;
        }

        ensureTargets(PowerGovernor.renderScale(s));
        ensureTextures(PowerGovernor.textureSampleSize(s));
        if (refreshLocation) {
            refreshLocation = false;
            sunClock.refreshLocation();
        }
        if (s.realtimeSun) sunClock.update(System.currentTimeMillis());

        // ---- 1. scene ----
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, sceneFbo);
        GLES30.glInvalidateFramebuffer(GLES30.GL_FRAMEBUFFER, 1, invalidateAttachments, 0);
        GLES30.glViewport(0, 0, sceneW, sceneH);
        GLES30.glUseProgram(progScene);
        bindTex(0, GLES30.GL_TEXTURE_3D, noiseTex, uNoise);
        bindTex(1, GLES30.GL_TEXTURE_2D, earthDayTex, uEarthDay);
        bindTex(2, GLES30.GL_TEXTURE_2D, earthAuxTex, uEarthAux);
        bindTex(3, GLES30.GL_TEXTURE_2D, moonTex, uMoonTex);
        GLES30.glUniform2f(uRes, sceneW, sceneH);
        GLES30.glUniform1f(uPhase, (float) phase);
        GLES30.glUniform4f(uCam, yaw, pitch, shiftX, shiftY);
        GLES30.glUniform1i(uOct, PowerGovernor.octaves(s));
        GLES30.glUniform4f(uToggles, s.stars ? 1f : 0f, 0f, sDrift, s.flare ? 1f : 0f);
        if (s.realtimeSun) {
            GLES30.glUniform3fv(uSun, 1, sunClock.sun, 0);
            GLES30.glUniformMatrix3fv(uEarthM, 1, false, sunClock.earthM, 0);
            GLES30.glUniform1f(uRealtime, 1f);
            GLES30.glUniform1f(uEarthSpin, 0f);                   // geostationary view
        } else {
            GLES30.glUniform3fv(uSun, 1, DEFAULT_SUN, 0);
            GLES30.glUniformMatrix3fv(uEarthM, 1, false, baseEarthM, 0);
            GLES30.glUniform1f(uRealtime, 0f);
            // one full rotation per loop, or a gentle sway that keeps Europe in view
            float spin = s.keepEurope ? (float) (0.30 * Math.sin(phase)) : (float) phase;
            GLES30.glUniform1f(uEarthSpin, spin);
        }
        GLES30.glUniform2f(uStars, s.starDensityFactor(), s.starBrightnessFactor());
        GLES30.glUniform4f(uMoon, s.moonX / 100f, s.moonY / 100f, s.moonScale(), s.moon ? 1f : 0f);
        GLES30.glUniform4f(uPlanets, s.planets ? 1f : 0f, s.dofStrength(), 0f, 0f);
        GLES30.glUniform4f(uMeteors, s.meteorAmount(), s.loopSeconds(), 0f, 0f);
        GLES30.glBindVertexArray(vao);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);

        // ---- 2-3. bloom (skipped in the low-power tier) ----
        float bloomAmt = PowerGovernor.bloomAmount(s);
        if (bloomAmt > 0f && progBright != 0 && progBlur != 0) {
            GLES30.glViewport(0, 0, bloomW, bloomH);
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloomFboA);
            GLES30.glUseProgram(progBright);
            bindTex(0, GLES30.GL_TEXTURE_2D, sceneTex, ubTex);
            GLES30.glUniform2f(ubSrcTexel, 1f / sceneW, 1f / sceneH);
            GLES30.glUniform1f(ubThreshold, 0.62f);
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);

            GLES30.glUseProgram(progBlur);
            for (int pass = 0; pass < 2; pass++) {
                float radius = pass == 0 ? 1f : 2f;
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloomFboB);
                bindTex(0, GLES30.GL_TEXTURE_2D, bloomTexA, ulTex);
                GLES30.glUniform2f(ulDir, radius / bloomW, 0f);
                GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloomFboA);
                bindTex(0, GLES30.GL_TEXTURE_2D, bloomTexB, ulTex);
                GLES30.glUniform2f(ulDir, 0f, radius / bloomH);
                GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
            }
        }

        // ---- 4. composite to the screen ----
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        GLES30.glViewport(0, 0, surfW, surfH);
        GLES30.glUseProgram(progComposite);
        bindTex(0, GLES30.GL_TEXTURE_2D, sceneTex, ucScene);
        bindTex(1, GLES30.GL_TEXTURE_2D, bloomTexA, ucBloom);
        GLES30.glUniform2f(ucScreen, surfW, surfH);
        GLES30.glUniform1f(ucBloomAmt, bloomAmt);
        GLES30.glUniform1f(ucSeed, frameCounter);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
    }

    // ------------------------------------------------------------------------------------------
    private static int loc(int prog, String name) { return GLES30.glGetUniformLocation(prog, name); }

    private static void bindTex(int unit, int target, int tex, int uniform) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit);
        GLES30.glBindTexture(target, tex);
        GLES30.glUniform1i(uniform, unit);
    }

    private void ensureTargets(float scale) {
        if (scale == builtScale && sceneFbo != 0) return;
        deleteTarget(sceneFbo, sceneTex);
        deleteTarget(bloomFboA, bloomTexA);
        deleteTarget(bloomFboB, bloomTexB);
        sceneW = Math.max(1, Math.round(surfW * scale));
        sceneH = Math.max(1, Math.round(surfH * scale));
        bloomW = Math.max(1, sceneW / 4);
        bloomH = Math.max(1, sceneH / 4);
        sceneTex = createTex(sceneW, sceneH);
        sceneFbo = createFbo(sceneTex);
        bloomTexA = createTex(bloomW, bloomH);
        bloomFboA = createFbo(bloomTexA);
        bloomTexB = createTex(bloomW, bloomH);
        bloomFboB = createFbo(bloomTexB);
        // start the bloom target black so the first composite never reads garbage
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloomFboA);
        GLES30.glClearColor(0f, 0f, 0f, 1f);
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        builtScale = scale;
    }

    private void deleteTarget(int fbo, int tex) {
        if (fbo != 0) {
            tmp[0] = fbo;
            GLES30.glDeleteFramebuffers(1, tmp, 0);
        }
        if (tex != 0) {
            tmp[0] = tex;
            GLES30.glDeleteTextures(1, tmp, 0);
        }
    }

    private int createTex(int w, int h) {
        GLES30.glGenTextures(1, tmp, 0);
        int t = tmp[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t);
        GLES30.glTexStorage2D(GLES30.GL_TEXTURE_2D, 1, GLES30.GL_RGBA8, w, h);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
        return t;
    }

    private int createFbo(int tex) {
        GLES30.glGenFramebuffers(1, tmp, 0);
        int f = tmp[0];
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, f);
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0,
                GLES30.GL_TEXTURE_2D, tex, 0);
        int status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER);
        if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) {
            Log.e(TAG, "Framebuffer incomplete: 0x" + Integer.toHexString(status));
        }
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        return f;
    }

    /** (Re)loads the texture maps when the quality tier changes (low power = half size). */
    private void ensureTextures(int sampleSize) {
        if (sampleSize == loadedSampleSize && earthDayTex != 0) return;
        if (earthDayTex != 0) {
            tex3[0] = earthDayTex;
            tex3[1] = earthAuxTex;
            tex3[2] = moonTex;
            GLES30.glDeleteTextures(3, tex3, 0);
        }
        earthDayTex = loadTexture("textures/earth_day.jpg", sampleSize);
        earthAuxTex = loadTexture("textures/earth_aux.jpg", sampleSize);
        moonTex = loadTexture("textures/moon.jpg", sampleSize);
        loadedSampleSize = sampleSize;
    }

    private int loadTexture(String asset, int sampleSize) {
        GLES30.glGenTextures(1, tmp, 0);
        int id = tmp[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id);
        Bitmap bmp = null;
        try (InputStream in = appContext.getAssets().open(asset)) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inSampleSize = sampleSize;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            bmp = BitmapFactory.decodeStream(in, null, o);
        } catch (IOException e) {
            Log.e(TAG, "Cannot load " + asset, e);
        }
        if (bmp != null) {
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0);
            bmp.recycle();
            GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D);
        } else {
            byte[] grey = {(byte) 20, (byte) 30, (byte) 50, (byte) 255};
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, 1, 1, 0,
                    GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, ByteBuffer.wrap(grey));
        }
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
        return id;
    }

    private String readAsset(String name) {
        try (InputStream in = appContext.getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            Log.e(TAG, "Cannot read " + name, e);
            return "";
        }
    }

    private static int compile(int type, String src) {
        int sh = GLES30.glCreateShader(type);
        GLES30.glShaderSource(sh, src);
        GLES30.glCompileShader(sh);
        int[] ok = new int[1];
        GLES30.glGetShaderiv(sh, GLES30.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            Log.e(TAG, "Shader compile error: " + GLES30.glGetShaderInfoLog(sh));
            GLES30.glDeleteShader(sh);
            return 0;
        }
        return sh;
    }

    private static int buildProgram(String vs, String fs) {
        int v = compile(GLES30.GL_VERTEX_SHADER, vs);
        int f = compile(GLES30.GL_FRAGMENT_SHADER, fs);
        if (v == 0 || f == 0) return 0;
        int p = GLES30.glCreateProgram();
        GLES30.glAttachShader(p, v);
        GLES30.glAttachShader(p, f);
        GLES30.glLinkProgram(p);
        GLES30.glDeleteShader(v);
        GLES30.glDeleteShader(f);
        int[] ok = new int[1];
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) {
            Log.e(TAG, "Program link error: " + GLES30.glGetProgramInfoLog(p));
            GLES30.glDeleteProgram(p);
            return 0;
        }
        return p;
    }
}
