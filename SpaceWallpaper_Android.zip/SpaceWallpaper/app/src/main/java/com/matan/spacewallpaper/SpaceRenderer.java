package com.matan.spacewallpaper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * GPU renderer shared by the live wallpaper and the in-app preview.
 *
 * Pipeline per frame (no allocations):
 *   1. scene shader -> offscreen RGBA8 target at (screen * renderScale)
 *   2. glBlitFramebuffer with linear filtering -> screen
 *
 * Seamless infinite loop: the phase advances continuously with real time and wraps at 2*PI.
 * Every animated term in the shader is periodic in the phase, so there is never a jump.
 * Pausing (screen off / wallpaper hidden) simply freezes the phase; it resumes where it stopped.
 */
public final class SpaceRenderer implements GLSurfaceView.Renderer {
    private static final String TAG = "SpaceRenderer";
    private static final double TWO_PI = Math.PI * 2.0;

    private final Context appContext;
    private volatile WallpaperSettings settings;

    // inputs written by the UI thread (sensors / home-screen offsets)
    private volatile float tiltX, tiltY, pageOffset;
    // smoothed camera state (GL thread only)
    private float sTiltX, sTiltY, sPage, sDrift = 1f;

    private double phase;
    private long lastNanos;
    private volatile boolean resetClock = true;

    private int program;
    private int vao;
    private int noiseTex;
    private int earthDayTex, earthAuxTex, moonTex;
    private int fbo, fboTex, fboW, fboH;
    private int surfW = 1, surfH = 1;
    private float builtScale = -1f;

    private int uNoise, uRes, uPhase, uCam, uOct, uToggles, uEarthDay, uEarthAux, uMoonTex;
    private final int[] tmp = new int[1];
    private final int[] invalidateAttachments = {GLES30.GL_COLOR_ATTACHMENT0};

    public SpaceRenderer(Context context, WallpaperSettings initial) {
        appContext = context.getApplicationContext();
        settings = initial;
        phase = 0.0;
    }

    public void setSettings(WallpaperSettings s) { settings = s; }

    /** Normalised device tilt in [-1, 1] (after the slow re-centering baseline). */
    public void setTilt(float x, float y) { tiltX = x; tiltY = y; }

    /** Home screen page offset in [-0.5, 0.5]. */
    public void setPageOffset(float o) { pageOffset = o; }

    /** Call when rendering resumes so the paused time is not counted. */
    public void resetClock() { resetClock = true; }

    // ------------------------------------------------------------------------------------------
    @Override
    public void onSurfaceCreated(GL10 unused, EGLConfig config) {
        // GL context is new: everything must be (re)created
        program = buildProgram(readAsset("shaders/fullscreen.vert"), readAsset("shaders/scene.frag"));
        if (program != 0) {
            uNoise = GLES30.glGetUniformLocation(program, "uNoise");
            uRes = GLES30.glGetUniformLocation(program, "uRes");
            uPhase = GLES30.glGetUniformLocation(program, "uPhase");
            uCam = GLES30.glGetUniformLocation(program, "uCam");
            uOct = GLES30.glGetUniformLocation(program, "uOct");
            uToggles = GLES30.glGetUniformLocation(program, "uToggles");
            uEarthDay = GLES30.glGetUniformLocation(program, "uEarthDay");
            uEarthAux = GLES30.glGetUniformLocation(program, "uEarthAux");
            uMoonTex = GLES30.glGetUniformLocation(program, "uMoonTex");
        }

        GLES30.glGenVertexArrays(1, tmp, 0);
        vao = tmp[0];

        GLES30.glGenTextures(1, tmp, 0);
        noiseTex = tmp[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, noiseTex);
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1);
        int n = NoiseTexture.SIZE;
        GLES30.glTexImage3D(GLES30.GL_TEXTURE_3D, 0, GLES30.GL_R8, n, n, n, 0,
                GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, NoiseTexture.get());
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_R, GLES30.GL_REPEAT);

        // real Earth / Moon maps (NASA imagery), mip-mapped for clean minification
        earthDayTex = loadTexture("textures/earth_day.jpg");
        earthAuxTex = loadTexture("textures/earth_aux.jpg");
        moonTex = loadTexture("textures/moon.jpg");

        GLES30.glDisable(GLES30.GL_DEPTH_TEST);
        GLES30.glDisable(GLES30.GL_BLEND);
        fbo = 0;
        fboTex = 0;
        builtScale = -1f;
        resetClock = true;
    }

    @Override
    public void onSurfaceChanged(GL10 unused, int width, int height) {
        surfW = Math.max(1, width);
        surfH = Math.max(1, height);
        builtScale = -1f; // rebuild offscreen target for the new size
    }

    @Override
    public void onDrawFrame(GL10 unused) {
        final WallpaperSettings s = settings;

        // ---- time / phase (double precision, wrapped => runs forever without drift) ----
        long now = System.nanoTime();
        float dt;
        if (resetClock || lastNanos == 0L) {
            dt = 0f;
            resetClock = false;
        } else {
            dt = Math.min((now - lastNanos) / 1e9f, 0.1f);
        }
        lastNanos = now;
        phase += dt * TWO_PI / s.loopSeconds();
        if (phase >= TWO_PI) phase -= TWO_PI;

        // ---- smooth parallax inputs ----
        float k = 1f - (float) Math.exp(-dt * 3.5f);
        float tx = s.motion ? tiltX : 0f;
        float ty = s.motion ? tiltY : 0f;
        float pg = s.parallax ? pageOffset : 0f;
        float driftTarget = s.parallax ? 1f : 0f;
        sTiltX += (tx - sTiltX) * k;
        sTiltY += (ty - sTiltY) * k;
        sPage += (pg - sPage) * k;
        sDrift += (driftTarget - sDrift) * k * 0.5f;

        float yaw = -0.010f * sTiltX - 0.020f * sPage;
        float pitch = 0.008f * sTiltY;
        float shiftX = 0.9f * sTiltX + 1.6f * sPage;
        float shiftY = 0.6f * sTiltY;

        if (program == 0) {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
            GLES30.glClearColor(0f, 0f, 0f, 1f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
            return;
        }

        ensureTarget(s.renderScale());

        // ---- 1. scene at reduced resolution ----
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo);
        GLES30.glInvalidateFramebuffer(GLES30.GL_FRAMEBUFFER, 1, invalidateAttachments, 0);
        GLES30.glViewport(0, 0, fboW, fboH);
        GLES30.glUseProgram(program);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, noiseTex);
        GLES30.glUniform1i(uNoise, 0);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, earthDayTex);
        GLES30.glUniform1i(uEarthDay, 1);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE2);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, earthAuxTex);
        GLES30.glUniform1i(uEarthAux, 2);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE3);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, moonTex);
        GLES30.glUniform1i(uMoonTex, 3);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
        GLES30.glUniform2f(uRes, fboW, fboH);
        GLES30.glUniform1f(uPhase, (float) phase);
        GLES30.glUniform4f(uCam, yaw, pitch, shiftX, shiftY);
        GLES30.glUniform1i(uOct, s.octaves());
        GLES30.glUniform4f(uToggles, s.stars ? 1f : 0f, s.spacecraft ? 1f : 0f, sDrift, 0f);
        GLES30.glBindVertexArray(vao);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);

        // ---- 2. GPU upscale to the screen ----
        GLES30.glBindFramebuffer(GLES30.GL_READ_FRAMEBUFFER, fbo);
        GLES30.glBindFramebuffer(GLES30.GL_DRAW_FRAMEBUFFER, 0);
        GLES30.glBlitFramebuffer(0, 0, fboW, fboH, 0, 0, surfW, surfH,
                GLES30.GL_COLOR_BUFFER_BIT, GLES30.GL_LINEAR);
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
    }

    // ------------------------------------------------------------------------------------------
    private void ensureTarget(float scale) {
        if (scale == builtScale && fbo != 0) return;
        if (fbo != 0) {
            tmp[0] = fbo;
            GLES30.glDeleteFramebuffers(1, tmp, 0);
            tmp[0] = fboTex;
            GLES30.glDeleteTextures(1, tmp, 0);
        }
        fboW = Math.max(1, Math.round(surfW * scale));
        fboH = Math.max(1, Math.round(surfH * scale));

        GLES30.glGenTextures(1, tmp, 0);
        fboTex = tmp[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fboTex);
        GLES30.glTexStorage2D(GLES30.GL_TEXTURE_2D, 1, GLES30.GL_RGBA8, fboW, fboH);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);

        GLES30.glGenFramebuffers(1, tmp, 0);
        fbo = tmp[0];
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo);
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0,
                GLES30.GL_TEXTURE_2D, fboTex, 0);
        int status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER);
        if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) {
            Log.e(TAG, "Offscreen framebuffer incomplete: 0x" + Integer.toHexString(status));
        }
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        builtScale = scale;
    }

    private int loadTexture(String asset) {
        GLES30.glGenTextures(1, tmp, 0);
        int id = tmp[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id);
        Bitmap bmp = null;
        try (InputStream in = appContext.getAssets().open(asset)) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            bmp = BitmapFactory.decodeStream(in, null, o);
        } catch (IOException e) {
            Log.e(TAG, "Cannot load " + asset, e);
        }
        if (bmp != null) {
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0);
            bmp.recycle();
            GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D);
        } else {
            byte[] grey = {(byte) 40, (byte) 60, (byte) 90, (byte) 255};
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, 1, 1, 0,
                    GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, java.nio.ByteBuffer.wrap(grey));
        }
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
        return id;
    }

    private String readAsset(String name) {
        try (InputStream in = appContext.getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            Log.e(TAG, "Cannot read " + name, e);
            return "";
        }
    }

    private static int compile(int type, String src) {
        int sh = GLES30.glCreateShader(type);
        GLES30.glShaderSource(sh, src);
        GLES30.glCompileShader(sh);
        int[] ok = new int[1];
        GLES30.glGetShaderiv(sh, GLES30.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            Log.e(TAG, "Shader compile error: " + GLES30.glGetShaderInfoLog(sh));
            GLES30.glDeleteShader(sh);
            return 0;
        }
        return sh;
    }

    private static int buildProgram(String vs, String fs) {
        int v = compile(GLES30.GL_VERTEX_SHADER, vs);
        int f = compile(GLES30.GL_FRAGMENT_SHADER, fs);
        if (v == 0 || f == 0) return 0;
        int p = GLES30.glCreateProgram();
        GLES30.glAttachShader(p, v);
        GLES30.glAttachShader(p, f);
        GLES30.glLinkProgram(p);
        GLES30.glDeleteShader(v);
        GLES30.glDeleteShader(f);
        int[] ok = new int[1];
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) {
            Log.e(TAG, "Program link error: " + GLES30.glGetProgramInfoLog(p));
            GLES30.glDeleteProgram(p);
            return 0;
        }
        return p;
    }
}
